<?php 
	require '../init.php';

	if(isset($_SESSION['user_name']) && isset($_SESSION['password']))
	{

		$username=$_SESSION['user_name'];
		$password=$_SESSION['password'];

		$source->Query("SELECT * FROM `admin` where  `id`=?",[$username]);
		$UserData=$source->Single(); 
		if($UserData==false){
			session_destroy();
			header('location:index');
		}
		
	}
	else
	{
		header('location:index');
	}
	
	
	
	
	
?>