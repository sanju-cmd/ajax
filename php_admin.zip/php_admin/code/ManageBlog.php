<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
			$name = base64_encode($_POST['name']);
			$description = base64_encode($_POST['description']);
			$image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			
			if(empty($name) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `blog` (`id`, `title`, `img`, `description`) VALUES (NULL, '$name', '$image', '$description')");	
				if($sel){
					 move_uploaded_file($_FILES['image']['tmp_name'],"../upload/blog/".$image);
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'AddBlog'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'Update':
		
			$id = $_POST['id'];
			$title = base64_encode($_POST['title']);
			$description = base64_encode($_POST['description']);
			
			
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$result=$source->Query("UPDATE `blog` SET `title`='$title', `description`='$description' WHERE `id`='$id'");
				
				if($result){
						if(!empty($_FILES['image']['name'])){
                        $image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image']['tmp_name'],"../upload/blog/".$image);
                        $source->Query("UPDATE `blog` SET `img`='$image' WHERE `id`='$id'");
						}
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageBlog'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;

        		
		
		default:
			break;
	}
	
 ?>