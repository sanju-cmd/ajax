<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
			$name = $_POST['name'];
			$email = $_POST['email'];
			$mobile = $_POST['mobile'];
			$password = $_POST['password'];
			$document_no = $_POST['document_no'];
			$image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			$document_image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['document_image']['name'],PATHINFO_EXTENSION);
			
			if(empty($name) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `tbl_deliveryboy`(`name`,`email`,`mobile`,`password`,`document_no`,`document_image`,`image`,`date`,`time`) VALUES('$name','$email','$mobile','$password','$document_no','$document_image','$image','$date','$time')");	
				if($sel){
					$last_id = $source->LastId();
					$source->Query("UPDATE `tbl_deliveryboy` SET sponsorID='ADD001$last_id' WHERE `id`='$last_id'");
					 move_uploaded_file($_FILES['image']['tmp_name'],"../../API/v1/uploads/Driver/".$image);
					 move_uploaded_file($_FILES['document_image']['tmp_name'],"../../API/v1/uploads/Driver/".$document_image);
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'AddDeliveryBoy'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'Update':
		
			$id = $_POST['id'];
			$name = $_POST['name'];
			$email = $_POST['email'];
			$mobile = $_POST['mobile'];
			$document_no = $_POST['document_no'];
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `tbl_deliveryboy` SET `name`=?, `email`=?, `mobile`=?, `document_no`=?,  `date`=?, `time`=? WHERE `id`=?",[$name,$email,$mobile,$document_no,$date,$time,$id]);
				
				if($res){
						if(!empty($_FILES['image']['name'])){
                        $image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image']['tmp_name'],"../../API/v1/uploads/Driver/".$image);
                        $source->Query("UPDATE `tbl_deliveryboy` SET `image`='$image' WHERE `id`='$id'");
						}
						if(!empty($_FILES['document_image']['name'])){
                        $document_image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['document_image']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['document_image']['tmp_name'],"../../API/v1/uploads/Driver/".$document_image);
                        $source->Query("UPDATE `tbl_deliveryboy` SET `document_image`='$document_image' WHERE `id`='$id'");
						}
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageDeliveryBoy'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;			
		
		default:
			# code...
			break;
	}
	
 ?>