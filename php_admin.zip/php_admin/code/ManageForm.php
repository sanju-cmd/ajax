<?php 


	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		

		case 'About':
		
			$id = 1;
			$about = $_POST['about'];
			if(empty($id) or empty($about)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `about` SET `about`=?, `date`=?, `time`=? WHERE `id`=?",[$about,$date,$time,$id]);
				
				if($res){
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageAbout'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;	

			// Settings
			
			case 'Setting':
		
			$id = 1;
			$facebook = $_POST['facebook'];
			$instagram = $_POST['instagram'];
			$twitter = $_POST['twitter'];
			$linkedin = $_POST['linkedin'];
			$indiamart = $_POST['indiamart'];
			$amazon = $_POST['amazon'];
			$flipkart = $_POST['flipkart'];
			$map = $_POST['map'];
			if(empty($id) or empty($facebook)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `setting` SET `facebook`=?, `instagram`=?, `twitter`=?, `linkedin`=?, `indiamart`=?, `amazon`=?, `flipkart`=?, `map`=?, `date`=?, `time`=? WHERE `id`=?",[$facebook,$instagram,$twitter,$linkedin,$indiamart,$amazon,$flipkart,$map,$date,$time,$id]);
				
				if($res){
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageSetting'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;
		case 'AddNotification':
			echo json_encode(array('res' =>'success' ,'msg'=>'Send Successfully','url'=>'ManageNotification'));
			break;


		default:
			# code...
			break;
	}







 ?>