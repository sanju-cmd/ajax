<?php
	
	if(isset($_GET['flag']) && $_GET['flag']==2)
	{
		$id=$_GET['id']; 
		?>
			<input type="hidden" class="form-control" name="id" value="<?php echo $id; ?>">
			<div class="form-group">
				<label for="recipient-name" class="col-form-label">Enter Message :</label>
				<textarea class="form-control" required name="message"></textarea>
			</div>
			
		<?php
	}
	
?>