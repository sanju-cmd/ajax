<?php 
	require '../../Admin/init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
		    
			$name =$_POST['name'];
			$nm=strtolower($name);
			$n=base64_encode($nm);
			$vendor_id = $_POST['vendor_id'];
			$category = $_POST['category'];
			$sub_category = $_POST['sub_category'];
			$brand = $_POST['brand'];
			$meta_tag_title = $_POST['meta_tag_title'];
			$meta_tag_description = base64_encode($_POST['meta_tag_description']);
			$meta_tag_keywords = $_POST['meta_tag_keywords'];
			$sdescription = base64_encode($_POST['sdescription']);
			$product_tags = $_POST['product_tags'];
			$exp_date=$_POST['exp_date'];
			//$tax_id=$_POST['tax_id'];
			if(empty($name)||empty($brand)||empty($category)||empty($sub_category)||empty($sdescription) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `product` (name,vendor_id,category,sub_category,brand,meta_tag_title,meta_tag_description,meta_tag_keywords,sdescription,product_tags,expiry_date,date,time,status) VALUES('$n','$vendor_id','$category','$sub_category','$brand','$meta_tag_title','$meta_tag_description','$meta_tag_keywords','$sdescription','$product_tags','$exp_date','$date','$time','false')");
				if($sel){
					$product_id = $source->LastId();
					$_SESSION['product_id']=$product_id;
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'Variant'));
						
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		


		case 'AddVariant':
			
			$url=$_POST['url'];
			if(empty($url)){
					$url="Variant";
			}
			$product_id = $_POST['product_id'];
			$model = $_POST['model'];
			$quantity = $_POST['quantity'];
			$unit = $_POST['unit'];
			$stock = $_POST['stock'];
			$tax = $_POST['tax'];
			$mrp = $_POST['mrp'];
			$price = $_POST['price'];
			$discount = $_POST['discount'];
			$order_limit = $_POST['order_limit'];
			$min_order_limit=$_POST['min_order_limit'];
			if(empty($model)|| empty($mrp) || empty($price) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
			
				$sel=$source->Query("INSERT INTO `tbl_product_details` (product_id,model,quantity,unit,stock,tax,mrp,price,discount,order_limit,date,time,min_order_limit) VALUES('$product_id','$model','$quantity','$unit','$stock','$tax','$mrp','$price','$discount','$order_limit','$date','$time','$min_order_limit')");
				if($sel){
					$_SESSION['product_id']=$product_id;
					
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>$url));
					
						
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'UpdateVariant':
		
			$variant_id = $_POST['variant_id'];
			$model = $_POST['model'];
			$quantity = $_POST['quantity'];
			$unit = $_POST['unit'];
			$stock = $_POST['stock'];
			$tax = $_POST['tax'];
			$mrp = $_POST['mrp'];
			$price = $_POST['price'];
			$discount = $_POST['discount'];
			$order_limit = $_POST['order_limit'];
			$min_order_limit=$_POST['min_order_limit'];
			$commission=$_POST['commission'];
			if(empty($model) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("UPDATE `tbl_product_details` SET `model` = '$model', `quantity` = '$quantity', `unit` = '$unit', `stock` = '$stock', `mrp` = '$mrp', `price` = '$price', `discount` = '$discount', `tax` = '$tax', `order_limit` = '$order_limit',`min_order_limit` = '$min_order_limit',`commission` = '$commission', `date` = '$date', `time` = '$time' WHERE `tbl_product_details`.`id` = '$variant_id'");
				if($sel){
					echo json_encode(array('res' =>'success' ,'msg'=>'Update Success','url'=>'UpdateVariantList?id='.$_SESSION['update_varient']));
					
						
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		



		case 'AddAttribute':
		    $url=$_POST['url'];
			if(empty($url)){
					$url="Attributes";
			}
			$product_id = $_POST['product_id'];
			$name = $_POST['name'];
			$text = $_POST['text'];
			
			
			if(empty($name) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `tbl_attribute` (product_id,name,text,date) VALUES('$product_id','$name','$text','$date')");
				if($sel){
					$_SESSION['product_id']=$product_id;
					
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>$url));
					
						
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

	case 'UpdateAttribute':

			$id = $_POST['id'];
			$name = $_POST['name'];
			$text = $_POST['text'];
			
			
			if(empty($name) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("UPDATE `tbl_attribute` SET name='$name',text='$text' WHERE id='$id'");
				if($sel){
					echo json_encode(array('res' =>'success' ,'msg'=>'Update Success','url'=>'UpdateAttributeList?id='.$_SESSION['update_varient']));
					
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		


		

		case 'AddImages':
		    $url=$_POST['url'];
			if(empty($url)){
					$url="Images";
			}
			$product_id = $_POST['product_id'];
			$image="Product_".date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
	
			if(empty($image)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `product_images` (product_id,image,delete_status,date) VALUES('$product_id','$image','false','$date')");
				if($sel){
					$_SESSION['product_id']=$product_id;
					 move_uploaded_file($_FILES['image']['tmp_name'],"../../API/v1/uploads/products/".$image);
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>$url));
						
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		
		
		case 'Update':
		
			$id = $_POST['id'];
			$name = base64_encode($_POST['name']);
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `tbl_category` SET `name`=?,  `date`=?, `time`=? WHERE `id`=?",[$name,$date,$time,$id]);
				
				if($res){
						if(!empty($_FILES['image']['name'])){
                        $image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image']['tmp_name'],"../upload/category/".$image);
                        $source->Query("UPDATE `tbl_category` SET `image`='$image' WHERE `id`='$id'");
						}
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageCategory'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}
			



		break;			
		
		
		case 'UpdateProduct':
				
			$name = $_POST['name'];
			$pname=strtolower($name);
			$pn=base64_encode($pname);
			//$vendor_id = $_POST['vendor_id'];
			$product_id = $_POST['product_id'];
			$category = $_POST['category'];
			$sub_category = $_POST['sub_category'];
			$brand = $_POST['brand'];
			$meta_tag_title = $_POST['meta_tag_title'];
			$meta_tag_description = base64_encode($_POST['meta_tag_description']);
			$meta_tag_keywords = $_POST['meta_tag_keywords'];
			$sdescription = base64_encode($_POST['sdescription']);
			$product_tags = $_POST['product_tags'];
			$exp_date=$_POST['exp_date'];
			//`vendor_id` = '$vendor_id',
			
			$sel=$source->Query("UPDATE `product` SET  `name` = '$pn', `category` = '$category', `sub_category` = '$sub_category', `brand` = '$brand', `meta_tag_title` = '$meta_tag_title', `meta_tag_description` = '$meta_tag_description', `meta_tag_keywords` = '$meta_tag_keywords', `product_tags` = '$product_tags', `sdescription` = '$sdescription', `expiry_date` = '$exp_date' WHERE `id` = '$product_id'");
			
			if($sel){
				$product_id = $source->LastId();
				$_SESSION['product_id']=$product_id;
				echo json_encode(array('res' =>'success' ,'msg'=>'Update Success','url'=>'AllProduct'));
					
			}else{
				echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
			}
			
			break;
		
		default:
			# code...
			break;
	}
	
 ?>