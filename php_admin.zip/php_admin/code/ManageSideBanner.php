<?php 


	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
			case 'Update':
		
			$id = 1;
			$link=$_POST['link'];
			$link2=$_POST['link2'];
			$link3=$_POST['link3'];
			$link4=$_POST['link4'];
			$link5=$_POST['link5'];
			
			
			if(empty($id) or empty($link)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `side_banner` SET `link`=?,`link2`=?,`link3`=?,`link4`=?,`link5`=?,`date`=?, `time`=? WHERE `id`=?",[$link,$link2,$link3,$link4,$link5,$date,$time,$id]);
				
				if($res){
						if(!empty($_FILES['image1']['name'])){
                        $image1=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image1']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image1']['tmp_name'],"../upload/sidebanner/".$image1);
                        $source->Query("UPDATE `side_banner` SET `image1`='$image1' WHERE `id`='$id'");
						}
						
						if(!empty($_FILES['image2']['name'])){
                        $image2=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image2']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image2']['tmp_name'],"../upload/sidebanner/".$image2);
                        $source->Query("UPDATE `side_banner` SET `image2`='$image2' WHERE `id`='$id'");
						}	
						
						if(!empty($_FILES['image3']['name'])){
                        $image3=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image3']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image3']['tmp_name'],"../upload/sidebanner/".$image3);
                        $source->Query("UPDATE `side_banner` SET `image3`='$image3' WHERE `id`='$id'");
						}
						if(!empty($_FILES['image4']['name'])){
                        $image4=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image4']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image4']['tmp_name'],"../upload/sidebanner/".$image4);
                        $source->Query("UPDATE `side_banner` SET `image4`='$image4' WHERE `id`='$id'");
						}
						if(!empty($_FILES['image5']['name'])){
                        $image5=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image5']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image5']['tmp_name'],"../upload/sidebanner/".$image5);
                        $source->Query("UPDATE `side_banner` SET `image5`='$image5' WHERE `id`='$id'");
						}
						
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'UpdateSideBanner'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;


		default:
			# code...
			break;
	}
	
 ?>