<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
		    $referal=$_POST['referal'];
			$shopname=$_POST['shopname'];
			$name = $_POST['name'];
			$oname=$_POST['oname'];
			$email = $_POST['email'];
			$mobile = $_POST['mobile'];
			$password = $_POST['password'];
			$gst = $_POST['gst'];
			$adharcard = $_POST['adharcard'];
			$pancard = $_POST['pancard'];
			$accountname = $_POST['accountname'];
			$ifsccode = $_POST['ifsccode'];
			$a_holder = $_POST['a_holder'];
			$shopaddress = $_POST['shopaddress'];
			$address = $_POST['address'];
			$state = $_POST['state'];
			$city = $_POST['city'];
			$pincode = $_POST['pincode'];
			$image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			
			if(empty($name) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `tbl_vendor`(referal,shopname,`name`,`oname`,`email`,`mobile`,`password`,`gst`,`adharcard`,`pancard`,`accountname`,`ifsccode`,`a_holder`,`shopaddress`,`address`,`state`,`city`,`pincode`,`image`,`date`,`time`) VALUES('$referal','$shopname','$name','$oname','$email','$mobile','$password','$gst','$adharcard','$pancard','$accountname','$ifsccode','$a_holder','$shopaddress','$address','$state','$city','$pincode','$image','$date','$time')");	
				if($sel){
					$last_id = $source->LastId();
					$source->Query("UPDATE `tbl_vendor` SET sponsorID='ADV001$last_id' WHERE `id`='$last_id'");
					 move_uploaded_file($_FILES['image']['tmp_name'],"../../API/v1/uploads/Vendor/".$image);
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'AddVendor'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'Update':
		    
			$id = $_POST['id'];
			$shopname=$_POST['shopname'];
			$name = $_POST['name'];
			$oname=$_POST['oname'];
			$email = $_POST['email'];
			$mobile = $_POST['mobile'];
			$gst = $_POST['gst'];
			$adharcard = $_POST['adharcard'];
			$pancard = $_POST['pancard'];
			$accountname = $_POST['accountname'];
			$shopaddress = $_POST['shopaddress'];
			$address = $_POST['address'];
			$state = $_POST['state'];
			$city = $_POST['city'];
			$pincode = $_POST['pincode'];
			$ifsccode = $_POST['ifsccode'];
			$a_holder = $_POST['a_holder'];
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `tbl_vendor` SET `shopname`=?, `name`=?,`oname`=?, `email`=?, `mobile`=?, `gst`=?,`adharcard`=?,`pancard`=?,`accountname`=?,`address`=?,`shopaddress`=?,`state`=?,`city`=?,`pincode`=?,`ifsccode`=?,`a_holder`=?,  `date`=?, `time`=? WHERE `id`=?",[$shopname,$name,$oname,$email,$mobile,$gst,$adharcard,$pancard,$accountname,$address,$shopaddress,$state,$city,$pincode,$ifsccode,$a_holder,$date,$time,$id]);
				
				if($res){
						if(!empty($_FILES['image']['name'])){
                        $image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image']['tmp_name'],"../../API/v1/uploads/Vendor/".$image);
                        $source->Query("UPDATE `tbl_vendor` SET `image`='$image' WHERE `id`='$id'");
						}
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageVendor'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;			
		
		default:
			# code...
			break;
	}
	
 ?>