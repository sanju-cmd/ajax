<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'logo_update':
			if(!empty($_FILES['image']['name'])){
			$image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			move_uploaded_file($_FILES['image']['tmp_name'],"../upload/banner/".$image);
			$source->Query("UPDATE `settings` SET `value`='$image' WHERE `name`='logo'");
			}
			echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'WebSettings'));
		break;		
		case 'link_update':
			$marquee=$_POST['marquee'];
			$facebook=$_POST['facebook'];
			$twitter=$_POST['twitter'];
			$instagram=$_POST['instagram'];
			$youtube=$_POST['youtube'];
			$applink=$_POST['app'];
			$links=$facebook.'ZPS'.$twitter.'ZPS'.$instagram.'ZPS'.$youtube.'ZPS'.$applink;
			$source->Query("UPDATE `settings` SET `value`='$links' WHERE `name`='links'");
			$source->Query("UPDATE `settings` SET `value`='$marquee' WHERE `name`='heading'");
			echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'WebSettings'));
			
		break;		
		
		
		default:
			# code...
			break;
	}
	
 ?>