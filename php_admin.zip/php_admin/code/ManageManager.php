<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
			$name = $_POST['name'];
			$email = $_POST['email'];
			$mobile = $_POST['mobile'];
			//$password = $_POST['password'];
			$adhar = $_POST['adhar'];
			$pancard = $_POST['pancard'];
			$address = $_POST['address'];
			$assigncity = $_POST['assigncity'];
			$assignstate = $_POST['assignstate'];
			$joining_date = $_POST['joining_date'];
			$image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			$adhar_image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			$pancard_image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			
			
			if(empty($name) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `tbl_manager`(`name`,`email`,`mobile`,`adhar`,`pancard`,`address`,`assigncity`,`assignstate`,`joiningdate`,`adhar_image`,`pan_image`,`image`,`date`,`time`) VALUES('$name','$email','$mobile','$adhar','$pancard','$address','$assigncity','$assignstate','$joining_date','$adhar_image','$pancard_image','$image','$date','$time')");	
				if($sel){
					$last_id = $source->LastId();
					$source->Query("UPDATE `tbl_manager` SET sponsorID='ADM001$last_id' WHERE `id`='$last_id'");
					 move_uploaded_file($_FILES['image']['tmp_name'],"../../API/v1/uploads/manager/".$image);
					  move_uploaded_file($_FILES['adhar_image']['tmp_name'],"../../API/v1/uploads/adhar/".$adhar_image);
					   move_uploaded_file($_FILES['pancard_image']['tmp_name'],"../../API/v1/uploads/pancard/".$pancard_image);
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'AddManager'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'Update':
		
			$id = $_POST['id'];
			$name = $_POST['name'];
			$email = $_POST['email'];
			$mobile = $_POST['mobile'];
			$adhar = $_POST['adhar'];
			$pancard = $_POST['pancard'];
			$address = $_POST['address'];
			$assigncity = $_POST['assigncity'];
			$assignstate = $_POST['assignstate'];
			$joining_date = $_POST['joining_date'];
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `tbl_manager` SET `name`=?, `email`=?, `mobile`=?,  `adhar=?`,`pancard=?`,`address=?`,`assigncity=?`,`assignstate=?`,`joining_date=?`,`date`=?, `time`=? WHERE `id`=?",[$name,$email,$mobile,$adhar,$pancard,$address,$assigncity,$assignstate,$joining_date,$date,$time,$id]);
				
				if($res){
						if(!empty($_FILES['image']['name'])){
                        $image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image']['tmp_name'],"../../API/v1/uploads/manager/".$image);
                        $source->Query("UPDATE `tbl_manager` SET `image`='$image' WHERE `id`='$id'");
						}
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageManager'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;			
		
		default:
			# code...
			break;
	}
	
 ?>