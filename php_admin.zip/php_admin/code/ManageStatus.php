<?php 

	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
			
		case 'ChangeOrderStatus':
            $id=$_POST['id'];
			$status=$_POST['status'];
			
            if(empty($id) or empty($status)){
                $output = array('res' => 'error', 'msg'=>'All field require ');
				echo json_encode($output);
            }
            else{
				if($status==4){
					
					
					
					
					
					$source->Query("SELECT * FROM `Orders` WHERE `id`=?",[$id]);
					$values=$source->Single();
					
					$variant_id=$values->variant_id;
					$qty=$values->qty;
					
					$qty=explode(",",$qty);
					$v_id=explode(",",$variant_id);
					$commission=0;
					$price=0;
					for($i=0;$i<count($v_id);$i++)
					{
					
						$source->Query("SELECT * FROM tbl_product_details WHERE id='".$v_id[$i]."'");
						$product_data=$source->Single();	
						
						$sale=$product_data->sale;
						
						$source->Query("UPDATE tbl_product_details SET sale=".$sale+$qty[$i]." WHERE id='".$v_id[$i]."'");
						if(empty($product_data->commission)){
							$com_1=0;
						}else{
							$com_1=$product_data->commission;
						}
						$commission+=$com_1;
						$price+=($product_data->price)*($qty[$i]); 
						
					}
					
					$commission=$commission/count($v_id);
					$ven_com=$price*$commission/100;
					$amount=$price-$ven_com;
					
					$source->Query("SELECT * FROM tbl_vendor WHERE id='$values->vendor_id'");
					$ven_data=$source->Single();
					$old_amount=$ven_data->wallet;
					$new_amount=$old_amount+$amount;
					
					$source->Query("UPDATE tbl_vendor SET wallet='$new_amount' WHERE id='$values->vendor_id'");
						
					$res=$source->Query("UPDATE `Orders` SET `status`='$status' WHERE `id`='$id'");
					if($res){	
						$output = array('res' => 'success', 'msg'=>'Status Updated');
						echo json_encode($output);
					}
					else{
						$output = array('res' => 'error', 'msg'=>'Failed ');
						echo json_encode($output);
					}
					
					// die();
					
				}else{
					$res=$source->Query("UPDATE `Orders` SET `status`='$status' WHERE `id`='$id'");
					if($res){	
						$output = array('res' => 'success', 'msg'=>'Status Updated');
						echo json_encode($output);
					}
					else{
						$output = array('res' => 'error', 'msg'=>'Failed ');
						echo json_encode($output);
					}
				}
            }
			
            break;
		
		// Vendor
			case 'UserWithdrawal':
            $id =$_POST['id'];
            $user_id =$_POST['user_id'];
            $column =$_POST['column'];
            $value =$_POST['value'];
            $table =$_POST['table'];
            $amount =$_POST['amount'];
			$source->Query("SELECT * FROM `tbl_user` WHERE `id`='$user_id'");
			$wallet=$source->Single()->wallet;
			if($wallet>$amount){
			
			
			$msg="Your wallet is debits of ₹$amount because you requested to withdrawal!";
			$updatewallet=$wallet-$amount;
			$milliseconds = 1000 * strtotime($time);
            if(empty($id) or empty($column) or empty($value) or empty($table)){
                echo "Fill";
            }
            else{
				if($value=="Accepted"){
				$source->Query("UPDATE `tbl_user` SET `wallet`='$updatewallet' WHERE `id`='$user_id'");
				
				$source->Query("INSERT INTO `txn_tbl` (txn_id,user_id,amount,msg,txn_type,user_type,date,time)VALUES('$milliseconds','$user_id','$amount','$msg','Debit','User','$date','$time')");
				
                $res=$source->Query("UPDATE `$table` SET `$column`='$value' WHERE `id`='$id'");
              
                if($res){
                    echo "Success";
                }
                else{
                    echo "Falied";
                }
				}
		}}
		else{
			$source->Query("UPDATE `$table` SET `$column`='Rejected' WHERE `id`='$id'");
			echo "Falied";
			
		}
            break;
			
// Vendor
			case 'VendorWithdrawal':
            $id =$_POST['id'];
            $user_id =$_POST['user_id'];
            $column =$_POST['column'];
            $value =$_POST['value'];
            $table =$_POST['table'];
            $amount =$_POST['amount'];
			$source->Query("SELECT * FROM `tbl_vendor` WHERE `id`='$user_id'");
			$wallet=$source->Single()->wallet;
			if($wallet>$amount){
			
			
			$msg="Your wallet is debits of ₹$amount because you requested to withdrawal!";
			$updatewallet=$wallet-$amount;
			$milliseconds = 1000 * strtotime($time);
            if(empty($id) or empty($column) or empty($value) or empty($table)){
                echo "Fill";
            }
            else{
				if($value=="Accepted"){
				$source->Query("UPDATE `tbl_vendor` SET `wallet`='$updatewallet' WHERE `id`='$user_id'");
				
				$source->Query("INSERT INTO `txn_tbl` (txn_id,user_id,amount,msg,txn_type,user_type,date,time)VALUES('$milliseconds','$user_id','$amount','$msg','Debit','Vendor','$date','$time')");
				
                $res=$source->Query("UPDATE `$table` SET `$column`='$value' WHERE `id`='$id'");
              
                if($res){
                    echo "Success";
                }
                else{
                    echo "Falied";
                }
				}
		}}
		else{
			$source->Query("UPDATE `$table` SET `$column`='Rejected' WHERE `id`='$id'");
			echo "Falied";
			
		}
            break;
// Vendor
			case 'ManagerWithdrawal':
            $id =$_POST['id'];
            $user_id =$_POST['user_id'];
            $column =$_POST['column'];
            $value =$_POST['value'];
            $table =$_POST['table'];
            $amount =$_POST['amount'];
			$source->Query("SELECT * FROM `tbl_manager` WHERE `id`='$user_id'");
			$wallet=$source->Single()->wallet;
			if($wallet>$amount){
			
			
			$msg="Your wallet is debits of ₹$amount because you requested to withdrawal!";
			$updatewallet=$wallet-$amount;
			$milliseconds = 1000 * strtotime($time);
            if(empty($id) or empty($column) or empty($value) or empty($table)){
                echo "Fill";
            }
            else{
				if($value=="Accepted"){
				$source->Query("UPDATE `tbl_manager` SET `wallet`='$updatewallet' WHERE `id`='$user_id'");
				
				$source->Query("INSERT INTO `txn_tbl` (txn_id,user_id,amount,msg,txn_type,user_type,date,time)VALUES('$milliseconds','$user_id','$amount','$msg','Debit','Manager','$date','$time')");
				
                $res=$source->Query("UPDATE `$table` SET `$column`='$value' WHERE `id`='$id'");
              
                if($res){
                    echo "Success";
                }
                else{
                    echo "Falied";
                }
				}
		}}
		else{
			$source->Query("UPDATE `$table` SET `$column`='Rejected' WHERE `id`='$id'");
			echo "Falied";
			
		}
            break;

			//Delete
			
			case 'Delete':
            $id = $_POST['id'];
            $column = $_POST['column'];
            $value = $_POST['value'];
			
            $table = $_POST['table'];
            if(empty($id) or empty($column) or empty($value) or empty($table)){
                echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
            }
            else{
                $res=$source->Query("UPDATE `$table` SET `$column`=? WHERE `id`=?",[$value,$id]);
               
                if($res){
                    echo "Success";
                }
                else{
                    echo "Falied";
                }
            }
            break;
			case 'DeleteAllData':
            $id = $_POST['id'];
            $column = $_POST['column'];
            $value = $_POST['value'];
			
            $table = $_POST['table'];
            if(empty($id) or empty($column) or empty($value) or empty($table)){
                echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
            }
            else{
                $res=$source->Query("DELETE FROM `$table` WHERE `id`='$id'");
               
                if($res)
			   {
				    $output = array('res' => 'success', 'msg'=>'Deleted  Successfull');
					echo json_encode($output);
			   } 
			   else{
				    $output = array('res' => 'error', 'msg'=>'Failed ');
					echo json_encode($output);
			   }
            }
            break;
			
           case 'Delete1':
            $id = $_POST['id'];
            $column = $_POST['column'];
            $value = $_POST['value'];
            $table = $_POST['table'];
            if(empty($id)){
                echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
            }
            else{
                // $res=$source->Query("DELETE FROM `product` WHERE `id`=?",[$id]);
                // $source->Query("DELETE FROM `tbl_product_details` WHERE `product_id`=?",[$id]);
                // $source->Query("DELETE FROM `product_images` WHERE `product_id`=?",[$id]);
                $res=$source->Query("DELETE FROM `$table` WHERE `id`=?",[$id]);
               
                if($res)
			   {
                    echo "Success";
			   } 
			   else{
				    $output = array('res' => 'error', 'msg'=>'Failed ');
					echo json_encode($output);
			   }
            }
            break;
			
			
			case 'DeleteImage':
            $id = $_POST['id'];
			
             $column = $_POST['column'];
             $value = $_POST['value'];
             $table = $_POST['table'];
            if(empty($id)){
                echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
            }
            else{
                //$res=$source->Query("DELETE FROM `product` WHERE `id`=?",[$id]);
                //$source->Query("DELETE FROM `tbl_product_details` WHERE `product_id`=?",[$id]);
                 $res=$source->Query("delete from `product_images` WHERE `id`=?",[$id]);
               // $source->Query("DELETE FROM `tbl_attribute` WHERE `product_id`=?",[$id]);
               
                if($res){
					echo 'Success';
                }
				else{
                    $output = array('res' => 'error', 'msg'=>'Failed ');
					echo json_encode($output);
                }
			}
			
            break;
			
			
			case 'DeleteVariant':
            $id = $_POST['id'];
			
             $column = $_POST['column'];
             $value = $_POST['value'];
             $table = $_POST['table'];
            if(empty($id)){
                echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
            }
            else{
                //$res=$source->Query("DELETE FROM `product` WHERE `id`=?",[$id]);
                //$source->Query("DELETE FROM `tbl_product_details` WHERE `product_id`=?",[$id]);
                 $res=$source->Query("DELETE from `tbl_product_details` WHERE `id`=?",[$id]);
               // $source->Query("DELETE FROM `tbl_attribute` WHERE `product_id`=?",[$id]);
               
                if($res){
					echo 'Success';
                }
				else{
                    $output = array('res' => 'error', 'msg'=>'Failed ');
					echo json_encode($output);
                }
			}
			
            break;
			
			
			case 'delivery_boy_status':
			   $o_id=$_POST['id'];
			   $db_id=$_POST['delivery'];
			   
			   $res=$source->Query("UPDATE `Orders` SET `delivery_boy_status` = 'Accepted' , `delivery_boy`='".$db_id."' WHERE `id`='".$o_id."'");
			   if($res)
			   {
				    $output = array('res' => 'success', 'msg'=>'Delivery Boy Assigned Successfull');
					echo json_encode($output);
			   } 
			   else{
				    $output = array('res' => 'error', 'msg'=>'Failed ');
					echo json_encode($output);
			   }
			
			
			
			break;
			
			
		case 'ServiceStatus':
		
			$id=$_POST['id'];
			$res=$source->Query("UPDATE `order_service` SET `status`='4' WHERE `id`=?",[$id]);
			echo 'Success';
			break;

		default:
			# code...
			break;
	}







 ?>