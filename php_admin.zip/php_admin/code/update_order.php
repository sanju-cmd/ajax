<?php 

	require '../init.php';
	
	        $id = $_POST['id'];
            $column = $_POST['column'];
            $value =$_POST['value'];
            $table = $_POST['table'];
            if(empty($id) or empty($column) or empty($value) or empty($table)){
                echo "Fill";
            }
           else{
				
				$source->Query("SELECT * FROM `Orders` WHERE `id`='$id'");
				$data=$source->Single();
				
				if($data){
					// User's Commission
					$user_id=$data->user_id;
					$source->Query("SELECT * FROM `tbl_user` WHERE `id`='$user_id'");
					$data_user=$source->Single();
					if($data_user){
						$a=[];
						function upline_list($sponsorID){
							global $a;
							global $source;
							$source->Query("SELECT * FROM `tbl_user` WHERE `sponsorID`='$sponsorID'");
							$upline=$source->Single();
							if($upline)
							{
								$referral_id=$upline->referral_id;
								if(!empty($referral_id))
								{
									array_push($a,$referral_id);
									
								 	return upline_list($referral_id);
								}
								else
								{
									return $a;
								}
								
							}
						}
						$referral_id=$data_user->sponsorID;
						$list=upline_list($referral_id);
						$totalCount=count($list);
						$upline_commission=[];
						$sr=1;
						$l=1;
						$order_price=$data->total_price;
						for($i=0;$i<$totalCount;$i++){
							if($sr>20){
								$sr=20;
							}
							$source->Query("SELECT level,commission FROM level_commission WHERE id='$sr' ");
							$commission=$source->Single();
							$commission_amount=20;
							$commissionAmount=$order_price*$commission_amount/100;
							// $commissionAmount=number_format($commissionAmount ,2);
							array_push($upline_commission,$commissionAmount);
							$order_price=$commissionAmount;
							$sr++;
						}
						$sr=1;
						for($i=0;$i<$totalCount;$i++){
							$a=(int)$upline_commission[$i];
							$b=(int)$upline_commission[$sr]; 
							$amount = $a-$b;   
							$upline=$list[$i]; 
							$source->Query("SELECT id,wallet,commission FROM tbl_user WHERE sponsorID='$upline'");
							$res4=$source->Single();
							$total_wallet=$res4->wallet+$amount; 
							$total_commission=$res4->commission+$amount;
							$order_price=$amount;
							$source->Query("UPDATE tbl_user SET wallet='$total_wallet' , commission='$total_commission' WHERE id=?",[$res4->id]); 
							$tnxId=time()+mt_rand();
							$message="Commission Amount $amount Credit , UserId : ".$data_user->id." , Name : ".$data_user->name."  ";
							$source->Query("INSERT INTO `txn_tbl` (`id`, `txn_id`, `user_id`, `user_type`, `amount`, `msg`, `txn_type`, `date`, `time`) VALUES (NULL, '$tnxId', '".$res4->id."', 'User', '$amount', '$message', 'Credit', '$date', '$time')");
							$source->Query("INSERT INTO `txn_commission` (`id`, `txn_id`, `user_id`, `user_type`, `amount`, `msg`, `date`, `time`) VALUES (NULL, '$tnxId', '".$res4->id."', 'User', '$amount', '$message', '$date', '$time')");
							$sr++;
						}
					}
					// Vendor Commission
					$vendor_id=$data->vendor_id;
					$commission_vendor=[];
					$source->Query("SELECT * FROM `tbl_vendor` WHERE `id`='$vendor_id'");
					$data_vendor=$source->Single();
					if($data_vendor){
						$product_id=$data->product_id;
						$product_id=explode(",",$product_id);
						for($i=0;$i<count($product_id);$i++){
							$source->Query("SELECT *,(SELECT id FROM tbl_category c WHERE c.id=p.category ) as commission  FROM product p where id=?",[$product_id[$i]]);
							$category_data=$source->Single();
							array_push($commission_vendor,$category_data->commission);
						}
						$dups = array_unique($commission_vendor);
						$commission_vendor=[];
						for($i=0;$i<count($dups);$i++){
							$source->Query("SELECT * FROM tbl_category WHERE id=?",[$dups[$i]]);
							$category_data=$source->Single();
							array_push($commission_vendor,$category_data->scommission);
						}
						$order_price=$data->total_price;
						$total_sum=array_sum($commission_vendor)/count($commission_vendor);
						$ven_comm=$order_price*$total_sum/100;
						$vendor_order_amount=$order_price-$ven_comm;
						$totalAmount=$vendor_order_amount+$data_vendor->wallet;
						$source->Query("UPDATE tbl_vendor SET wallet='$totalAmount' WHERE id='$vendor_id'");
						$tnxId=time()+mt_rand();
						$message="Order Amount $vendor_order_amount Credit , UserId : ".$data_user->id." , Name : ".$data_user->name."  ";
						$source->Query("INSERT INTO `txn_tbl` (`id`, `txn_id`, `user_id`, `user_type`, `amount`, `msg`, `txn_type`, `date`, `time`) VALUES (NULL, '$tnxId', '".$data_user->id."', 'Vendor', '$vendor_order_amount', '$message', 'Credit', '$date', '$time')");
						//Vendor Order Amount 
						$a=[];
						function upline_list_1($sponsorID){
							global $a;
							global $source;
							$source->Query("SELECT * FROM `tbl_vendor` WHERE `sponsorID`='$sponsorID'");
							$upline=$source->Single();
							if($upline)
							{
								$referral_id=$upline->referral_id;
								if(!empty($referral_id))
								{
									array_push($a,$referral_id);
									
								 	return upline_list_1($referral_id);
								}
								else
								{
									return $a;
								}
								
							}
						}
						$referral_id=$data_vendor->sponsorID;
						$list=upline_list_1($referral_id);
						$totalCount=count($list);
						$upline_commission=[];
						$sr=1;
						$l=1;
						$order_price=$data->total_price;
						for($i=0;$i<$totalCount;$i++){
							if($sr>20){
								$sr=20;
							}
							$source->Query("SELECT level,commission FROM level_commission WHERE id='$sr' ");
							$commission=$source->Single();
							$commission_amount=20;
							$commissionAmount=$order_price*$commission_amount/100;
							// $commissionAmount=number_format($commissionAmount ,2);
							array_push($upline_commission,$commissionAmount);
							$order_price=$commissionAmount;
							$sr++;
						}
						$sr=1;
						for($i=0;$i<$totalCount;$i++){
							$a=(int)$upline_commission[$i];
							$b=(int)$upline_commission[$sr]; 
							$amount = $a-$b;   
							$upline=$list[$i]; 
							$source->Query("SELECT id,wallet,commission FROM tbl_vendor WHERE sponsorID='$upline'");
							$res4=$source->Single();
							$total_wallet=$res4->wallet+$amount; 
							$total_commission=$res4->commission+$amount;
							$order_price=$amount;
							$source->Query("UPDATE tbl_vendor SET wallet='$total_wallet' , commission='$total_commission' WHERE id=?",[$res4->id]); 
							$tnxId=time()+mt_rand();
							$message="Commission Amount $amount Credit , UserId : ".$data_user->id." , Name : ".$data_user->name."  ";
							$source->Query("INSERT INTO `txn_tbl` (`id`, `txn_id`, `user_id`, `user_type`, `amount`, `msg`, `txn_type`, `date`, `time`) VALUES (NULL, '$tnxId', '".$res4->id."', 'Vendor', '$amount', '$message', 'Credit', '$date', '$time')");
							$source->Query("INSERT INTO `txn_commission` (`id`, `txn_id`, `user_id`, `user_type`, `amount`, `msg`, `date`, `time`) VALUES (NULL, '$tnxId', '".$res4->id."', 'Vendor', '$amount', '$message', '$date', '$time')");
							$sr++;
						}
					}
					$source->Query("UPDATE Orders SET status='4' WHERE id='$id'");
					echo 'Success';
				}
            }
 ?>