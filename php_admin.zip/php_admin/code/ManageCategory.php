<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
			$name = base64_encode($_POST['name']);
			//$tax_id = $_POST['tax_id'];
			$image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			
			if(empty($name) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `tbl_category` (`name`,`image`,`date`, `time`) VALUES ('$name','$image','$date', '$time')");	
				if($sel){
					 move_uploaded_file($_FILES['image']['tmp_name'],"../upload/category/".$image);
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'AddCategory'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'Update':
		
			$id = $_POST['id'];
			$name = base64_encode($_POST['name']);
			//$mcommission = $_POST['mcommission'];
			//$ucommission = $_POST['ucommission'];
			//$scommission = $_POST['scommission'];
			$tax_id = $_POST['tax_id'];
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `tbl_category` SET `name`='$name',`date`='$date', `time`='$time' WHERE `id`='$id'");
				
				if($res){
						if(!empty($_FILES['image']['name'])){
                        $image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image']['tmp_name'],"../upload/category/".$image);
                        $source->Query("UPDATE `tbl_category` SET `image`='$image' WHERE `id`='$id'");
						}
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageCategory'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}
 

		break;			
		
		default:
			# code...
			break;
	}
	
 ?>