<?php
	
	require '../init.php';
	$id=$_REQUEST['id'];
	$source->Query("SELECT * FROM `Orders` WHERE `id`=?",[$id]);
	$values=$source->Single();
	
	$variant_id=$values->variant_id;
	$qty=$values->qty;
	
	$qty=explode(",",$qty);
	$v_id=explode(",",$variant_id);
	$commission=0;
	$price=0;
	for($i=0;$i<count($v_id);$i++)
	{
		
		$source->Query("SELECT * FROM tbl_product_details WHERE id='".$v_id[$i]."'");
		$product_data=$source->Single();	
		$commission+=$product_data->commission;
		$price+=$product_data->price*$qty[$i]; 
		
	}
	
	// $commission=$commission/count($v_id);
	// $ven_com=$price*$commission/100;
	// $amount=$price-$ven_com;
	
	$source->Query("SELECT * FROM tbl_vendor WHERE id='$values->vendor_id'");
	$ven_data=$source->Single();
	var_dump($ven_data);
	// $old_amount=$ven_data->wallet;
	// $new_amount=$old_amount+$amount;
	
	// $source->Query("UPDATE tbl_vendor SET wallet='$new_amount' WHERE id='$values->vendor_id'");
	
	
	
?>