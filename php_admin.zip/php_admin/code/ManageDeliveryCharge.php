<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
			$amount = $_POST['amount'];
			$limits = $_POST['limits'];
			
			if(empty($amount) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `delivery_charge` (`id`, `amount`, `limits`, `date`, `time`) VALUES (NULL, '$amount', '$limits', '$date', '$time');");	
                if($sel)
				{
				echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'ManageDeliveryCharge'));
				}
			
				else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'Update':
		
			$id = $_POST['id'];
			$amount = $_POST['amount'];
			$limits = $_POST['limits'];
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `delivery_charge` SET `amount`=?,`limits`=?,  `date`=?, `time`=? WHERE `id`=?",[$amount,$limits,$date,$time,$id]);
				
				if($res){
						

					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageDeliveryCharge'));
						
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
	}


		break;			
		case 'CommissionDeliveryBoy':
			
			$commission=$_POST['commission'];
			$source->Query("UPDATE `settings` SET `value` = '$commission' WHERE `settings`.`name` = 'delivery_boy'");
			echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'CommissionDeliveryBoy'));
			
		break;
		default:
			# code...
			break;
	}
	
 ?>