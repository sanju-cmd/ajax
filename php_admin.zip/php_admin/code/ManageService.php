<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
		
			$name = base64_encode($_POST['name']);
			$category_id = $_POST['category_id'];
			$subcategory = $_POST['subcategory'];
			$property = $_POST['property'];
			$description = base64_encode($_POST['description']);
			$price = $_POST['price'];
			$image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			
			if(empty($name) ||empty($description)||empty($category_id)||empty($subcategory)||empty($price)){
				
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
				
			}else{
				
				$sel=$source->Query("INSERT INTO `tbl_services` (`cat_id`,`name`,`subcategory`,`description`,`price`,`attribute`,`image`,`date`) VALUES ('$category_id','$name','$subcategory','$description','$price','$property','$image','$date')");	
				if($sel){
					 move_uploaded_file($_FILES['image']['tmp_name'],"../upload/service/".$image);
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'AddService'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}

		break;		

		case 'Update':
		
			$id = $_POST['id'];
			$name = base64_encode($_POST['name']);
			$category_id = $_POST['category_id'];
			$property = $_POST['property'];
			$description = base64_encode($_POST['description']);
			$price = $_POST['price'];
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `tbl_services` SET `cat_id`=?, `name`=?,  `description`=?,  `price`=?,  `attribute`=?,  `date`=? WHERE `id`=?",[$category_id,$name,$description,$price,$property,$date,$id]);
				
				if($res){
						if(!empty($_FILES['image']['name'])){
                        $image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image']['tmp_name'],"../upload/service/".$image);
                        $source->Query("UPDATE `tbl_services` SET `image`='$image' WHERE `id`='$id'");
						}
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageService'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;			
		
		default:
			# code...
			break;
	}
	
 ?>