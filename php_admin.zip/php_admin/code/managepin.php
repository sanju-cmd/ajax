<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
			$percentage = $_POST['percentage'];
			
			if(empty($percentage) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `pincode` (`pincode`) VALUES ('$percentage')");	
				if($sel){
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'managepin'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		
		case 'Update':
		
			$id = $_POST['id'];
			$percentage = $_POST['percentage'];
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `pincode` SET `pincode`=? WHERE `id`=?",[$percentage,$id]);
				
				if($res){
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'managepin'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;			
		
		default:
			# code...
			break;
	}
	
 ?>