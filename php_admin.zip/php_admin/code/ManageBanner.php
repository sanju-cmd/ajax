<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
			
			$url=$_POST['url'];
			$image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			
			if(empty($image) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `tbl_banner` (`image`,`date`, `time`,`url`) VALUES ('$image','$date','$time','$url')");	
				if($sel){ 
					 move_uploaded_file($_FILES['image']['tmp_name'],"../upload/banner/".$image);
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'AddBanner'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'Update':
		
			$id = $_POST['id'];
			$url = $_POST['url'];
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `tbl_banner` SET `date`=?, `time`=? , `url`=? WHERE `id`=?",[$date,$time,$url,$id]);
				
				if($res){
						if(!empty($_FILES['image']['name'])){
                        $image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image']['tmp_name'],"../upload/banner/".$image);
                        $source->Query("UPDATE `tbl_banner` SET `image`='$image' WHERE `id`='$id'");
						}
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageBanner'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;		
		case 'updatecommission':
			$id = $_POST['id'];
			$commission = $_POST['commission'];
			if(empty($id) and empty($commission)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `level_commission` SET  commission='$commission',`date`=?, `time`=? WHERE `id`=?",[$date,$time,$id]);
				
				if($res){
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageCommission'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}
		break;
		
		default:
			# code...
			break;
	}
	
 ?>