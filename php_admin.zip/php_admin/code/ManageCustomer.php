<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
			$name = $_POST['name'];
			$email = $_POST['email'];
			$mobile = $_POST['mobile'];
			$password = $_POST['password'];
			$image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			
			if(empty($name) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `tbl_user`(`name`,`email`,`mobile`,`password`,`image`,`date`,`time`) VALUES('$name','$email','$mobile','$password','$image','$date','$time')");	
				if($sel){
					$last_id = $source->LastId();
					$source->Query("UPDATE `tbl_user` SET sponsorID='ADU001$last_id' WHERE `id`='$last_id'");
					 move_uploaded_file($_FILES['image']['tmp_name'],"../../API/v1/uploads/user/".$image);
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'AddCustomer'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'Update':
		
			$id = $_POST['id'];
			$name = $_POST['name'];
			$email = $_POST['email'];
			$mobile = $_POST['mobile'];
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `tbl_user` SET `name`=?, `email`=?, `mobile`=?,  `date`=?, `time`=? WHERE `id`=?",[$name,$email,$mobile,$date,$time,$id]);
				
				if($res){
						if(!empty($_FILES['image']['name'])){
                        $image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image']['tmp_name'],"../../API/v1/uploads/user/".$image);
                        $source->Query("UPDATE `tbl_user` SET `image`='$image' WHERE `id`='$id'");
						}
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageCustomer'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;			
		
		default:
			# code...
			break;
	}
	
 ?>