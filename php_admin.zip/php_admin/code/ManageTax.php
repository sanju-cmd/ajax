<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
			$title = $_POST['title'];
			$percentage = $_POST['percentage'];
			
			if(empty($title) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `tbl_tax` (`percentage`,`title`,`date`, `time`) VALUES ('$percentage','$title','$date', '$time')");	
				if($sel){
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'ManageTax'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'UnitAdd':
			$name = $_POST['name'];
			
			if(empty($name) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `tbl_unit` (`name`,`date`, `time`) VALUES ('$name','$date', '$time')");	
				if($sel){
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'ManageUnit'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'Update':
		
			$id = $_POST['id'];
			$title = $_POST['title'];
			$percentage = $_POST['percentage'];
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `tbl_tax` SET `percentage`=?, `title`=?,  `date`=?, `time`=? WHERE `id`=?",[$percentage,$title,$date,$time,$id]);
				
				if($res){
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageTax'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;			
		
		default:
			# code...
			break;
	}
	
 ?>