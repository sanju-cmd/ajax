<?php 
	require '../init.php';
	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'Add':
			$name = base64_encode($_POST['name']);
			$category_id = $_POST['category_id'];
			$image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
			
			if(empty($name) || empty($category_id) || empty($image) ){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$sel=$source->Query("INSERT INTO `tbl_subcategory` (`category_id`,`name`,`image`,`date`, `time`) VALUES ('$category_id','$name','$image','$date', '$time')");	
				if($sel){
					 move_uploaded_file($_FILES['image']['tmp_name'],"../upload/subcategory/".$image);
					echo json_encode(array('res' =>'success' ,'msg'=>'Added Success','url'=>'AddSubCategory'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong'));
				}
			}


		break;		

		case 'Update':
		
			$id = $_POST['id'];
			$name = base64_encode($_POST['name']);
			$category_id = $_POST['category_id'];
			if(empty($id)){
				echo json_encode(array('res' =>'error' ,'msg'=>'Data require'));
			}else{
				$res=$source->Query("UPDATE `tbl_subcategory` SET `category_id`=?, `name`=?,  `date`=?, `time`=? WHERE `id`=?",[$category_id,$name,$date,$time,$id]);
				
				if($res){
						if(!empty($_FILES['image']['name'])){
                        $image=date('YHis').rand(1000,9999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                        move_uploaded_file($_FILES['image']['tmp_name'],"../upload/subcategory/".$image);
                        $source->Query("UPDATE `tbl_subcategory` SET `image`='$image' WHERE `id`='$id'");
						}
						
					echo json_encode(array('res' =>'success' ,'msg'=>'Updated Success','url'=>'ManageSubCategory'));
				}else{
					echo json_encode(array('res' =>'error' ,'msg'=>'Something went wrong!'));
				}
				
			}


		break;			
		
		default:
			# code...
			break;
	}
	
 ?>