<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';
		if(empty($_REQUEST['id'])){
		header("location:CustomerDashboard");
		}
		else{
			$id=base64_decode($_REQUEST['id']);
			$source->Query("SELECT * FROM `tbl_user` WHERE `id`=?",[$id]);
			$data=$source->Single();
			
		}
		?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="col-12 col-lg-12 m-0 p-0">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body p-5">
									<div class="card-title d-flex align-items-center">
										
										<h4 class="mb-0 text-primary">All Orders</h4>
									</div>
									
									<hr>
									<div class="row">
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="Pending"/>
					 <button class="btn btn-warning text-white">Pending</button>
					 </form></div>
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="Processed"/>
					 <button class="btn btn-info">Processed</button>
					 </form></div>
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="Shipped"/>
					 <button class="btn btn-primary">Shipped</button>
					 </form></div>
					 
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="Complete"/>
					 <button class="btn btn-success">Complete</button> 
					 </form></div>
					 
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="Cancel"/>
					 <button class="btn btn-danger">Cancelled</button>
					 </form></div>
					 </div>
					 <hr>
					 <form method="POST">
									<div class="row m-4">
									<div class="col-sm-5">
									<?php if(isset($_POST['fromDate'])){?>
									From <input class="form-control" value="<?php echo $_POST['fromDate']?>" type="date" id="datepicker" name="fromDate"/>
									<?php }else{?>
									From <input class="form-control" type="date" id="datepicker" name="fromDate"/>
									<?php }?>
											</div>
											<div class="col-sm-5">
											<?php if(isset($_POST['toDate'])){?>
											To <input class="form-control" value="<?php echo $_POST['toDate']?>" type="date" id="datepicker2" name="toDate"/> 
											<?php }else{?>
											To <input class="form-control"  type="date" id="datepicker2" name="toDate"/> 
											<?php }?>
											</div>
											<div class="col-sm-2">
											<br>
											<button style="height:38px;" class="btn btn-primary" type="submit" ><i class="fa fa-search"></i> Search </button>
											</div>
											</div>
											</form>
											
											
									<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Order ID</th>
											<th>Vendor</th>
											<th>Username</th>
											<th>Address</th>
											<th>Total</th>
											<th>Date/Time</th>
											<th>Status</th>
										</tr>
									</thead>
									<tbody>
									<?php
									$i=1;
										if(isset($_POST['toDate'])){
										$from = $_POST['fromDate'];
										$to = $_POST['toDate'];
										$min = date("M d,Y",strtotime($from));
										$max = date("M d,Y",strtotime($to));
										$source->Query("SELECT * FROM `Orders` WHERE user_id='$data->id' and date BETWEEN '".$min."' AND '".$max."' ORDER BY `id` DESC");
										}elseif(isset($_POST['Pending'])){$source->Query("SELECT * FROM `Orders` WHERE `status`=0 and user_id='$data->id' ORDER BY `id` DESC");}
										elseif(isset($_POST['Processed'])){$source->Query("SELECT * FROM `Orders` WHERE `status`=1 and user_id='$data->id' ORDER BY `id` DESC");}
										elseif(isset($_POST['Shipped'])){$source->Query("SELECT * FROM `Orders` WHERE `status`=3 and user_id='$data->id' ORDER BY `id` DESC");}
										elseif(isset($_POST['Complete'])){$source->Query("SELECT * FROM `Orders` WHERE `status`=4 and user_id='$data->id' ORDER BY `id` DESC");}
										elseif(isset($_POST['Cancel'])){$source->Query("SELECT * FROM `Orders` WHERE `status`=2 and user_id='$data->id' ORDER BY `id` DESC");}
										else{$source->Query("SELECT * FROM `Orders`WHERE user_id='$data->id' ORDER BY `id` DESC");}
										while ($values=$source->Single()){
                                    ?>
										<tr>
													
													
													<?php
													
														$jsonobj = $values->address_id;
														$obj = json_decode($jsonobj);
														
														?>
														<td><?php echo $i;?></td>
														<td><a href="OrderDetail?id=<?php echo base64_encode($values->id)?>" style="text-decoration:none;"><?php echo $values->order_id?></a></td>
														<td>
														<?php $source->Query1("SELECT * FROM `tbl_vendor` WHERE `id`='$values->vendor_id'"); echo$source->SingleData()->name;?>
														</td>
														<td>
														<?php echo $obj->name;?>
														</td>
														<td><?php echo $obj->address;?>,<?php echo $obj->city;?>,<?php echo $obj->state;?>,<?php echo $obj->pincode;?></td>
														<td>₹<?php echo $values->total_price?></td> 
														<td>
															<?php echo $values->date?>
														</td>
														
														<td>
														<?php if($values->status==0){?>
															<button class="btn btn-warning text-white" onclick="OrderStatus3(<?php echo $values->id;?>,'status','4','Orders','Status')">Pending</button>
														<?php }elseif($values->status==1){?>
															<button class="btn btn-info text-white">Processed</button>
														<?php }elseif($values->status==2){?>
															<button class="btn btn-danger text-white">Cancel</button>
														<?php }elseif($values->status==3){?>
															<button class="btn btn-primary text-white">Shipped</button>
														<?php }elseif($values->status==4){?>
															<button class="btn btn-success text-white">Complete</button>
														<?php }?>
														</td>
														
														
													</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
								</div>
							</div>
						</div>
					
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
	
	<script>
		  /// Order Delivered
		function OrderStatus3(id,column,value,table,status){
            swal({
         		title: "Are you sure?",
         		text: "You want to change order "+status+".",
         		icon: "warning",
         		buttons: true,
         		dangerMode: true,
         		})
         		.then((willDelete) => {
         		if (willDelete) {
					
					$.ajax({
					   url: "../code/update_order.php?flag=OrderStatus4",
					   type: "post",
					   data: {"id": id,"column":column,"value":value,"table":table,"status":status },
					   beforeSend: function() {
						 
						},
						success: function(r) { 
						// alert(r);
						if(r=='Success'){
						   swal(""+status+"", "Order has been delevered.", "success");
							   window.setTimeout(function() {
							 window.location.reload();
							}, 800);
						   }
						   else{
								swal("Failed"," Try  ! Again", "error");
						   }
						}
				   })
         		}
			});
		}
	</script>
</body>

</html>