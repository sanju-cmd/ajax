<?php 
require '../init.php';
$id=$_REQUEST['id'];

$source->Query("SELECT * FROM `Orders` WHERE  id='$id'");
$data1=$source->Single();
									
// var_dump($data1);


?>

				  
        <input name="id" type="hidden" value="<?php echo $data1->id;?>"/>
            <div class="form-group">
                 <label>Delivery Boy Assign</label>
               <select class="form-control" name="delivery" >
			   <option>-------- Select Delivery Boy   --------</option>
                            <?php 
							$source->Query("SELECT * FROM `tbl_deliveryboy` WHERE `delete_status`='false' ORDER BY `id` DESC");
							while($values1=$source->single()){
							?>
							
						   <option value="<?php echo $values1->id;?>"><?php echo $values1->name;?></option>
							<?php } ?>
                        </select>
                     </div>
            <button type="submit" class="btn btn-success">Assign Delivery Boy</button>
