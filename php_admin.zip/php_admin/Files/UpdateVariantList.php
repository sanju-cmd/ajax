<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
							<?php 
							$_SESSION['update_varient']=$_REQUEST['id'];
							$source->Query("SELECT * FROM `tbl_product_details` WHERE product_id='".base64_decode($_REQUEST['id'])."'");
							?>
								<h4 class="mb-0">All Variant</h4>
								
								<a href="AddVariant?id=<?php echo $_REQUEST['id'];?>">
								
								<button class="btn btn-primary" style="float:right;margin-top:-25px;"  onclick="">Add Variant</button>
								
								</a>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Model</th>
											<th>Quantity</th>
											<th>Unit</th>
											<th>Stock</th>
											<th>MRP</th>
											<th>Price</th>
											<th>Discount</th>
											<th>Tax</th>
											<th>OrderLimit</th>
											<th>Minimum OrderLimit</th>
											<th>Commission (%)</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$_SESSION['update_varient']=$_REQUEST['id'];
										$source->Query("SELECT *,(SELECT percentage FROM tbl_tax TB WHERE TB.id=TPD.tax) as tax_ FROM `tbl_product_details` TPD WHERE product_id='".base64_decode($_REQUEST['id'])."' and delete_status='false'");
										while ($values=$source->Single()){
										$source->Query1("select * from tbl_unit where id='".$values->unit."'");
										$unt=$source->SingleData();
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											
											
											<td><?php echo $values->model;?></td>
											<td><?php echo $values->quantity;?></td>
											<td><?php echo $unt->name;?></td>
											<td><?php echo $values->stock;?></td>
											<td><?php echo $values->mrp;?></td>
											<td><?php echo $values->price;?></td>
											<td><?php echo $values->discount;?></td>
											<td><?php echo $values->tax_;?>%</td>
											<td><?php echo $values->order_limit;?></td>
											<td><?php echo $values->min_order_limit;?></td>
											<td><?php echo $values->commission;?></td>
											<td>
												
												<a class="btn btn-outline-warning btn-circle" href="UpdateVariant?id=<?php echo base64_encode($values->id);?>"><i class="fa fa-pencil"></i></a>
										
												<button class="btn btn-outline-danger " title="Delete" onclick="Status1(<?php echo $values->id;?>,'delete_status','true','tbl_product_details','Delete')"><i class="fa fa-trash "></i></button>
												
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
	
	<script>
         function Status1(id,column,value,table,status){
			 //alert(id);
                      swal({
         		title: "Are you sure?",
         		text: "You want to "+status+" this section.",
         		icon: "warning",
         		buttons: true,
         		dangerMode: true,
         		})
         		.then((willDelete) => {
         		if (willDelete) {
         		 $.ajax({
                           url: "../code/ManageStatus.php?flag=DeleteVariant",
                           type: "post",
                           data: {"id": id,"column":column,"value":value,"table":table,"status":status },
                           success: function(r) {
                               if(r=='Success'){
								   
                                   swal(""+status+"", "Selected data has been "+status+".", "success");
                                   window.setTimeout(function() {
                                 window.location.reload();
                             }, 800);
                               }
                               else{
                                    swal("Failed"," Try  ! Again", "error");
                               }
                           }
                       })
         		}
         		});
                  }
				  
				 
      </script>
</body>

</html>