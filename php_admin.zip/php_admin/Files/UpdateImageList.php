<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">All Images</h4>
								
								<?php $_SESSION['product_id']=base64_decode($_REQUEST['id']); ?>
								<a href="Images">
								
								<button class="btn btn-primary" style="float:right;margin-top:-25px;"  onclick="">Add Images</button>
								
								</a>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Image</th>
											
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$_SESSION['update_varient']=$_REQUEST['id'];
										$source->Query("SELECT * FROM `product_images` WHERE product_id='".base64_decode($_REQUEST['id'])."' and delete_status='false'");
										while ($values=$source->Single()){
											
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											
											
											<td><a href="../../API/v1/uploads/products/<?php echo $values->image;?>" target="_blank"><img src="../../API/v1/uploads/products/<?php echo $values->image;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
											
											<td>
												
												
												<button class="btn btn-outline-danger " title="Delete" onclick="DeleteImage('<?php echo $values->id;?>','delete_status','true','product_images','Delete')"><i class="fa fa-trash "></i></button>
												
												
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
	
	<script>
         function Status1(id,column,value,table,status){
                      swal({
         		title: "Are you sure?",
         		text: "You want to "+status+" this section.",
         		icon: "warning",
         		buttons: true,
         		dangerMode: true,
         		})
         		.then((willDelete) => {
         		if (willDelete) {
         		 $.ajax({
                           url: "../code/ManageStatus.php?flag=Delete1",
                           type: "post",
                           data: {"id": id,"column":column,"value":value,"table":table,"status":status },
                           success: function(r) {
                               if(r=='Success'){
                                   swal(""+status+"", "Selected data has been "+status+".", "success");
                                   window.setTimeout(function() {
                                 window.location.reload();
                             }, 800);
                               }
                               else{
                                    swal("Failed"," Try  ! Again", "error");
                               }
                           }
                       })
         		}
         		});
                  }
				  
				 
      </script>
	  
	  <script>
         function DeleteImage(id,column,value,table,status){
			// alert(id);
                      swal({
         		title: "Are you sure?",
         		text: "You want to "+status+" this section.",
         		icon: "warning",
         		buttons: true,
         		dangerMode: true,
         		})
         		.then((willDelete) => {
         		if (willDelete) {
         		 $.ajax({
                           url: "../code/ManageStatus.php?flag=DeleteImage",
                           type: "post",
                           data: {"id": id,"column":column,"value":value,"table":table,"status":status },
                           success: function(r) {
							   //alert(r);
                               if(r=='Success'){
                                   swal(""+status+"", "Selected data has been "+status+".", "success");
                                   window.setTimeout(function() {
                                 window.location.reload();
                             }, 800);
                               }
                               else{
								   //alert("error");
                                    swal("Failed"," Try  ! Again", "error");
                               }
                           }
                       })
         		}
         		});
                  }
				  
				 
      </script>
	  
	  
	  
</body>

</html>