<?php require '../code/Validation.php'; 
$source->Query("SELECT * FROM `admin` WHERE `id`=?",[1]);
$admin=$source->Single();
?>

<html>
<head>

</head>
<body>
<!--sidebar-wrapper-->
		<div class="sidebar-wrapper" data-simplebar="true">
			<div class="sidebar-header">
				<div class="">
					<img src="../assets/images/logo2.png" class="logo-icon-2" alt="" style="height:60px;width:80%;">
				</div>
				<!--<div>
					<h4 class="logo-text">ZPS</h4>
				</div>-->
				<a href="javascript:;" class="toggle-btn ml-auto"> <i class="bx bx-menu"></i>
				</a>
			</div>
			<!--navigation-->
			<ul class="metismenu" id="menu">
				<li>
					<a href="DashBoard" >
						<div class="parent-icon icon-color-1"><i class="bx bx-home-alt"></i>
						</div>
						<div class="menu-title">Dashboard</div>
					</a>
					
				</li>
				<li>
					<a href="ManageOrders" >
						<div class="parent-icon icon-color-5"><i class="bx bx-cart"></i>
						</div>
						<div class="menu-title">Orders</div>
					</a>
					
				</li>
				<li>
					<a href="ManageBookings" >
						<div class="parent-icon icon-color-5"><i class="bx bx-brightness"></i>
						</div>
						<div class="menu-title">Service Bookings</div>
					</a>
					
				</li>
				<li>
					<a href="ManageTax">
						<div class="parent-icon icon-color-5"><i class="bx bx-award"></i>
						</div>
						<div class="menu-title">Manage Tax</div>
					</a>
				</li>
				<li>
					<a href="RefundOrders" >
						<div class="parent-icon icon-color-5"><i class="bx bx-undo"></i>
						</div>
						<div class="menu-title">Refund Orders</div>
					</a>
					
				</li>
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-10"><i class="bx bx-image"></i>
						</div>
						<div class="menu-title">Banner</div>
					</a>
					<ul>
						<li> <a href="AddBanner"><i class="bx bx-right-arrow-alt"></i>Add Banner</a>
						</li>
						<li> <a href="ManageBanner"><i class="bx bx-right-arrow-alt"></i>Manage Banner</a>
						</li>
						
					</ul>
				</li>
				
				<li>
					<a href="UpdateSideBanner" >
						<div class="parent-icon icon-color-1"><i class="bx bx-home-alt"></i>
						</div>
						<div class="menu-title">SideBanner</div>
					</a>
					
				</li>
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-10"><i class="bx bx-news"></i>
						</div>
						<div class="menu-title">Blog</div>
					</a>
					<ul>
						<li> <a href="AddBlog"><i class="bx bx-right-arrow-alt"></i>Add Blog</a>
						</li>
						<li> <a href="ManageBlog"><i class="bx bx-right-arrow-alt"></i>Manage Blog</a>
						</li>
						
					</ul>
				</li>
				
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-11"><i class="bx bx-arch"></i>
						</div>
						<div class="menu-title">Brand</div>
					</a>
					<ul>
						<li> <a href="AddBrand"><i class="bx bx-right-arrow-alt"></i>Add Brand</a>
						</li>
						<li> <a href="ManageBrand"><i class="bx bx-right-arrow-alt"></i>Manage Brand</a>
						</li>
						
					</ul>
				</li>
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-3"><i class="bx bx-layer"></i>
						</div>
						<div class="menu-title">Category</div>
					</a>
					<ul>
						<li> <a href="AddCategory"><i class="bx bx-right-arrow-alt"></i>Add Category</a>
						</li>
						<li> <a href="ManageCategory"><i class="bx bx-right-arrow-alt"></i>Manage Category</a>
						</li>
						
					</ul>
				</li>
				
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-4"><i class="bx bx-layer"></i>
						</div>
						<div class="menu-title">Sub Category</div>
					</a>
					<ul>
						<li> <a href="AddSubCategory"><i class="bx bx-right-arrow-alt"></i>Add Sub Category</a>
						</li>
						<li> <a href="ManageSubCategory"><i class="bx bx-right-arrow-alt"></i>Manage Sub Category</a>
						</li>
						
					</ul>
				</li>
				
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-5"><i class="bx bx-basket"></i>
						</div>
						<div class="menu-title">Products</div>
					</a>
					<ul>
						<!--<li> <a href="AddProduct"><i class="bx bx-plus"></i>Add Product</a></li>-->
						<li> <a href="AddProduct"><i class="bx bx-right-arrow-alt"></i>Add Products</a></li>
						<li> <a href="AllProduct"><i class="bx bx-right-arrow-alt"></i>All Products</a></li>
						<li> <a href="ProductByCategory"><i class="bx bx-right-arrow-alt"></i>Products By Category</a></li>
						<li> <a href="ProductByVendor"><i class="bx bx-right-arrow-alt"></i>Products By Vendor</a></li>
						<!--li> <a href="#"><i class="bx bx-right-arrow-alt"></i>Bulk Upload</a></li-->
						<!--<li> <a href="ManageTax"><i class="bx bx-right-arrow-alt"></i>Taxes</a></li>-->
						<li> <a href="ManageUnit"><i class="bx bx-circle"></i>Units</a></li>
					</ul>
				</li>
				  <li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-4"><i class="bx bx-brightness"></i>
						</div>
						<div class="menu-title">Service Category</div>
					</a>
					<ul>
						<li> <a href="AddServiceCategory"><i class="bx bx-right-arrow-alt"></i>Add Service Category</a>
						</li>
						<li> <a href="ManageServiceCategory"><i class="bx bx-right-arrow-alt"></i>Manage Service Category</a>
						</li>
						
						<!--li> <a href="AddServiceSubCategory"><i class="bx bx-right-arrow-alt"></i>Add Service Sub-Category</a>
						</li>
						
						<li> <a href="ManageServiceSubCategory"><i class="bx bx-right-arrow-alt"></i>Manage Service Sub-Category</a>
						</li>
						<li> <a href="AddService"><i class="bx bx-right-arrow-alt"></i>Add Service</a>
						</li>
						<li> <a href="ManageService"><i class="bx bx-right-arrow-alt"></i>Manage Service</a>
						</li-->
					</ul>
				</li>
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-4"><i class="bx bx-brightness"></i>
						</div>
						<div class="menu-title">Service Sub-Category</div>
					</a>
					<ul>
						<!--li> <a href="AddServiceCategory"><i class="bx bx-right-arrow-alt"></i>Add Service Category</a>
						</li>
						<li> <a href="ManageServiceCategory"><i class="bx bx-right-arrow-alt"></i>Manage Service Category</a>
						</li-->
						
						<li> <a href="AddServiceSubCategory"><i class="bx bx-right-arrow-alt"></i>Add Service Sub-Category</a>
						</li>
						
						<li> <a href="ManageServiceSubCategory"><i class="bx bx-right-arrow-alt"></i>Manage Service Sub-Category</a>
						</li>
						<!--li> <a href="AddService"><i class="bx bx-right-arrow-alt"></i>Add Service</a>
						</li>
						<li> <a href="ManageService"><i class="bx bx-right-arrow-alt"></i>Manage Service</a>
						</li-->
					</ul>
				</li>
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-4"><i class="bx bx-brightness"></i>
						</div>
						<div class="menu-title">Services</div>
					</a>
					<ul>
						<!--li> <a href="AddServiceCategory"><i class="bx bx-right-arrow-alt"></i>Add Service Category</a>
						</li>
						<li> <a href="ManageServiceCategory"><i class="bx bx-right-arrow-alt"></i>Manage Service Category</a>
						</li>
						
						<li> <a href="AddServiceSubCategory"><i class="bx bx-right-arrow-alt"></i>Add Service Sub-Category</a>
						</li>
						
						<li> <a href="ManageServiceSubCategory"><i class="bx bx-right-arrow-alt"></i>Manage Service Sub-Category</a>
						</li-->
						<li> <a href="AddService"><i class="bx bx-right-arrow-alt"></i>Add Service</a>
						</li>
						<li> <a href="ManageService"><i class="bx bx-right-arrow-alt"></i>Manage Service</a>
						</li>
					</ul>
				</li>
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-6"><i class="bx bx-user-pin"></i>
						</div>
						<div class="menu-title">Manager</div>
					</a>
					<ul>
						<li> <a href="AddManager"><i class="bx bx-right-arrow-alt"></i>Add Manager</a>
						</li>
						<li> <a href="ManageManager"><i class="bx bx-right-arrow-alt"></i>Manage Manager</a>
						</li>
						
					</ul>
				</li>
				
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-7"><i class="bx bx-user-plus"></i>
						</div>
						<div class="menu-title">Vendor</div>
					</a>
					<ul>
						<li> <a href="AddVendor"><i class="bx bx-right-arrow-alt"></i>Add Vendor</a>
						</li>
						<li> <a href="ManageVendor"><i class="bx bx-right-arrow-alt"></i>Manage Vendor</a>
						</li>
						
					</ul>
				</li>
				
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-8"><i class="bx bx-user"></i>
						</div>
						<div class="menu-title">Delivery Boy</div>
					</a>
					<ul>
						
						<li> <a href="CommissionDeliveryBoy"><i class="bx bx-right-arrow-alt"></i>Delivery Boy Commission</a></li>
						<li> <a href="AddDeliveryBoy"><i class="bx bx-right-arrow-alt"></i>Add Delivery Boy</a></li>
						
						<li> <a href="ManageDeliveryBoy"><i class="bx bx-right-arrow-alt"></i>Manage Delivery Boy</a>
						</li>
						
					</ul>
				</li>
				
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-9"><i class="bx bx-user-circle"></i>
						</div>
						<div class="menu-title">Customers</div>
					</a>
					<ul>
						<li><a href="AddCustomer"><i class="bx bx-right-arrow-alt"></i>Add Customer</a></li>
						<li><a href="ManageCustomer"><i class="bx bx-right-arrow-alt"></i>Manage Customer</a></li>
					
						<li><a href="WalletTransaction"><i class="bx bx-right-arrow-alt"></i>Wallet Transaction</a></li>
					
						
					</ul>
				</li>
				
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-3"><i class="bx bx-book"></i>
						</div>
						<div class="menu-title">KYC</div>
					</a>
					<ul>
						<li> <a href="UsersKYC"><i class="bx bx-right-arrow-alt"></i>Users</a>
						</li>
						<li> <a href="VendorsKYC"><i class="bx bx-right-arrow-alt"></i>Vendor</a>
						</li>
						<li> <a href="ManagersKYC"><i class="bx bx-right-arrow-alt"></i>Driver</a>
						</li>
						
					</ul>
				</li>
				
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-4"><i class="bx bx-money"></i>
						</div>
						<div class="menu-title">Withdrawal Request</div>
					</a>
					<ul>
						<li> <a href="UsersWR"><i class="bx bx-right-arrow-alt"></i>Users</a>
						</li>
						<li> <a href="VendorsWR"><i class="bx bx-right-arrow-alt"></i>Vendor</a>
						</li>
						<li> <a href="ManagersWR"><i class="bx bx-right-arrow-alt"></i>Driver</a>
						</li>
						
					</ul>
				</li>
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-4"><i class="bx bx-cog"></i>
						</div>
						<div class="menu-title">App&Web Settings</div>
					</a>
					<ul>
						<li> <a href="WebSettings"><i class="bx bx-right-arrow-alt"></i>Web Settings</a></li>
					</ul>
				</li>
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-4"><i class="bx bx-file"></i>
						</div>
						<div class="menu-title">Manage Report</div>
					</a>
					<ul>
						<li> <a href="SelarStockReport"><i class="bx bx-right-arrow-alt"></i>Seller Stock Report</a></li>
						<li> <a href="ProductWiseSalesReport"><i class="bx bx-right-arrow-alt"></i>Product Wise Sales Report </a></li>
						<li> <a href="ProductWiseStockReport"><i class="bx bx-right-arrow-alt"></i>Product Wise Stock Report  </a></li>
					</ul>
				</li>
				
				<li>
					<a href="Complaints">
						<div class="parent-icon icon-color-5"><i class="fa fa-comments"></i> 
						</div>
						<div class="menu-title">Complaints</div>
					</a>
				</li>
				
				
						
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-12"><i class="bx bx-copy"></i>
						</div>
						<div class="menu-title">AboutUs</div>
					</a>
					<ul>
						<li> <a href="AddAboutus"><i class="bx bx-right-arrow-alt"></i>Add About Us</a>
						</li>
						<li> <a href="ManageAboutUs"><i class="bx bx-right-arrow-alt"></i>Manage About Us</a>
						</li>
						
					</ul>
				</li>
				
				<li>
					<a href="managepin">
						<div class="parent-icon icon-color-5"><i class="fa fa-location-arrow"></i> 
						</div>
						<div class="menu-title">Pincode</div>
					</a>
				</li>
				
				
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-12"><i class="bx bx-rupee"></i>
						</div>
						<div class="menu-title">Delivery Charge</div>
					</a>
					<ul>
						<li> <a href="AddDelivery"><i class="bx bx-right-arrow-alt"></i>Add Delivery Charge</a>
						</li>
						<li> <a href="ManageDeliveryCharge"><i class="bx bx-right-arrow-alt"></i>Manage Delivery Charge</a>
						</li>
						
					</ul>
				</li>
				
				
				
				<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-13"><i class="bx bx-user-circle"></i>
						</div>
						<div class="menu-title">Profile</div>
					</a>
					<ul>
						<li> <a href="ManageProfile"><i class="bx bx-right-arrow-alt"></i>My Profile</a></li>
						
						<li> <a  href="#" data-toggle="modal" data-target="#logoutModal"><i class="bx bx-right-arrow-alt"></i>Logout</a>
						</li>
						
					</ul>
				</li>
				
			</ul>
			<!--end navigation-->
		</div>
		
		</body>
		</html>