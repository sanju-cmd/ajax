<!DOCTYPE html>
<html lang="en">
   <head>
      <?php require'CssLink.php';?>
   </head>
   <body>
      <!-- wrapper -->
      <div class="wrapper">
         <?php require'LeftMenu.php';?>
         <?php require'Header.php';?>
         <!--page-wrapper-->
         <div class="page-wrapper">
            <!--page-content-wrapper-->
            <div class="page-content-wrapper">
               <div class="page-content">
                  <!--breadcrumb-->
                  <!--end breadcrumb-->
                  <div class="col-12 col-lg-12 m-0 p-0">
                     <div class="card radius-15 border-lg-top-primary">
                        <div class="card-body p-2">
                           <div class="card-title d-flex align-items-center">
                              <h4 class="mb-0 text-primary">Report</h4>
                           </div>
                           <hr>
                           <form method="POST">
                              <div class="row m-4">
                                 <div class="col-sm-4">
                                    Product 
                                    <select class="form-control" name="category_id" id="productFilter">
                                       <option selected="" disabled="">Select Product</option>
                                       <?php
                                          $source->Query("SELECT name,id FROM `product` WHERE `del_status`='false' and status='true' ORDER BY `id` ASC");
                                          while($values=$source->Single()){
                                           
                                           if($_REQUEST['product_id']==$values->id){
                                            echo '<option  selected value='.$values->id.'>'.base64_decode($values->name).'</option>';
                                           }else{
                                            echo '<option  value='.$values->id.'>'.base64_decode($values->name).'</option>';
                                           }
                                          
                                          }
                                          
                                          ?>
                                    </select>
                                 </div>
                                 <div class="col-sm-3">
                                    <?php if(isset($_POST['fromDate'])){?>
                                    From <input class="form-control" value="<?php echo $_POST['fromDate']?>" type="date" id="datepicker" name="fromDate"/>
                                    <?php }else{?>
                                    From <input class="form-control" type="date" id="datepicker" name="fromDate"/>
                                    <?php }?>
                                 </div>
                                 <div class="col-sm-3">
                                    <?php if(isset($_POST['toDate'])){?>
                                    To <input class="form-control" value="<?php echo $_POST['toDate']?>" type="date" id="datepicker2" name="toDate"/> 
                                    <?php }else{?>
                                    To <input class="form-control"  type="date" id="datepicker2" name="toDate"/> 
                                    <?php }?>
                                 </div>
                                 <div class="col-sm-2">
                                    <br>
                                    <button style="height:38px;" class="btn btn-primary" type="submit" ><i class="fa fa-search"></i> Search </button>
                                 </div>
                              </div>
                           </form>
                           <div class="table-responsive">
                              <table id="example2" class="table table-striped table-bordered" style="width:100%">
                                 <thead>
                                    <tr>
                                       <th>Sr. No.</th>
                                       <th>Vendor</th>
                                       <th>Product</th>
                                       <th>Product Variant ID </th>
                                       <th>Unit Of Measure</th>
                                       <th>Total Stock</th>
                                       <th>Total Sale Amount</th>
                                       <th>Total Sale</th>
									   <th>Available Stock</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <?php
                                       $where="WHERE del_status='false' and status='true'";
                                       $i=1;
                                       
                                       if(isset($_REQUEST['product_id'])){
                                       	$where.="and id='".$_REQUEST['product_id']."'";
                                       }
                                       if(isset($_POST['toDate'])){
                                       	$from = $_POST['fromDate'];
                                       	$to = $_POST['toDate'];
                                       	$min = date("M d,Y",strtotime($from));
                                       	$max = date("M d,Y",strtotime($to));
                                       	$where.="and date BETWEEN '".$min."' AND '".$max."'";
                                       }
                                       
                                       if(isset($_REQUEST['product_id']) and isset($_POST['toDate'])){
                                       	$from = $_POST['fromDate'];
                                       	$to = $_POST['toDate'];
                                       	$min = date("M d,Y",strtotime($from));
                                       	$max = date("M d,Y",strtotime($to));
                                       	$where.="and  id='".$_REQUEST['product_id']."' and date BETWEEN '".$min."' AND '".$max."'";
                                       }
                                       
                                        $source->Query("SELECT *,(SELECT name from tbl_vendor tb where tb.id=p.vendor_id) as vendor_name FROM `product` p ".$where." ORDER BY `id` DESC");
										 while ($values=$source->Single()){
                                       	$source->Query1("SELECT *,(SELECT name FROM tbl_unit TU WHERE TU.id=TPD.unit) as unit_name FROM `tbl_product_details` TPD WHERE product_id=?",[$values->id]);
                                       	$values_details=$source->SingleData();
                                       	
                                       	$source->Query1("SELECT COUNT(*) as total FROM Orders WHERE product_id='".$values->id."'");
                                       	$p_data=$source->SingleData();
										 
                                                                 ?>
                                    <tr>
                                       <td><?php echo $i; ?></td>
                                       <td><?php echo $values->vendor_name; ?></td>
                                       <td><?php echo base64_decode($values->name); ?></td>
                                       <td><?php echo $values_details->id; ?></td>
                                       <td><?php echo $values_details->quantity; ?> <?php echo $values_details->unit_name; ?></td>
                                       <td><?php echo $values_details->stock; ?> </td>
                                       <td>₹<?= $p_data->total*$values_details->price; ?> </td>
                                       <td><?= $values_details->sale; ?> </td>
									   <td><?= $values_details->stock-$values_details->sale; ?> </td>
                                    </tr>
                                    <?php $i++;} ?>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--end page-content-wrapper-->
         </div>
         <!--end page-wrapper-->
         <!--start overlay-->
         <div class="overlay toggle-btn-mobile"></div>
         <!--end overlay-->
         <?php require'Footer.php';?>
      </div>
      <!-- end wrapper -->
      <?php require'JsLink.php';?>
      <script>
         /// Order Delivered
         function OrderStatus3(id,column,value,table,status){
                 swal({
              		title: "Are you sure?",
              		text: "You want to change order "+status+".",
              		icon: "warning",
              		buttons: true,
              		dangerMode: true,
              		})
              		.then((willDelete) => {
              		if (willDelete) {
         	
         	$.ajax({
         	   url: "../code/update_order.php?flag=OrderStatus4",
         	   type: "post",
         	   data: {"id": id,"column":column,"value":value,"table":table,"status":status },
         	   beforeSend: function() {
         		 
         		},
         		success: function(r) { 
         		// alert(r);
         		if(r=='Success'){
         		   swal(""+status+"", "Order has been delevered.", "success");
         			   window.setTimeout(function() {
         			 window.location.reload();
         			}, 800);
         		   }
         		   else{
         				swal("Failed"," Try  ! Again", "error");
         		   }
         		}
            })
              		}
         });
         }
         
         $("#CategoryFilter").change(function(){
         var id=document.getElementById('CategoryFilter').value;
         location.href="ProductWiseStockReport?product_id="+id;
         });
         $("#productFilter").change(function(){
         var id=document.getElementById('productFilter').value;
         location.href="ProductWiseStockReport?product_id="+id;
         });
         
         
      </script>
   </body>
</html>