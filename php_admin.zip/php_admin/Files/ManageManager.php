<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Manage Manager</h4>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>AD ID</th>
											<th>Name</th>
											<th>Email</th>
											<th>Mobile</th>
											<th>Adhar No.</th>
											<th>Pan Card No.</th>
											<th>Address</th>
											<th>Assign City</th>
											<th>Assign State</th>
											<th>Joining Date</th>
											<th>Wallet Amount</th>
											<th>Total Referrals</th>
											<th>Profile</th>
											<th>Adhar Image</th>
											<th>Pan Card Image</th>
											<th>Date/Time</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$source->Query("SELECT * FROM `tbl_manager` where delete_status='false' ORDER BY `id` DESC");
										while ($values=$source->Single()){
											
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											<td><a href="ManagerDashboard?id=<?php echo base64_encode($values->id);?>"><?php echo $values->sponsorID;?></td>
											<td><?php echo $values->name;?></td>
											<td><?php echo $values->email;?></td>
											<td><?php echo $values->mobile;?></td>
											<td><?php echo $values->adhar;?></td>
											<td><?php echo $values->pancard;?></td>
											<td><?php echo $values->address;?></td>
											<td><?php echo $values->assigncity;?></td>
											<td><?php echo $values->assignstate;?></td>
											<td><?php echo $values->joiningdate;?></td>
											<td>&#x20B9;<?php echo $values->wallet;?></td>
											<td><?php $source->Query1("SELECT * FROM `tbl_manager` where delete_status='false' and referral_id='$values->sponsorID'"); echo $count=$source->NumRows();?></td>
											<td><a href="../../API/v1/uploads/manager/<?php echo $values->image;?>" target="_blank"><img src="../../API/v1/uploads/manager/<?php echo $values->image;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
											
											<td><a href="../../API/v1/uploads/adhar/<?php echo $values->adhar_image;?>" target="_blank"><img src="../../API/v1/uploads/adhar/<?php echo $values->adhar_image;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
											
											<td><a href="../../API/v1/uploads/pancard/<?php echo $values->pan_image;?>" target="_blank"><img src="../../API/v1/uploads/pancard/<?php echo $values->pan_image;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
											
											<td><?php echo $values->date;?><br><?php echo $values->time;?></td>
											<td>
												<a class="btn btn-outline-warning btn-circle" title="Edit" href="UpdateManager?id=<?php echo base64_encode($values->id);?>"><i class="fa fa-pencil"></i></a>
												
									
												<button class="btn btn-outline-danger " title="Delete" onclick="Status(<?php echo $values->id?>,'delete_status','true','tbl_manager','Delete')"><i class="fa fa-trash "></i></button>
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
</body>

</html>