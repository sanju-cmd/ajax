<!DOCTYPE html>
<html lang="en">
   <head>
      <?php require'CssLink.php';?>
      <style>
         .shop-dt-left {
         margin-left: 20px;
         }
         .shop-dt-left h4 {
         color: #2b2f4c;
         font-size: 18px;
         font-weight: 500;
         margin-bottom: 7px;
         text-align: left;
         }
         .shop-dt-left span {
         color: #3e3f5e;
         font-size: 14px;
         font-weight: 400;
         text-align: left;
         }
         .shopowner-dt-left {
         margin-left: 0;
         text-align: center;
         }
         .shopowner-dt-left h4 {
         color: #2b2f4c;
         font-size: 18px;
         font-weight: 500;
         margin-bottom: 7px;
         }
         .shopowner-dt-left span {
         color: #3e3f5e;
         font-size: 14px;
         font-weight: 400;
         text-align: left;
         }
         .shopowner-dts {
         margin-top: 20px;
         border: 1px solid #efefef;
         border-radius: 3px;
         }
         .shopowner-dt-list {
         display: flex;
         align-items: start;
         padding: 10px;
         border-bottom: 1px solid #efefef;
         width: 100%;
         }
         .shopowner-dt-list:last-child {
         border-bottom: 0;
         }
         .left-dt {
         color: #2b2f4c;
         font-size: 14px;
         font-weight: 500;
         margin-bottom: 0;
         text-align: left;
         width: 50%;
         }
         .right-dt {
         color: #3e3f5e;
         font-size: 14px;
         font-weight: 400;
         margin-bottom: 0;
         margin-left: auto;
         text-align: right;
         width: 50%;
         }
      </style>
   </head>
   <body>
      <!-- wrapper -->
      <div class="wrapper">
         <?php require'LeftMenu.php';?>
         <?php 
            require'Header.php';
            if(empty($_REQUEST['id'])){
            header("location:ManageOrders");
            }
            else{
            	$id=base64_decode($_REQUEST['id']);
            	$source->Query("SELECT * FROM `Orders` WHERE `id`=?",[$id]);
            	$values=$source->Single();
            	
            }
            ?>
         <!--page-wrapper-->
         <div class="page-wrapper">
            <!--page-content-wrapper-->
            <div class="page-content-wrapper">
               <div class="page-content">
                  <!--breadcrumb-->
                  <style>
                     .card {
                     z-index: 0;
                     background-color: white;
                     padding-bottom: 20px;
                     border-radius: 10px
                     }
                     .top {
                     padding-top: 40px;
                     padding-left: 13% !important;
                     padding-right: 13% !important
                     }
                     #progressbar {
                     margin-bottom: 30px;
                     overflow: hidden;
                     color: #455A64;
                     padding-left: 0px;
                     margin-top: 30px
                     }
                     #progressbar li {
                     list-style-type: none;
                     font-size: 13px;
                     width: 25%;
                     float: left;
                     position: relative;
                     font-weight: 400
                     }
                     #progressbar .step0:before {
                     font-family: FontAwesome;
                     content: "\f10c";
                     color: #fff
                     }
                     #progressbar li:before {
                     width: 40px;
                     height: 40px;
                     line-height: 45px;
                     display: block;
                     font-size: 20px;
                     background: grey;
                     border-radius: 50%;
                     margin: auto;
                     padding: 0px
                     }
                     #progressbar li:after {
                     content: '';
                     width: 100%;
                     height: 12px;
                     background: grey;
                     position: absolute;
                     left: 0;
                     top: 16px;
                     z-index: -1
                     }
                     #progressbar li:last-child:after {
                     border-top-right-radius: 10px;
                     border-bottom-right-radius: 10px;
                     position: absolute;
                     left: -50%
                     }
                     #progressbar li:nth-child(2):after,
                     #progressbar li:nth-child(3):after {
                     left: -50%
                     }
                     #progressbar li:first-child:after {
                     border-top-left-radius: 10px;
                     border-bottom-left-radius: 10px;
                     position: absolute;
                     left: 50%
                     }
                     #progressbar li:last-child:after {
                     border-top-right-radius: 10px;
                     border-bottom-right-radius: 10px
                     }
                     #progressbar li:first-child:after {
                     border-top-left-radius: 10px;
                     border-bottom-left-radius: 10px
                     }
                     <?php if($values->status==2){?>
                     #progressbar li.active:before,
                     #progressbar li.active:after {
                     background: red
                     }
                     <?php }else{?>
                     #progressbar li.active:before,
                     #progressbar li.active:after {
                     background: green
                     }
                     <?php }?>
                     #progressbar li.active:before {
                     font-family: FontAwesome;
                     content: "\f00c"
                     }
                     .icon {
                     width: 60px;
                     height: 60px;
                     margin-right: 15px
                     }
                     .icon-content {
                     padding-bottom: 20px
                     }
                     @media screen and (max-width: 992px) {
                     .icon-content {
                     width: 50%
                     }
                     }
                  </style>
                  <!--Start Order Tracking-->
                  <div class=" mx-auto">
                     <div class="card">
                        <div class="row d-flex justify-content-between px-3 top">
                           <div class="d-flex">
                              <h5>ORDER ID <span class="text-primary font-weight-bold"> #<?php echo $values->order_id?></span></h5>
                           </div>
                           <div class="d-flex flex-column text-sm-right">
                              <p class="mb-0">Order Date: <span><?php echo $values->date?></span></p>
                              <p>Order Type: <span class="font-weight-bold"><?php echo $values->order_type?></span></p>
                           </div>
                        </div>
                        <!-- Add class 'active' to progress -->
                        <div class="row d-flex justify-content-center">
                           <div class="col-12">
                              <ul style="color:pink;" id="progressbar" class="text-center">
                                 <?php 
                                    if($values->status==0){
                                    ?>
                                 <li class="active step0"></li>
                                 <li class=" step0"></li>
                                 <li class=" step0"></li>
                                 <li class=" step0"></li>
                                 <?php }
                                    elseif($values->status==1){
                                    ?>
                                 <li class="active step0"></li>
                                 <li class="active step0"></li>
                                 <li class=" step0"></li>
                                 <li class=" step0"></li>
                                 <?php }
                                    elseif($values->status==2){
                                    ?>
                                 <li class="active step0"></li>
                                 <li class="active step0"></li>
                                 <li class="active step0"></li>
                                 <li class=" step0"></li>
                                 <?php }
                                    elseif($values->status==3){
                                    ?>
                                 <li class="active step0"></li>
                                 <li class="active step0"></li>
                                 <li class="active step0"></li>
                                 <li class=" step0"></li>
                                 <?php }
                                    elseif($values->status==4){
                                    ?>
                                 <li class="active step0"></li>
                                 <li class="active step0"></li>
                                 <li class="active step0"></li>
                                 <li class="active step0"></li>
                                 <?php }?>
                              </ul>
                           </div>
                        </div>
                        <div class="row justify-content-between top">
                           <div class="row d-flex icon-content">
                              <div class="d-flex flex-column">
                                 <p class="font-weight-bold">Order<br>Pending</p>
                              </div>
                           </div>
                           <div class="row d-flex icon-content">
                              <div class="d-flex flex-column">
                                 <p class="font-weight-bold">Order<br>Proccessed</p>
                              </div>
                           </div>
                           <?php if($values->status==2){?>
                           <div class="row d-flex icon-content">
                              <div class="d-flex flex-column">
                                 <p class="font-weight-bold">Order<br>Cancel</p>
                              </div>
                           </div>
                           <?php }else{?>
                           <div class="row d-flex icon-content">
                              <div class="d-flex flex-column">
                                 <p class="font-weight-bold">Order<br>Shipped</p>
                              </div>
                           </div>
                           <?php }?>
                           <div class="row d-flex icon-content">
                              <div class="d-flex flex-column">
                                 <p class="font-weight-bold">Order<br>Delivered</p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!--end breadcrumb-->
                  <div class="col-12 col-lg-12 m-0 p-0">
                     <div class="card radius-15 border-lg-top-primary">
                        <div class="card-body p-3">
                           <button class="btn btn-outline-dark btn-sm" data-toggle="modal" data-target="#invoiceModal" ><i class="fa fa-print"></i> Print Invoice</button>
                           <div class="row">
                              <div class="col-sm-6" style="float:left;">
                                 <h4 class="mb-0 text-primary">Order ID: #<?php echo $values->order_id;?> </h4>
                              </div>
                              <?php if($values->delivery_boy_status=='Accepted'){?>
                              <div class="col-sm-6 text-right" style="float:right;">
                                 <button class="btn btn-warning text-white" data-toggle="modal" data-target="#exampleModal">Change Status</button>
                              </div>
                              <?php }?>
                              <?php if($values->delivery_boy_status=='false'){?>
                              <div class="col-sm-6 text-right" style="float:right;">
                                 <button class="btn btn-success text-white" onclick="AssignDelivery('<?= $values->id?>')" data-toggle="modal" data-target="#exampleModall">Assign Delivery Boy <?php //var_dump($values) ?></button>
                              </div>
                              <?php }?>
                           </div>
                           <hr>
                           <?php  $source->Query1("SELECT * FROM `tbl_vendor` WHERE `id`='$values->vendor_id'");
                              $vendor=$source->SingleData();
                              ?>
                           <div class="card">
                              <h5 class="card-header"><?php echo $vendor->name?>, <?php echo $vendor->address?> </h5>
                              <div class="card-body">
                                 <div class="table-responsive">
                                    <table id="example1" class="table  table-bordered" style="width:100%">
                                       <thead class="thead-light">
                                          <tr>
                                             <th scope="col">Image</th>
                                             <th scope="col">Name</th>
                                             <th scope="col">Category</th>
                                             <th scope="col">Brand</th>
                                             <th scope="col">Unit</th>
                                             <th scope="col">Tax</th>
											 <th scope="col">HSN No.</th>
                                             <th scope="col">Price*Quantity</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <?php
                                             $str = $values->product_id;
											 //var_dump($values);
																																																	$variant_id = $values->variant_id;
                                            $variant_id=explode(",",$variant_id);
											 
                                             $ssy=(explode(",",$str));
                                             $str2 = $values->qty;
                                             $ssy2=(explode(",",$str2));
                                             //$j=1;
											 
                                             for($i=0;$i<sizeOf($ssy);$i++){
                                             	if($ssy[$i]!=''){
                                             		// $sky=$conn->query("SELECT * FROM `product` WHERE `id`='".$ssy[$i]."'")->fetch_assoc();
                                             		
                                             		$source->Query1("SELECT *,(SELECT name FROM `tbl_category` c where c.id=p.category) as category,(SELECT image FROM `product_images` i where i.product_id=p.id limit 1) as images,(SELECT name FROM `tbl_brands` b where b.id=p.brand) as brand FROM `product` p where `id`='$ssy[$i]' ");
                                             		$sky=$source->SingleData();
                                             		$source->Query1("SELECT * FROM `tbl_product_details` WHERE id='".$variant_id[$i]."' ");
                                             		$details=$source->SingleData();
                                             		//var_dump($sky->id);
                                             		$img=(explode("ZPS",$sky->images));
                                             		$subp=$subp+($details->price*$ssy2[$i]);
                                             		
                                             		$source->Query1("SELECT * FROM `tbl_tax` WHERE id='".$details->tax."'");
                                             $d=$source->SingleData();
                                             		//var_dump($details);
                                             ?>	
                                          <tr>
                                             <td><a href="../../API/v1/uploads/products/<?php echo $img[0];?>"><img style="height:60px;width:60px;border:2px solid gray;border-radius:50%;" src="../../API/v1/uploads/products/<?php echo $img[0];?>"></a></td>
                                             <td><?php echo base64_decode($sky->name);?></td>
                                             <td><?php echo base64_decode($sky->category);?></td>
                                             <td><?php echo $sky->brand;?></td>
                                             <td><?php echo $details->quantity;?>
                                                <?php $source->Query1("select * from tbl_unit where id='".$details->unit."'");
                                                   $units=$source->SingleData();
                                                   ;?>
                                                <?php echo $units->name;?>
                                             </td>
                                             <td>
                                                <?php
                                                   $gst=($d->percentage)/2;	  
                                                     $t=($details->price)*($ssy2[$i]);
                                                     
                                                   						    $prc=($t)*($gst)/100;
                                                   							//echo $prc;
                                                                                  $user_state=$_REQUEST['ob'];
                                                   							$vendor_state=$vendor->state;
                                                   							//echo $vendor_state;
                                                   							//$user_state=$data_add->state;
                                                   							//echo $user_state;
                                                   							if($vendor_state == $user_state)
                                                   							{
                                                   						
                                                   							echo "CGST(".$gst."%)=₹".$prc."<br>";
                                                   							$var=$var+$prc;
                                                   							echo "SGST(".$gst."%)=₹".$prc;
                                                   							} 
                                                   							else { 
                                                   							$igst=$d->percentage;
                                                   							echo "IGST(".$igst.")%=₹".$prc*2;
                                                   							$var1=$var1+$prc;
                                                   							}
                                                   							?>	
                                             </td>
											 <td>
												<?php 
                                                   echo $d->title?>
													
											 </td>
                                             <td>₹
                                                <?php 
                                                   echo $details->price?> x <?php echo $ssy2[$i]?>
                                                <?php 
                                                   //print_r($ssy[$i]);
                                                   
                                                   //$prc=(($details->price)*($ssy2[$i])*$gst)/100;
                                                   //$total2=$prc+(($prc*$gst)/100)*9;
                                                   //$total=0;
                                                   								
                                                   ?>
                                             </td>
                                          </tr>
                                          <?php } } ?>
                                       </tbody>
                                    </table>
                                    <div class="col-sm-12">
                                       <div class="shopowner-dts">
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Price</span>
                                             <span class="right-dt">₹<?php echo $subp?></span>
                                          </div>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Order Mode</span>
                                             <span class="right-dt"><?php echo $values->order_type?></span>
                                          </div>
                                          <?php if($vendor_state == $user_state)
                                             { ?>
                                          <div class="shopowner-dt-list">
                                             <p class="left-dt">CGST</p>
                                             <br>
                                             <span class="right-dt">
                                             <?php
                                                echo "CGST(".$gst."%)=₹".$var."<br>";
                                                              
                                                
                                                ?></span>
                                          </div>
                                          <div class="shopowner-dt-list">
                                             <p class="left-dt">SGST</p>
                                             <br>
                                             <span class="right-dt">
                                             <?php
                                                echo "SGST(".$gst."%)=₹".$var;
                                                
                                                ?></span>
                                          </div>
                                          <?php } else {  ?>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">IGST</span>
                                             <span class="right-dt">
                                             <?php 
                                                //$igst=$d->percentage;
                                                               echo "IGST(".$igst.")%=₹".$var1*2;
                                                
                                                ?></span>
                                          </div>
                                          <?php } ?>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">GST Number</span>
                                             <span class="right-dt"><?php echo $values->gstnumber?></span>
                                          </div>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Shipping Charge</span>
                                             <span class="right-dt">₹<?php echo $values->shipping_charge?></span>
                                          </div>
                                          <?php 
                                             if($values->coupon_id!=''){
                                             ?>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Coupon</span>
                                             <span class="right-dt "><b class="text-success"><?php echo $conn->query("SELECT * FROM `coupon` WHERE `id`='$values->coupon_id'")->fetch_assoc()['code'];?></b> Applied(<?php echo $values->c_discount?>%)</span>
                                          </div>
                                          <?php } ?>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Order Date</span>
                                             <span class="right-dt"><?php echo $values->date?></span>
                                          </div>
                                          <div class="shopowner-dt-list" >
                                             <span class="left-dt" style="font-size:23px;">Total Price</span>
                                             <span class="right-dt" style="font-size:23px;">₹<?php echo $values->total_price?></span>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="card">
                              <?php 
                                 $source->Query1("SELECT * FROM `tbl_user` WHERE `id`='$values->user_id'");
                                 $user=$source->SingleData();
                                 
                                 $source->Query1("SELECT * FROM `tbl_deliveryboy` WHERE `id`='$values->delivery_boy'");
                                 $driver=$source->SingleData();
                                 
                                 
                                 ?>
                              <h5 class="card-header">Details</h5>
                              <?php
                                 $jsonobj = $values->address_id;
                                 $obj = json_decode($jsonobj);
                                 ?>
                              <?php if($values->delivery_boy!=''){?>
                              <div class="card-body">
                                 <div class="row">
                                    <div class="col-sm-6 mb-4">
                                       <h5 class="card-title">User Details </h5>
                                       <div class="shopowner-dts">
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Name</span>
                                             <span class="right-dt"><?php echo $obj->name?></span>
                                          </div>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Mobile</span>
                                             <span class="right-dt"><?php echo $obj->mobile?></span>
                                          </div>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Email</span>
                                             <span class="right-dt"><?php echo $obj->email?></span>
                                          </div>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Address</span>
                                             <span class="right-dt"><?php echo $obj->address?>,<?php echo $obj->city?>,<?php echo $obj->state?>,<?php echo $obj->pincode?></span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-sm-6">
                                       <h5 class="card-title">Driver Details</h5>
                                       <div class="shopowner-dts">
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Name</span>
                                             <span class="right-dt"><?php echo $driver->name?></span>
                                          </div>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Mobile</span>
                                             <span class="right-dt"><?php echo $driver->mobile?></span>
                                          </div>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Email</span>
                                             <span class="right-dt"><?php echo $driver->email?></span>
                                          </div>
                                          <div class="shopowner-dt-list">
                                             <span class="left-dt">Address</span>
                                             <span class="right-dt"><?php echo $driver->address?></span>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <?php }
                                 else{
                                 ?>
                              <div class="card-body">
                                 <h5 class="card-title">User Details</h5>
                                 <div class="shopowner-dts">
                                    <div class="shopowner-dt-list">
                                       <span class="left-dt">Name</span>
                                       <span class="right-dt"><?php echo $user->name?></span>
                                    </div>
                                    <div class="shopowner-dt-list">
                                       <span class="left-dt">Mobile</span>
                                       <span class="right-dt"><?php echo $user->mobile?></span>
                                    </div>
                                    <div class="shopowner-dt-list">
                                       <span class="left-dt">Email</span>
                                       <span class="right-dt"><?php echo $user->email?></span>
                                    </div>
                                    <div class="shopowner-dt-list">
                                       <span class="left-dt">Address</span>
                                       <span class="right-dt"><?php echo $obj->address?>,<?php echo $obj->city?>,<?php echo $obj->state?>,<?php echo $obj->pincode?></span>
                                    </div>
                                 </div>
                              </div>
                              <?php }?>
                           </div>
                           <!--End Order Tracking-->
                           <hr>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--end page-content-wrapper-->
         </div>
         <!--end page-wrapper-->
         <!--start overlay-->
         <div class="overlay toggle-btn-mobile"></div>
         <!--end overlay-->
         <!-- Modal -->
         <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
               <div class="modal-content">
                  <div class="modal-header">
                     <h5 class="modal-title" id="exampleModalLabel">Change Status</h5>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                     </button>
                  </div>
                  <div class="modal-body">
                     <form method="post" id="ChangeStatus" >
                        <input name="id" type="hidden" type="text" value="<?php echo $values->id;?>"/>
                        <div class="form-group">
                           <label> Status</label>
                           <select class="form-control" name="status" >
                              <option value="0">Pending</option>
                              <option value="1">Processed</option>
                              <option value="2">Cancel</option>
                              <option value="3">Shipped</option>
                              <option value="4">Complete</option>
                           </select>
                        </div>
                        <button type="submit" class="btn btn-success">Update Status</button>
                     </form>
                  </div>
               </div>
            </div>
         </div>
         <!-- Modal -->
         <div class="modal fade" id="invoiceModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
               <div class="modal-content" id="invoice_1">
                  <div class="modal-header" >
                     <h5 class="modal-title" id="exampleModalLabel">
                        <h4>Order ID : <?php echo $values->order_id;?></h4>
                     </h5>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                     </button>
                  </div>
                  <div class="modal-body" id="invoice" style="padding:2%">
                     <style>
                        #customers {
                        font-family:sans-serif;
                        border-collapse: collapse;
                        width: 100%;
                        // font-size:10px;
                        } 
                        #customers td, #customers th {
                        border: 1px solid black;
                        }
                        #customers tr:nth-child(even){background-color: #f2f2f2;}
                        #customers tr:hover {background-color: #ddd;}
                        #customers th {
                        text-align: left;
                        color: black;
                        font-weight:bold;
                        }
                        #customersr {
                        font-family:sans-serif;
                        border-collapse: collapse;
                        width: 100%;
                        // font-size:10px;
                        }
                        #customersr td, #customersr th {
                        border: 1px solid #ddd;
                        padding: 8px;
                        }
                        #customersr tr:nth-child(even){background-color: #f2f2f2;}
                        #customersr tr:hover {background-color: #ddd;}
                        #customersr th {
                        padding-top: 12px;
                        padding-bottom: 12px;
                        text-align: left;
                        background-color: #04AA6D;
                        color: white;
                        }
                        #customerst {
                        font-family:sans-serif;
                        border-collapse: collapse;
                        width: 100%;
                        // font-size:10px;
                        }
                        #customerst td, #customerst th {
                        border: 1px solid #ddd;
                        padding: 8px;
                        }
                        #customerst tr:nth-child(even){background-color: #f2f2f2;}
                        #customerst tr:hover {background-color: #ddd;}
                        #customerst th {
                        padding-top: 12px;
                        padding-bottom: 12px;
                        text-align: left;
                        background-color: #04AA6D;
                        color: white;
                        }
                        #tbl{
                        width:750px;
                        }
                        @media only screen and (max-width: 768px) {
                        #tbl{
                        width:430px;
                        }
                        }
                        @media only screen and (max-width: 600px) {
                        #tbl{
                        width:320px !important;
                        }
                        }
                        h5{
                        font-size:13px;
                        }
                     </style>
                     <div style="border : 0px solid black;text-align:;" >
                        <?php $source->Query("SELECT * FROM `settings` where name='logo'"); $logo=$source->Single(); ?>
                        <div class="row">
                           <?php //var_dump($logo);?>
                           <div class="col-sm-6"><img src="../upload/banner/<?php echo $logo->value;?>" style="height:70px;width:70px"></div>
                           <div class="col-sm-6 text-right">
                              <h4>My Advika Pvt. Ltd.</h4>
                              <h5>Email : bills@myadvika.com</h5>
                              <h5>Contact  : +919471578200</h5>
                              <h5>Address  : Harmu Housing Coloney, Ranchi, Jharkhand - 834002</h5>
                              <h5>GST Number  : 20AAOCM9362N1ZW</h5>
                           </div>
                        </div>
                        <p style="font-size:15px;font-weight:bold;text-align:center;margin:0px;padding:0px;">Tax Invoice</p>
                        <table id="customers" class="table" >
                           <tr style="height:5px !important;">
                              <th width="60">Sr. No.</th>
                              <th width="300">Product Name</th>
                              <th>Quantity</th>
                              <th width="120">MRP</th>
                              <th width="120">Price</th>
                              <th width="120">Tax</th>
                             <!-- <th width="120">GST Number</th>-->
                              <th width="70">Total</th>
                           </tr>
                           <?php
                              $variant_id = $values->variant_id;
                              $variant_id=explode(",",$variant_id);


							  $str = $values->product_id;
                              $ssy=(explode(",",$str));
                              $str2 = $values->qty;
                              $ssy2=(explode(",",$str2));
                              $s=1;
                              $total=0;
                              
                              for($i=0;$i<sizeOf($ssy);$i++){
                              if($ssy[$i]!=''){
                              	// $sky=$conn->query("SELECT * FROM `product` WHERE `id`='".$ssy[$i]."'")->fetch_assoc();
                              	
                              	$source->Query1("SELECT *,(SELECT name FROM `tbl_category` c where c.id=p.category) as category,(SELECT image FROM `product_images` i where i.product_id=p.id limit 1) as images,(SELECT name FROM `tbl_brands` b where b.id=p.brand) as brand FROM `product` p where `id`='$ssy[$i]' ");
                              	$sky=$source->SingleData();
                              	$source->Query1("SELECT * FROM `tbl_product_details` WHERE id='".$variant_id[$i]."'");
                              	$details=$source->SingleData();
                              	
                              	$subp=$subp+($details->price*$ssy2[$i]);
                              	
                              	$source->Query1("SELECT * FROM `tbl_tax` WHERE id='".$details->tax."'");
                              	$d=$source->SingleData();
                              ?>	
                           <tr>
                              <td><?php echo $s++; ?></td>
                              <td><?php echo base64_decode($sky->name);?></td>
                              <td><?= $ssy2[$i]; ?></td>
                              <td><?php echo $details->mrp;?></td>
                              <td><?php echo $details->price;?></td>
                              <td>
                                 <?php
                                    $gst=($d->percentage)/2;	  
                                      $t=($details->price)*($ssy2[$i]);
                                      
                                    						    $prc=($t)*($gst)/100;
                                    							//echo $prc;
                                                                   $user_state=$_REQUEST['ob'];
                                    							$vendor_state=$vendor->state;
                                    							//echo $vendor_state;
                                    							//$user_state=$data_add->state;
                                    							//echo $user_state;
                                    							if($vendor_state == $user_state)
                                    							{
                                    						
                                    							echo "CGST(".$gst."%)=₹".$prc."<br>";
                                    							$var=$var+$prc;
                                    							echo "SGST(".$gst."%)=₹".$prc."<br>";
																echo "$d->title";
																
                                    							} 
                                    							else { 
                                    							$igst=$d->percentage;
                                    							echo "IGST(".$igst.")%=₹".($prc*2)."<br>";
																echo "$d->title";
                                    							$var1=$var1+$prc;
																
                                    							}
                                    							?>		
                              </td>
                              <!--td>
                                 <?php 
                                   # echo #$values->gstnumber;
                                    
                                    ?>
                              </td-->
                              <td>₹<?php echo $details->price*$ssy2[$i];$total+=$details->price*$ssy2[$i]; ?></td>
                           </tr>
                           <?php }} ?>
                        </table>
                        <table id="customers" class="table">
						<tr >
                              <td style="text-align:left">Order Date</td>
                              <td style="text-align:right"><?php echo $values->date?></td>
                           </tr>
						    <tr style="height:7px !important;">
                              <td style="text-align:left">Shipping To</td>
                              <td style="text-align:right"><?php echo $obj->name?>,<?php echo $obj->mobile?>,<?php echo $obj->address?>,<?php echo $obj->city?>,<?php echo $obj->state?>,<?php echo $obj->pincode?></td>
                           </tr>
						    <tr style="height:7px !important;">
                              <td style="text-align:left">Shipping From</td>
                              <td style="text-align:right"><?php ?></td>
                           </tr>
						   
                           <tr >
                              <td style="text-align:left">Price</td>
                              <td style="text-align:right">&#x20B9;<?php echo $total;?></td>
                           </tr>
                           
                           <tr >
                              <td style="text-align:left">GST Number</td>
                              <td style="text-align:right"><?php echo $values->gstnumber?></td>
                           </tr>
                           <?php if($vendor_state == $user_state) { ?>
                           <tr >
                              <td style="text-align:left">CGST</td>
                              <td style="text-align:right">&#x20B9;<?php echo ($var)/2;?></td>
                           </tr>
                           <tr >
                              <td style="text-align:left">SGST</td>
                              <td style="text-align:right">&#x20B9;<?php echo ($var)/2;?></td>
                           </tr>
                           <?php } else { ?>
                           <tr >
                              <td style="text-align:left">IGST</td>
                              <td style="text-align:right">&#x20B9;<?php echo ($var1) ;?></td>
                           </tr>
                           <?php 	} ?>
                          
                           <tr style="font-size:14px;">
                              <td style="text-align:left"><b>Total Price</b></td>
                              <td style="text-align:right"><b> &#x20B9;<?php echo $values->total_price?></b></td>
                           </tr>
                           <tr style="font-size:14px;">
                              <td style="text-align:left"><b>Transport/Courier Name</b></td>
                              <td style="text-align:right"></td>
                           </tr>
                           <tr style="font-size:14px;">
                              <td style="text-align:left"><b>Licence Number</b></td>
                              <td style="text-align:right"></b></td>
                           </tr>
                           <tr style="font-size:14px;">
                              <td style="text-align:left"><b>Driver Name</b></td>
                              <td style="text-align:right"></td>
                           </tr>
                           <tr style="font-size:14px;">
                              <td style="text-align:left"><b>Driver Mobile No.</b></td>
                              <td style="text-align:right"></td>
                           </tr>
                           <tr style="font-size:14px;">
                              <td style="text-align:left"><b>Signature</b></td>
                              <td style="text-align:right"></td>
                           </tr>
                        </table>
                     </div>
                  </div>
                  <div class="col-sm-4 mb-4">
                     <button type="button" onclick="printDiv('invoice_1')" id="printInvoice" class="btn btn-secondary"><i class="fa fa-print"></i> Print</button>
                  </div>
               </div>
            </div>
         </div>
         <?php require'Footer.php';?>
      </div>
      <!-- end wrapper -->
      <div class="modal fade" id="exampleModall" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Change Status</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <form method="post" id="ChangeStatus1" >
                  <div class="modal-body">
				  
                  </div>
               </form>
            </div>
         </div>
      </div>
      <?php require'JsLink.php';?>
      <script>	
         $("#ChangeStatus").on('submit', function(e) {
         
         e.preventDefault();
         var data = new FormData(this);
         //alert(data);
         
         $.ajax({
         	type: 'POST',  
         	url: '../code/ManageStatus?flag=ChangeOrderStatus',
         	data: data,
         	cache: false,
         	contentType: false,
         	processData: false,
         	
         	success: function(response) {
         		alert(response);
         		var  response= JSON.parse(response);
         		const Toast = Swal.mixin({  
         		  toast: true,
         		  position: 'top-end',
         		  showConfirmButton: false,
         		  timer: 2000,
         		  timerProgressBar: true,
         		  didOpen: (toast) => {
         			toast.addEventListener('mouseenter', Swal.stopTimer)
         			toast.addEventListener('mouseleave', Swal.resumeTimer)
         		  }
         		})
         
         		Toast.fire({
         		  icon: response.res,
         		  title: response.msg
         		})
         		
         		if( response.res=='success'){
         			window.setTimeout(function () {
         			  window.location.reload();
         			}, 2000);
         		}
         		
         	},
         	error: function() {
         		alert('error123');
         	}
         });
         
         })
      </script>
      <script type="text/javascript">
         function printDiv(id){
         	$(".close").hide();
         	$("#printInvoice").hide();
         	var printContents = document.getElementById(id).innerHTML;
         	var originalContents = document.body.innerHTML;
         	document.body.innerHTML = printContents;
         	window.print();
         	document.body.innerHTML = originalContents;
         	$(".close").show();
         	$("#printInvoice").show();
         }	
         $(".close").click(function (){
         	$("#invoiceModal").hide();
         })	
         function PrintInvoice(){
         	var print_div = document.getElementById("invoice");
         	var print_area = window.open();
         	print_area.document.write(print_div.innerHTML);
         	print_area.document.close();
         	print_area.focus();
         	print_area.print();
         	print_area.close();
         }
         
      </script>
      <script type="text/javascript" src="ajax/form.js"></script>
      <script type="text/javascript">
         function AssignDelivery(id)
         {
         	
         	//alert(id);
         	
         	$("#exampleModall").modal("show");
                   $("#exampleModall .modal-body").html("<center><i class='fa fa-4x fa-spin fa-spinner'></i></center>");
                   $("#exampleModall .modal-body").load("AssignDeliveryBoy?id="+id);
         	
         }
         
         $(".btnclose").click(function(){
         	$("#exampleModall").modal("hide");
         })
             
      </script>
      <script>	
         $("#ChangeStatus1").on('submit', function(e) {
             
             e.preventDefault();
             var data = new FormData(this);
             //alert(data);
             
             $.ajax({
             	type: 'POST',  
             	url: '../code/ManageStatus?flag=delivery_boy_status',
             	data: data,
             	cache: false,
             	contentType: false,
             	processData: false,
             	
             	success: function(response) {
             		//alert(response);
             		var  response= JSON.parse(response);
             		const Toast = Swal.mixin({  
             		  toast: true,
             		  position: 'top-end',
             		  showConfirmButton: false,
             		  timer: 2000,
             		  timerProgressBar: true,
             		  didOpen: (toast) => {
             			toast.addEventListener('mouseenter', Swal.stopTimer)
             			toast.addEventListener('mouseleave', Swal.resumeTimer)
             		  }
             		})
             
             		Toast.fire({
             		  icon: response.res,
             		  title: response.msg
             		})
             		
             		if( response.res=='success'){
             			window.setTimeout(function () {
             			  window.location.reload();
             			}, 2000);
             		}
             		
             	},
             	error: function() {
             		alert('error123');
             	}
             });
             
             })
          
      </script>
   </body>
</html>