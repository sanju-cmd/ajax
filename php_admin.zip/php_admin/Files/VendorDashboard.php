<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
	   <style>
   
.shop-dt-left {
    margin-left: 20px;
}

.shop-dt-left h4 {
    color: #2b2f4c;
    font-size: 18px;
    font-weight: 500;
    margin-bottom: 7px;
    text-align: left;
}

.shop-dt-left span {
    color: #3e3f5e;
    font-size: 14px;
    font-weight: 400;
    text-align: left;
}

.shopowner-dt-left {
    margin-left: 0;
	text-align: center;
}

.shopowner-dt-left h4 {
    color: #2b2f4c;
    font-size: 18px;
    font-weight: 500;
    margin-bottom: 7px;
}

.shopowner-dt-left span {
    color: #3e3f5e;
    font-size: 14px;
    font-weight: 400;
    text-align: left;
}

.shopowner-dts {
    margin-top: 20px;
    border: 1px solid #efefef;
    border-radius: 3px;
}

.shopowner-dt-list {
    display: flex;
    align-items: start;
    padding: 10px;
    border-bottom: 1px solid #efefef;
	width: 100%;
}

.shopowner-dt-list:last-child {
    border-bottom: 0;
}

.left-dt {
    color: #2b2f4c;
    font-size: 14px;
    font-weight: 500;
    margin-bottom: 0;
    text-align: left;
	width: 50%;
}

.right-dt {
    color: #3e3f5e;
    font-size: 14px;
    font-weight: 400;
    margin-bottom: 0;
    margin-left: auto;
    text-align: right;
	width: 50%;
}

   </style>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';
		if(empty($_REQUEST['id'])){
		header("location:ManageVendor");
		}
		else{
			$id=base64_decode($_REQUEST['id']);
			$source->Query("SELECT * FROM `tbl_vendor` WHERE `id`=?",[$id]);
			$data=$source->Single();
			
		}
		?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">  Vendor Dashboard</h4>
							</div>
							<hr>
									<div class="card">
  <div class="card-header">
    <?php echo $data->sponsorID?>
  </div>
  <div class="card-body">
   <div class="row">
   <div class="col-sm-4">
   <img class="mt-4" style="height:150px;width:150px;border-radius:50%;"src="../../API/v1/uploads/Vendor/<?php echo $data->image?>">
   </div>
   <div class="col-sm-8">
   <div class="shopowner-dts">
												<div class="shopowner-dt-list">
													<span class="left-dt">Name</span>
													<span class="right-dt"><?php echo $data->name;?></span>
												</div>
												
												<div class="shopowner-dt-list">
													<span class="left-dt">Mobile</span>
													<span class="right-dt"><?php echo $data->mobile;?></span>
												</div>
												<div class="shopowner-dt-list">
													<span class="left-dt">Email</span>
													<span class="right-dt"><?php echo $data->email;?></span>
												</div>
												<div class="shopowner-dt-list">
													<span class="left-dt">GST</span>
													<span class="right-dt"><?php echo $data->gst;?>%</span>
												</div>
												<div class="shopowner-dt-list">
													<span class="left-dt">Wallet Amount</span>
													<span class="right-dt">&#x20B9;<?php echo $data->wallet;?></span>
												</div>
												<div class="shopowner-dt-list">
													<span class="left-dt">Total Referrals</span>
													<span class="right-dt"><?php $source->Query1("SELECT * FROM `tbl_vendor` where delete_status='false' and referral_id='$data->sponsorID'"); echo $count=$source->NumRows();?></span>
												</div>
												
											</div>
   </div>
   </div>
  </div>
</div>


<div class="row">
						<div class="col-12 col-lg-3">
						<a href="VendorAllOrder?id=<?php echo base64_encode($data->id);?>">
							<div class="card radius-15 bg-voilet">
								<div class="card-body">
									<div class="d-flex align-items-center">
										<div>
											<h2 class="mb-0 text-white"><?php $source->Query("SELECT * FROM `Orders` where vendor_id='$data->id' "); echo $count=$source->CountRows(); ?><i class='bx bxs-up-arrow-alt font-14 text-white'></i> </h2>
										</div>
										<div class="ml-auto font-35 text-white"><i class="bx bx-cart-alt"></i>
										</div>
									</div>
									<div class="d-flex align-items-center">
										<div>
											<p class="mb-0 text-white">Total Order</p>
										</div>
										<div class="ml-auto font-14 text-white">View All</div>
									</div>
								</div>
							</div></a>
						</div>
						<div class="col-12 col-lg-3">
						<a href="VendorCancelOrder?id=<?php echo base64_encode($data->id);?>">
							<div class="card radius-15 bg-danger">
								<div class="card-body">
									<div class="d-flex align-items-center">
										<div>
											<h2 class="mb-0 text-white"><?php $source->Query("SELECT * FROM `Orders` where vendor_id='$data->id' and status='2' "); echo $count=$source->CountRows(); ?><i class='bx bxs-down-arrow-alt font-14 text-white'></i> </h2>
										</div>
										<div class="ml-auto font-35 text-white"><i class="bx bx-cart-alt"></i>
										</div>
									</div>
									<div class="d-flex align-items-center">
										<div>
											<p class="mb-0 text-white">Cancelled Order</p>
										</div>
										<div class="ml-auto font-14 text-white">View All</div>
									</div>
								</div>
							</div></a>
						</div>
						<div class="col-12 col-lg-3">
						<a href="VendorCompleteOrder?id=<?php echo base64_encode($data->id);?>">
							<div class="card radius-15 bg-success">
								<div class="card-body">
									<div class="d-flex align-items-center">
										<div>
											<h2 class="mb-0 text-white"><?php $source->Query("SELECT * FROM `Orders` where vendor_id='$data->id' and status='4'"); echo $count=$source->CountRows(); ?><i class='bx bxs-up-arrow-alt font-14 text-white'></i> </h2>
										</div>
										<div class="ml-auto font-35 text-white"><i class="bx bx-cart-alt"></i>
										</div>
									</div>
									<div class="d-flex align-items-center">
										<div>
											<p class="mb-0 text-white">Completed Orders</p>
										</div>
										<div class="ml-auto font-14 text-white">View All</div>
									</div> 
								</div>
							</div></a>
						</div>
						
						<div class="col-12 col-lg-3">
						<a href="ViewVendorReferrals?id=<?php echo base64_encode($data->sponsorID);?>"> 
							<div class="card radius-15 bg-sunset">
								<div class="card-body">
									<div class="d-flex align-items-center">
										<div>
											<h2 class="mb-0 text-white"><?php $source->Query("SELECT * FROM `tbl_vendor` where delete_status='false' and referral_id='$data->sponsorID' "); echo $count=$source->CountRows(); ?><i class='bx bxs-up-arrow-alt font-14 text-white'></i> </h2>
										</div>
										<div class="ml-auto font-35 text-white"><i class="bx bx-user"></i>
										</div>
									</div>
									<div class="d-flex align-items-center">
										<div>
											<p class="mb-0 text-white">Referrals</p>
										</div>
										<div class="ml-auto font-14 text-white">View All</div>
									</div>
								</div>
							</div></a>
						</div>
						
					</div>
					<!--end row-->
					
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0"> All Vendor Referrals</h4>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Sponsor ID</th>
											<th>Name</th>
											<th>Email</th>
											<th>Mobile</th>
											<th>GST</th>
											<th>Wallet Amount</th>
											<th>Total Referrals</th>
											<th>Profile</th>
											<th>Date/Time</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$source->Query("SELECT * FROM `tbl_vendor` where delete_status='false' and referral_id='$data->sponsorID' ORDER BY `id` DESC");
										while ($values=$source->Single()){
											
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											<td><a href="VendorDashboard?id=<?php echo base64_encode($values->id);?>"><?php echo $values->sponsorID;?></td>
											<td><?php echo $values->name;?></td>
											<td><?php echo $values->email;?></td>
											<td><?php echo $values->mobile;?></td>
											<td><?php echo $values->gst;?>%</td>
											<td>&#x20B9;<?php echo $values->wallet;?></td>
											<td><?php $source->Query1("SELECT * FROM `tbl_vendor` where delete_status='false' and referral_id='$values->sponsorID'"); echo $count=$source->NumRows();?></td>
											<td><a href="../../API/v1/uploads/Vendor/<?php echo $values->image;?>" target="_blank"><img src="../../API/v1/uploads/Vendor/<?php echo $values->image;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
											<td><?php echo $values->date;?><br><?php echo $values->time;?></td>
											<td>
												<a class="btn btn-outline-warning btn-circle" title="Edit" href="UpdateVendor?id=<?php echo base64_encode($values->id);?>"><i class="fa fa-pencil"></i></a>
												
												<a class="btn btn-outline-success btn-circle" title="View Dashboard" href="VendorDashboard?id=<?php echo base64_encode($values->id);?>"><i class="fa fa-eye"></i></a>
									
												<button class="btn btn-outline-danger " title="Delete" onclick="Status(<?php echo $values->id?>,'delete_status','true','tbl_vendor','Delete')"><i class="fa fa-trash "></i></button>
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
</body>

</html>