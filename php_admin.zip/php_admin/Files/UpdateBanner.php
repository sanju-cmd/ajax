<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
	<style>
		#img-preview {
	  display: none; 
	  width: 155px;   
	  border: 2px dashed #333;  
	  margin-bottom: 20px;
	}
	#img-preview img {  
	  width: 100%;
	  height: auto; 
	  display: block;   
	}
	
	[type="file"] {
	  height: 0;  
	  width: 0;
	  overflow: hidden;
	}
	[type="file"] + label {
	  font-family: sans-serif;
	  background: #f44336;
	  padding: 10px 30px;
	  border: 2px solid #f44336;
	  border-radius: 3px;
	  color: #fff;
	  cursor: pointer;
	  transition: all 0.2s;
	}
	[type="file"] + label:hover {
	  background-color: #fff;
	  color: #f44336;
	}
	
	</style>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php 
		require'Header.php';
		if(empty($_REQUEST['id'])){
		header("location:ManageBanner");
		}
		else{
			$id=base64_decode($_REQUEST['id']);
			$source->Query("SELECT * FROM `tbl_banner` WHERE `id`=?",[$id]);
			$data=$source->Single();
			
		}
		?>
		
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					<div class="row">
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body p-5">
									<div class="card-title d-flex align-items-center">
										
										<h4 class="mb-0 text-primary">Update Bannner</h4>
									</div>
									<hr>
									<form  id="FormSubmit" novalidate="">
                     
										<input type="hidden" name="location" id="location" value="../code/ManageBanner?flag=Update">
										<input type="hidden" name="id"  value="<?php echo $id;?>">
									<div class="form-body tel-center">
									<div class="form-group col-md-4">
												<label>URL<sup class="text-danger">*</sup></label>
												<input type="text" class="form-control" name="url" value="<?php echo $data->url;?>">
											</div>
										<div class="form-row">
										<div class="col-sm-3 mb-3">
                                            <div class="form-group">
											<p></p><br>
                                                <a href="../upload/banner/<?php echo $data->image;?>" target="_blank"><img src="../upload/banner/<?php echo $data->image;?>" style="width:100%; height:100px;"></a>
                                            </div>
                                        </div>
											<div class="form-group col-sm-6">
											<label >Image<sup class="text-danger">*</sup></label>
												<!--<div class="custom-file">
													<input type="file" class="custom-file-input" name="image" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
													<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
											    </div>-->
												<div>
													
													<input type="file" accept="image/*"  id="choose-file" name="image" />
													<label for="choose-file">Choose File</label>
													<div id="img-preview"></div>
												</div>
											
											
										</div>
										
                                        <div class="form-group col-md-4">
												<button type="submit" class="btn btn-primary px-5 mt-4 p-2 radius-30" id="uploadBtn">Submit <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>
											</div>
										<!--<button type="submit" class="btn btn-primary px-5 radius-30" id="uploadBtn">Update <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>-->
									</div>
									</form>
								</div>
							</div>
						</div>
						
					</div>
					<!--end row-->
					
					
				
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--End Back To Top Button-->
		<?php require'Footer.php';?>
	</div>
	
	<?php require'JsLink.php';?>
	 <script type="text/javascript" src="../ajax/SignUp.js"></script>
</body>
<script>
	
	const chooseFile = document.getElementById("choose-file");
	const imgPreview = document.getElementById("img-preview");
	
	chooseFile.addEventListener("change", function () {
	  getImgData();
	  
	});
	
	function getImgData() {
	  const files = chooseFile.files[0];
	  if (files) {
		const fileReader = new FileReader();
		fileReader.readAsDataURL(files);
		fileReader.addEventListener("load", function () {
		  imgPreview.style.display = "block";
		  imgPreview.innerHTML = '<img src="' + this.result + '" />';
		});    
	  }
	}
	
	
	
</script>

</html>