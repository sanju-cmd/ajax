<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Manage Customer</h4>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Level</th>
											<th>Commission</th>
											<th>Date</th>
											<th>Time</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$source->Query("SELECT * FROM `level_commission` ");
										while ($values=$source->Single()){
											
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											<td>Level <?php echo $values->id;?></td>
											<td><?php echo $values->commission;?>%</td>
											<td><?php echo $values->date;?></td>
											<td><?php echo $values->time;?></td>
											<td><button class="btn btn-outline-success  btn-sm " title="Update" onclick="Update(<?php echo $values->id?>)"><i class="fa fa-edit "></i></button></td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<div class="modal fade" id="update" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog" role="document">
			<form method="post"  id="FormSubmit">
			<input type="hidden" name="location" id="location" value="../code/ManageBanner?flag=updatecommission">
									
			<div class="modal-content">
			  <div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Update Commission</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button> 
			  </div>
			  <div class="modal-body">
				
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary px-5" id="uploadBtn">Submit <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>
			  </div>
			</div>
			</form>
		  </div>
		</div>
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
	
	 <script type="text/javascript" src="../ajax/SignUp.js"></script>
	<script>
		function Update(id){
			$("#update").modal("show");
            $("#update .modal-body").html("<center><i class='fa fa-4x fa-spin fa-spinner'></i></center>");
            $("#update .modal-body").load("update-commission?id="+id);
		}
	</script>
</body>

</html>