<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					<div class="row">
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body p-5">
									<div class="card-title d-flex align-items-center">
										
										<h4 class="mb-0 text-primary">Add Variants  </h4>
									
									</div>
									<hr>
									<form  id="FormSubmit" class="FormSubmit" novalidate="">
                     
										<input type="hidden" name="location" id="location" value="../code/ManageProduct?flag=AddVariant">
										
										<input type="hidden" name="product_id"  value="<?= base64_decode($_REQUEST['id']); ?>">
										
										<input type="hidden" name="url"  value="AddVariant?id=<?= $_REQUEST['id']; ?>">
									
									<div class="form-body">
									
										<div class="form-row">
										<div class="col-sm-4 ">
                                            <div class="form-group">
                                                <label >Model<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="model"  placeholder="Model " required />
                                            </div>
										</div>
										
										<div class="col-sm-4 ">
                                            <div class="form-group">
                                                <label >Quantity<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="quantity"  placeholder="Quantity " required />
                                            </div>
										</div>
										
										<div class="col-sm-4">
                                            <div class="form-group">
                                                <label >Unit<sup class="text-danger">*</sup></label>
                                                <select class="form-control" name="unit" id="unit">  
													<?php
													  $source->Query("SELECT * FROM `tbl_unit` WHERE `delete_status`='false' ORDER BY `id` DESC");
													  while($values=$source->Single()){
														  
														  if($var_data->unit==$values->id){
															  echo '<option value='.$values->id.' selected> '.$values->name.'</option>';
														  }else{
															  echo '<option value='.$values->id.'>'.$values->name.'</option>';
														  }
														  
													  
													  }
													  
													?>
												</select>
                                            </div>
										</div>
											
										<div class="col-sm-6">
                                            <div class="form-group">
                                                <label >Stock<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="stock" placeholder="Stock "   required />
                                            </div>
										</div>
										<div class="col-sm-6">
                                            <div class="form-group">
                                                <label>HSN<sup class="text-danger">*</sup></label>
												
                                                <select class="form-control" name="tax">  
													<option selected="" disabled="">Select HSN</option>
													<?php
													  $source->Query("SELECT * FROM `tbl_tax` WHERE `delete_status`='false' ORDER BY `id` DESC");
													  while($values=$source->Single()){
														  
														if($var_data->tax==$values->id){
															   echo '<option value='.$values->id.' selected>'.$values->title."(".$values->percentage."%)".'</option>';
														  }else{
															  echo '<option value='.$values->id.'>'.$values->title."(".$values->percentage."%)".'</option>';  
														  }
													  }
													  
													?>
												</select>
                                            </div>
										</div>

									
											
											
										
										<div class="col-sm-4 ">
                                            <div class="form-group">
                                                <label >Product MRP<sup class="text-danger">*</sup></label>
                                                <input type="number" class="form-control"  id="mrp" name="mrp" oninput="Price()" placeholder="MRP" required />
                                            </div>
										</div>	
										<div class="col-sm-4 ">
                                            <div class="form-group">
                                                <label >Selling Price<sup class="text-danger">*</sup></label>
                                                <input type="number" class="form-control" id="price"  name="price" oninput="Price()" placeholder="Price" required />
                                            </div>
										</div>	
										<div class="col-sm-4 ">
                                            <div class="form-group">
                                                <label >Discount<sup class="text-danger">*</sup></label>
                                                <input type="number" readonly class="form-control" id="discount" name="discount" placeholder="Discount" required />
                                            </div>
										</div>										
											
											
											
										<div class="col-sm-6">
                                            <div class="form-group">
                                                <label >Order Limit<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="order_limit" placeholder="Order Limit "  required />
                                            </div>
										</div>
										<div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Minimum Order Limit<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="min_order_limit" placeholder="Minimum Order Limit "  />
                                            </div>
										</div>
										</div>
										
										<button type="submit" class="btn btn-primary px-5 radius-30" id="uploadBtn" >Add Variant <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>
										
									</div>
									</form>
								</div>
							</div>
						</div>
						
					</div> 
					<!--end row-->
					
					
				
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--End Back To Top Button-->
		<?php require'Footer.php';?>
	</div>
	
	<?php require'JsLink.php';?>
	 <script type="text/javascript">
		function Price(){
		  var mrp=$("#mrp").val();
		  var price=$("#price").val();
		  var discount=((mrp-price)/mrp*100).toFixed(2);
		  $("#discount").val(discount);
		}
		
		$("#FormSubmit").on('submit', function(e) {
	 // $("#pageloader").fadeIn();
	e.preventDefault();
	var data = new FormData(this);
	// alert(data);
	$.ajax({
		type: 'POST',
		url: data.get('location'),
		data: data,
		cache: false,
		contentType: false,
		processData: false,
		 beforeSend: function() {
			$("#uploadBtn").attr("disabled", true);
			$('#uploadSpin').show();
		},
		success: function(response) {
			// alert(response);
			 $("#pageloader").fadeOut();
			var  response= JSON.parse(response);
			$("#uploadBtn").removeAttr("disabled");
			$('#uploadSpin').hide();
			if(response.res == 'success'){
				$.notify(response.msg,'success');
				 window.setTimeout(function() {
					 window.location.href=response.url;
				 }, 800);
			}
			else if(response.res == 'otp'){
				// alert("ok");
				$("#otp").show();
				$("#SelectLogin").val(response.otp);
				$("#EmailPwd").prop('readonly', true);
				$.notify(response.msg,'success');
			}else if(response.res=='newPwd'){
				$.notify(response.msg,'success');
				setInterval(function () {
				   location.href=response.url;
			   },3000)
			}else{
				$.notify(response.msg,'error');
			}
		},
		error: function() {
			 $("#uploadBtn").removeAttr("disabled");
			 $('#uploadSpin').hide();
			$.notify('Something went wrong','success');
		}
	});
})

	
    </script>
		
</body>

</html>