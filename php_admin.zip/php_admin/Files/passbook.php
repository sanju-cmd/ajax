<?php 
require'../init.php';
$id=$_REQUEST['id'];
$source->Query("SELECT * from account_kyc where id='$id'");
$data=$source->Single();
if($data->user_type=='User'){
?>
<img height="300" width="100%" src="../../API/v1/uploads/user/<?php echo $data->passbook_img;?>"/>
<?php }elseif($data->user_type=='Vendor'){?>
<img height="300" width="100%" src="../../API/v1/uploads/Vendor/<?php echo $data->passbook_img;?>"/>
<?php }elseif($data->user_type=='Manager'){?>
<img height="300" width="100%" src="../../API/v1/uploads/manager/<?php echo $data->passbook_img;?>"/>
<?php }?>