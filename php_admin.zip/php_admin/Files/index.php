<?php 
	
	header('location:Login');
	
 ?>