<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
		<style>
	#img-preview {
	  display: none; 
	  width: 155px;   
	  border: 2px dashed #333;  
	  margin-bottom: 20px;
	}
	#img-preview img {  
	  width: 100%;
	  height: auto; 
	  display: block;   
	}
	
	[type="file"] {
	  height: 0;  
	  width: 0;
	  overflow: hidden;
	}
	[type="file"] + label {
	  font-family: sans-serif;
	  background: #f44336;
	  padding: 10px 30px;
	  border: 2px solid #f44336;
	  border-radius: 3px;
	  color: #fff;
	  cursor: pointer;
	  transition: all 0.2s;
	}
	[type="file"] + label:hover {
	  background-color: #fff;
	  color: #f44336;
	}
	
	</style>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					<div class="row">
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body p-5">
									<div class="card-title d-flex align-items-center">
										
										<h4 class="mb-0 text-primary">Add Vendor</h4>
									</div>
									<hr>
									<form  id="FormSubmit" novalidate="">
                     
										<input type="hidden" name="location" id="location" value="../code/ManageVendor?flag=Add">
									
									<div class="form-body">
									
										<div class="form-row">
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Referal ID<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="referal" placeholder="Referal ID" required />
                                            </div>
                                    </div>
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Shop Name<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="shopname" placeholder="Shop Name" required />
                                            </div>
                                    </div>
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Name<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="name" placeholder="Name" required />
                                            </div>
                                    </div>
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Owner Name<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="oname" placeholder="Name" required />
                                            </div>
                                    </div>
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Email<sup class="text-danger">*</sup></label>
                                                <input type="email" class="form-control" name="email" placeholder="example@gmail.com" required />
                                            </div>
                                    </div>
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Mobile<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="mobile" placeholder="Mobile" required />
                                            </div>
                                    </div>
									
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >GST<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="gst" placeholder="GST" required />
                                            </div>
                                    </div>
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Account Holder Name<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="a_holder" placeholder="Account Holder Name" required />
                                            </div>
                                    </div>
									
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Account Number<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="accountname" placeholder="Account Number" required />
                                            </div>
                                    </div>
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >IFSC Code<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="ifsccode" placeholder="IFSC Code" required />
                                            </div>
                                    </div>
									
									
									
									
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >AadharCard<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="adharcard" placeholder="AadharCard" required />
                                            </div>
                                    </div>
									
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >PanCard<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="pancard" placeholder="PanCard" required />
                                            </div>
                                    </div>	
									
									
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Shop Address<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="shopaddress" placeholder="Shop Address" required />
                                            </div>
                                    </div>
																		<!--div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Address<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="address" placeholder="Enter Address" required />
                                            </div>
                                    </div-->
									
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >State<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="state" placeholder="Shop State" required />
                                            </div>
                                    </div>
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >City<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="city" placeholder="Shop City" required />
                                            </div>
                                    </div>
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Pin Code<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="pincode" placeholder="Shop Pincode" required />
                                            </div>
                                    </div>
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Password<sup class="text-danger">*</sup></label>
                                                <input type="text" value="123456" class="form-control" name="password" placeholder="Enter your Password" required />
                                            </div>
                                    </div>
								
											<div class="form-group col-md-6">
											<label >Profile<sup class="text-danger">*</sup></label>
												<!--<div class="custom-file">
												
													<input type="file" class="custom-file-input" name="image" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
													<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
											    </div>-->
												<div>
													
													<input type="file" accept="image/*"  id="choose-file" name="image" />
													<label for="choose-file">Choose File</label>
													<div id="img-preview"></div>
												</div>
											</div>
											
										</div>
										
                                        
										<button type="submit" class="btn btn-primary px-5 radius-30" id="uploadBtn">Submit <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>
									</div>
									</form>
								</div>
							</div>
						</div>
						
					</div>
					<!--end row-->
					
					
				
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--End Back To Top Button-->
		<?php require'Footer.php';?>
	</div>
	
	<?php require'JsLink.php';?>
	 <script type="text/javascript" src="../ajax/SignUp.js"></script>
</body>
<script>
	
	const chooseFile = document.getElementById("choose-file");
	const imgPreview = document.getElementById("img-preview");
	
	chooseFile.addEventListener("change", function () {
	  getImgData();
	  
	});
	
	function getImgData() {
	  const files = chooseFile.files[0];
	  if (files) {
		const fileReader = new FileReader();
		fileReader.readAsDataURL(files);
		fileReader.addEventListener("load", function () {
		  imgPreview.style.display = "block";
		  imgPreview.innerHTML = '<img src="' + this.result + '" />';
		});    
	  }
	}
	
	
	
</script>

</html>