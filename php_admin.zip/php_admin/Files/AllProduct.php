<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">All Product</h4>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Name</th>
											<th>Category</th>
											<th>Brand</th>
											<th>Model</th>
											
											<th>Quantity</th>
											<th>Unit</th>
											<th>Stock</th>
											<th>Mrp</th>
											<th>Discount</th>
											<th>Price</th>
											<th>Image</th>
											<th>Date</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$source->Query("SELECT *,(SELECT name FROM `tbl_category` c where c.id=p.category) as category,(SELECT image FROM `product_images` i where i.product_id=p.id limit 1) as images,(SELECT name FROM `tbl_brands` b where b.id=p.brand) as brand FROM `product` p where del_status='false' ORDER BY `id` DESC");
										
										while ($values=$source->Single()){
											$source->Query1("SELECT * FROM `tbl_product_details` WHERE product_id=? ",[$values->id]);
											$details=$source->SingleData();
											$source->Query1("select * from tbl_unit where id='".$details->unit."'");
											$unt=$source->SingleData();
											//var_dump($unt);
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											
											
											<td><?php echo base64_decode($values->name);?></td>
											<td><?php echo base64_decode($values->category);?></td>
											<td><?php echo $values->brand;?></td>
											<td><?php echo $details->model;?></td>
											<td><?php echo $details->quantity;?></td>
											
											<td><?php echo $unt->name;?></td>
											<td><?php echo $details->stock;?></td>
											<td>&#x20B9;<?php echo $details->mrp;?></td>
											<td><?php echo $details->discount;?>%</td>
											<td>&#x20B9;<?php echo $details->price;?></td>
											<td><a href="../../API/v1/uploads/products/<?php echo $values->images;?>" target="_blank"><img src="../../API/v1/uploads/products/<?php echo $values->images;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
											<td><?php echo $details->date;?></td>
											<td>
											<?php if($values->status=='true'){
												?><input type="checkbox" checked onchange="Status(<?php echo $values->id?>,'status','false','product','Deactive')" name="checkbox"  data-toggle="toggle" ><?php
											}else{
												?><input type="checkbox" onchange="Status(<?php echo $values->id?>,'status','true','product','Active')" name="checkbox"  data-toggle="toggle" ><?php
											} ?>
											
											
												<a class="btn btn-outline-warning btn-circle btn-sm" href="UpdateAttributeList?id=<?php echo base64_encode($values->id);?>">Update Attribute</a>
												
												<a class="btn btn-outline-warning btn-circle btn-sm" href="UpdateVariantList?id=<?php echo base64_encode($values->id);?>">UpdateVariant</a>
												
												<a class="btn btn-outline-warning btn-circle btn-sm" href="UpdateImageList?id=<?php echo base64_encode($values->id);?>">UpdateImage</a>
												
												<a class="btn btn-outline-warning btn-circle btn-sm" href="UpdateProduct?id=<?php echo base64_encode($values->id);?>"><i class="fa fa-pencil"></i></a>
												
												<button type="button" onclick="ViewInfo('<?= $values->id; ?>')" class="btn btn-outline-warning btn-circle btn-sm" data-toggle="modal" data-target="#exampleModall"><i class="fa fa-eye"></i></button> 


										
												<button class="btn btn-outline-danger btn-sm" title="Delete" onclick="Status1(<?php echo $values->id?>,'delete_status','true','product','Delete')"><i class="fa fa-trash "></i></button>
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						
						
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<div class="modal fade bd-example-modal-lg" id="exampleModall" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		  <div class="modal-dialog modal-lg">
			<div class="modal-content">
			      <div class="modal-body">
			 
				</div>
			</div>
		  </div>
		</div>
		<!--end page-wrapper-->
		 <!--div class="modal fade" id="exampleModall" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Change Status</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <form method="post" id="ChangeStatus1" >
                  <div class="modal-body">
				  
                  </div>
               </form>
            </div>
         </div>
      </div-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
	
	<script>
         function Status1(id,column,value,table,status){
                      swal({
         		title: "Are you sure?",
         		text: "You want to "+status+" this section.",
         		icon: "warning",
         		buttons: true,
         		dangerMode: true,
         		})
         		.then((willDelete) => {
         		if (willDelete) {
         		 $.ajax({
                           url: "../code/ManageStatus.php?flag=Delete1",
                           type: "post",
                           data: {"id": id,"column":column,"value":value,"table":table,"status":status },
                           success: function(r) {
                               if(r=='Success'){
                                   swal(""+status+"", "Selected data has been "+status+".", "success");
                                   window.setTimeout(function() {
                                 window.location.reload();
                             }, 800);
                               }
                               else{
                                    swal("Failed"," Try  ! Again", "error");
                               }
                           }
                       })
         		}
         		});
                  }
				  
				 
      </script>
	  
	  <script>
	    function ViewInfo(id){
			//alert(id);
			$("#exampleModall").modal("show");
                   $("#exampleModall .modal-body").html("<center><i class='fa fa-4x fa-spin fa-spinner'></i></center>");
                   $("#exampleModall .modal-body").load("ViewAllDetail?id="+id);
			
		}
		
	  </script>
</body>

</html>