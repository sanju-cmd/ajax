<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					<?php
						$id=$_REQUEST['id'];
						$id=base64_decode($id);
						
						$source->Query("SELECT * FROM `product` WHERE id='$id' ");
						$product=$source->Single();
						// var_dump($product);
					?>
					<!--end breadcrumb-->
					<div class="row">
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body p-5">
									<div class="card-title d-flex align-items-center">
										
										<h4 class="mb-0 text-primary">Update Product</h4>
									</div>
									<hr>
									<form  id="FormSubmit" novalidate="">
                     
										<input type="hidden" name="location" id="location" value="../code/ManageProduct?flag=UpdateProduct">
										<input type="hidden" name="vendor_id"  value="<?php echo $admin->id;?>">
										<input type="hidden" name="product_id"  value="<?php echo $product->id;?>">
									
									<div class="form-body">
									
										<div class="form-row">
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Product Name<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" value="<?php echo base64_decode($product->name); ?>" name="name" placeholder="Product Name " required />
                                            </div>
										</div>
										
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Brand<sup class="text-danger">*</sup> <?= $product->brand;?></label>
                                                <select class="form-control" name="brand">  
													<option disabled="">Select Brand</option>
													<?php
													  $source->Query("SELECT * FROM `tbl_brands` WHERE `delete_status`='false' ORDER BY `id` ASC");
													  while($values=$source->Single()){
														  if($values->id==$product->brand){
															 echo '<option value='.$values->id.' selected>'.$values->name.'</option>';
														  }else{
															 echo '<option value='.$values->id.'>'.$values->name.'</option>';  
														  }
													  }
													  
													?>
												</select>
                                            </div>
										</div>
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Category<sup class="text-danger">*</sup></label>
                                                <select class="form-control" name="category" id="category">  
													<option  disabled="">Select Category</option>
													<?php
													  $source->Query("SELECT * FROM `tbl_category` WHERE `delete_status`='false' ORDER BY `id` ASC");
													  while($values=$source->Single()){
														 if($values->id==$product->category){
															 echo '<option value='.$values->id.' selected>'.base64_decode($values->name).'</option>';
														  }else{
															 echo '<option value='.$values->id.'>'.base64_decode($values->name).'</option>';  
														  }
													 
													  }
													  
													?>
												</select>
                                            </div>
                                    </div>
									<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Sub-Category<sup class="text-danger">*</sup></label>
                                                <select class="form-control"  name="sub_category" id="subcategory">
												<?php $source->Query("SELECT * FROM `tbl_subcategory` WHERE delete_status='false' and id='".$product->sub_category."'"); $sub_cate=$source->Single(); ?>
													<option value="<?= $sub_cate->id;?>"><?= base64_decode($sub_cate->name); ?></option>
												</select>
                                            </div>
                                    </div>
										
											
										<!--<div class="form-group col-md-12 ">
											<div class="card radius-15">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Image Uploadify</h4>
							</div>
							<hr>
								<input id="image-uploadify" name="image[]" type="file" accept=".xlsx,.xls,image/*,.doc,audio/*,.docx,video/*,.ppt,.pptx,.txt,.pdf,.jpg,.png,.jpeg,.jfifi" multiple="">
							
						</div>
					</div>
											</div>
											-->
											
										<div class="col-sm-12 ">
                                            <div class="form-group">
                                                <label >Description<sup class="text-danger">*</sup></label>
                                                <textarea class="form-control summernote" name="sdescription" placeholder="Description" >
												<?php echo base64_decode($product->sdescription); ?></textarea>
                                            </div>
										</div>
										
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Meta Tag Title<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" value="<?php echo $product->meta_tag_title;?>" name="meta_tag_title" placeholder="Meta Tag Title" required />
                                            </div>
										</div>										
											
											
											
											
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Meta Tag Keywords<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" value="<?php echo $product->meta_tag_keywords;?>" name="meta_tag_keywords" placeholder="Meta Tag Keywords" required />
                                            </div>
										</div>	
											<div class="col-sm-12 ">
                                            <div class="form-group">
                                                <label >Meta Tag Description<sup class="text-danger">*</sup></label>
                                                <textarea class="form-control"  name="meta_tag_description" placeholder="Meta Tag Description"  ><?php echo base64_decode($product->meta_tag_description); ?></textarea>
                                            </div>
										</div>
										
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Product Tags<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" value="<?php echo $product->product_tags; ?>" name="product_tags" placeholder="Product Tags" required />
                                            </div>
										</div>	
										
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Expiry Date<sup class="text-danger">*</sup></label>
                                                <input type="date" class="form-control" name="exp_date" value="<?= $product->expiry_date;?>" placeholder="Product Tags" required />
                                            </div>
										</div>
									
										</div>
										
                                        
										<button type="submit" class="btn btn-primary px-5 radius-30" id="uploadBtn">Update <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>
									</div>
									</form>
								</div>
							</div>
						</div>
						
					</div>
					<!--end row-->
					
					
				
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--End Back To Top Button-->
		<?php require'Footer.php';?>
	</div>
	
	<?php require'JsLink.php';?>
	 <script type="text/javascript" src="../ajax/SignUp.js"></script>
	 <script type="text/javascript">
		function Price(){
		  var mrp=$("#mrp").val();
		  var discount=$("#discount").val();
		  var price=mrp-((mrp*discount)/100);
		  $("#price").val(price);
		}
    </script>
	 	<script> 
		
		$("#category").change(function(){
		var id=$("#category").val();
		//alert(id);
		$.ajax({
			url: 'products.php',
			type: 'POST',
			contentType: 'application/x-www-form-urlencoded',
			data: { id:id },
			success: function(data) {
				
				// alert(data);
				$("#subcategory").html(data);
						//location.reload();
			},
			error: function() {
				alert('error');
			}
		});
	});
		
</script>
</body>

</html>