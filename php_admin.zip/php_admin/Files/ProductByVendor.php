<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Product By Vendor</h4>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Vendor</th>
											<th>Products</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$source->Query("SELECT * FROM `tbl_vendor` where delete_status='false' ORDER BY `id` DESC");
										while ($values=$source->Single()){
											
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											<td><?php echo $values->name;?></td>
											<td><?php $source->Query1("SELECT * FROM `product` where del_status='false' and vendor_id='$values->id' "); echo $count=$source->NumRows(); ?></td>
											<td>
												<a class="btn btn-outline-success btn-circle" title="Edit" href="VendorProduct?id=<?php echo base64_encode($values->id);?>"><i class="fa fa-eye"></i></a>
												
											
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
</body>

</html>