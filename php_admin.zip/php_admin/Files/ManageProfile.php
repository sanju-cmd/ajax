<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
	<style>
	#img-preview {
	  display: none; 
	  width: 155px;   
	  border: 2px dashed #333;  
	  margin-bottom: 20px;
	}
	#img-preview img {  
	  width: 100%;
	  height: auto; 
	  display: block;   
	}
	
	[type="file"] {
	  height: 0;  
	  width: 0;
	  overflow: hidden;
	}
	[type="file"] + label {
	  font-family: sans-serif;
	  background: #f44336;
	  padding: 10px 30px;
	  border: 2px solid #f44336;
	  border-radius: 3px;
	  color: #fff;
	  cursor: pointer;
	  transition: all 0.2s;
	}
	[type="file"] + label:hover {
	  background-color: #fff;
	  color: #f44336;
	}
	
	</style>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					<div class="page-breadcrumb d-none d-md-flex align-items-center mb-3">
						<div class="breadcrumb-title pr-3">User Profile</div>
						
						
					</div>
					<!--end breadcrumb-->
					<div class="user-profile-page">
						<div class="card radius-15">
							<div class="card-body">
								<div class="row">
									<div class="col-12 col-lg-7 border-right">
										<div class="d-md-flex align-items-center">
											<div class="mb-md-0 mb-3">
												<img src="../upload/admin/<?php echo $admin->image?>" class="rounded-circle shadow" width="130" height="130" alt="">
											</div>
											<div class="ml-md-4 flex-grow-1">
												<div class="d-flex align-items-center mb-1">
													<h4 class="mb-0"><?php echo $admin->name?></h4>
													
												</div>
												<p class="mb-0 text-primary">Login Time: <?php echo $admin->login_time?></p>
												<p class="text-primary">Last Logout: <?php echo $admin->logout_time?></p>
												<button class="btn btn-primary "  data-toggle="modal" data-target="#exampleModal">Change Password</button>
												
											</div>
										</div>
									</div>
									<div class="col-12 col-lg-5">
										<table class="table table-sm table-borderless mt-md-0 mt-3">
											<tbody>
												<tr>
													<th>Name:</th>
													<td><?php echo $admin->name?> <span class="badge badge-success">available</span>
													</td>
												</tr>
												<tr>
													<th>Email:</th>
													<td><?php echo $admin->email?></td>
												</tr>
												<tr>
													<th>Mobile:</th>
													<td><?php echo $admin->mobile?></td>
												</tr>
												<tr>
													<th>Address:</th>
													<td><?php echo $admin->address?></td>
												</tr>
											</tbody>
										</table>
									
									</div>
								</div>
								<!--end row-->
								<br>
								<ul class="nav nav-pills">
									
									<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#Edit-Profile"><span class="p-tab-name">Edit Profile</span><i class='bx bx-message-edit font-24 d-sm-none'></i></a>
									</li>
									
									 
								</ul>
								
								<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change Password</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <form method="post" id="UpdatePassword" >
                       <div class="row">
					   <div class="col-sm-12">
					   <label>Current Password</label>
					   <input class="form-control mb-3" type="text" name="opass" placeholder="Enter your current password">
					   </div>
					   
					   <div class="col-sm-12">
					   <label>New Password</label>
					   <input class="form-control mb-3" type="text" name="npass"placeholder="Enter your new password">
					   </div>
					   
					   <div class="col-sm-12">
					   <label>Conform Password</label>
					   <input class="form-control mb-3" type="text" name="cpass" placeholder="Enter your conform password">
					   </div>
					   

					   <div class="col-sm-6">
					   <button type="submit"  class="btn btn-primary mt-3">Change</button>
					   </div>
					    
					   
					   </div>
                        </form>
      </div>
      
    </div>
  </div>
</div>
								<div class="tab-content mt-3">
									
									
									<div class="tab-pane  active" id="Edit-Profile">
										<div class="card shadow-none border mb-0 radius-15">
											<div class="card-body">
												<div class="form-body">
													<div class="row">
														<div class="col-12 col-lg-12 border-right">
														 <form method="post" id="UpdateProfile" >
															<div class="form-row">
																<div class="form-group col-md-6">
																	<label>Name</label>
																	<input type="text" value="<?php echo $admin->name?>" name="name" class="form-control">
																</div>
																<div class="form-group col-md-6">
																<label>Email</label>
																<input type="text" value="<?php echo $admin->email?>" name="email" class="form-control">
															</div>
															<div class="form-group col-md-6">
																<label>Mobile</label>
																<input type="text" value="<?php echo $admin->mobile?>" name="mobile" class="form-control">
															</div>
															<div class="form-group col-md-6">
																<label >Profile<sup class="text-danger">*</sup></label>
																	<!--<div class="custom-file">
																	
																		<input type="file" class="custom-file-input" name="image" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
																		<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
																	</div>-->
																	<div>
													
													<input type="file" accept="image/*"  id="choose-file" name="image" />
													<label for="choose-file">Choose File</label>
													<div id="img-preview"></div>
												</div>
																</div>
															<div class="form-group col-md-12">
																<label>Address</label>
																<input type="text" value="<?php echo $admin->address?>" name="address" class="form-control">
															</div>
															
															<div class="form-group col-md-12">
																<button class="btn btn-primary">Update Profile</button>
															</div>
															
															</div>
															<form>
															
															
														</div>
														
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		
		


		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
	<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->

	<?php require'JsLink.php';?>
	<script>
	
	$("#UpdateProfile").on('submit', function(e) {
	
	e.preventDefault();
	var data = new FormData(this);
	//alert(data);
	
	$.ajax({
		type: 'POST',  
		url: '../code/ManageAccount?flag=UpdateP',
		data: data,
		cache: false,
		contentType: false,
		processData: false,
		
		success: function(response) {
			//alert(response);
			var  response= JSON.parse(response);
			const Toast = Swal.mixin({  
			  toast: true,
			  position: 'top-end',
			  showConfirmButton: false,
			  timer: 2000,
			  timerProgressBar: true,
			  didOpen: (toast) => {
				toast.addEventListener('mouseenter', Swal.stopTimer)
				toast.addEventListener('mouseleave', Swal.resumeTimer)
			  }
			})

			Toast.fire({
			  icon: response.res,
			  title: response.msg
			})
			
			if( response.res=='success'){
				window.setTimeout(function () {
				  window.location.reload();
				}, 2000);
			}
			
		},
		error: function() {
			alert('error123');
		}
	});

})

$("#UpdatePassword").on('submit', function(e) {
	
	e.preventDefault();
	var data = new FormData(this);
	//alert(data);
	
	$.ajax({
		type: 'POST',  
		url: '../code/ManageAccount?flag=ChangePassword',
		data: data,
		cache: false,
		contentType: false,
		processData: false,
		
		success: function(response) {
			//alert(response);
			var  response= JSON.parse(response);
			const Toast = Swal.mixin({  
			  toast: true,
			  position: 'top-end',
			  showConfirmButton: false,
			  timer: 2000,
			  timerProgressBar: true,
			  didOpen: (toast) => {
				toast.addEventListener('mouseenter', Swal.stopTimer)
				toast.addEventListener('mouseleave', Swal.resumeTimer)
			  }
			})

			Toast.fire({
			  icon: response.res,
			  title: response.msg
			})
			
			if( response.res=='success'){
				window.setTimeout(function () {
				  window.location.href = "../code/ManageAccount?flag=Logout";
				}, 2000);
			}
			
		},
		error: function() {
			alert('error123');
		}
	});

})
</script>
</body>

<script>
	
	const chooseFile = document.getElementById("choose-file");
	const imgPreview = document.getElementById("img-preview");
	
	chooseFile.addEventListener("change", function () {
	  getImgData();
	  
	});
	
	function getImgData() {
	  const files = chooseFile.files[0];
	  if (files) {
		const fileReader = new FileReader();
		fileReader.readAsDataURL(files);
		fileReader.addEventListener("load", function () {
		  imgPreview.style.display = "block";
		  imgPreview.innerHTML = '<img src="' + this.result + '" />';
		});    
	  }
	}
	
	
	
</script>

</html>