<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
					 
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Manage Driver KYC</h4>
							</div>
							<hr>
							<div class="row mt-2">
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="all"/>
					 <button class="btn btn-info">All</button>
					 </form></div>
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="accepted"/>
					 <button class="btn btn-success">Accepted</button>
					 </form></div>
					 
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="pending"/>
					 <button class="btn btn-warning">Pending</button> 
					 </form></div>
					 
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="rejected"/>
					 <button class="btn btn-danger">Rejected</button>
					 </form></div>
					 </div> 
					 <hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Manager ID</th>
											<th>Bank Name</th>
											<th>A/C No.</th>
											<th>IFSC Code</th>
											<th>PassBook</th>
											<th>PAN Card</th>
											<th>Date/Time</th>
											<th>Status</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										if(isset($_POST['accepted'])){
										$source->Query("SELECT * FROM `account_kyc` WHERE delete_status='false' and `user_type`='Driver' and `kyc_status`='Accepted' ORDER BY `id` DESC");}
										elseif(isset($_POST['rejected'])){
										$source->Query("SELECT * FROM `account_kyc` WHERE delete_status='false' and `user_type`='Driver' and `kyc_status`='Rejected' ORDER BY `id` DESC");}
										elseif(isset($_POST['pending'])){
										$source->Query("SELECT * FROM `account_kyc` WHERE delete_status='false' and `user_type`='Driver' and `kyc_status`='Pending' ORDER BY `id` DESC");}
										else{
										$source->Query("SELECT * FROM `account_kyc` where delete_status='false' and `user_type`='Driver' ORDER BY `id` DESC");}
										while ($values=$source->Single()){
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											<td><?php $source->Query1("SELECT * FROM `tbl_deliveryboy` WHERE `id`='$values->user_id'"); echo$source->SingleData()->sponsorID;?></td>
											<td><?php echo $values->name;?></td>
											<td><?php echo $values->account_number;?></td>
											<td><?php echo $values->ifsc;?></td>
											<td><a onclick="quick_view(<?php echo $values->id?>)"><img src="../../API/v1/uploads/Vendor/<?php echo $values->passbook_img;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
											<td><a onclick="quick_view1(<?php echo $values->id?>)"><img src="../../API/v1/uploads/Vendor/<?php echo $values->pan_img;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
											<td><?php echo $values->date;?><br><?php echo $values->time;?></td>
											<td><?php if($values->kyc_status=='Pending'){ ?>
												  <button class="btn btn-warning btn-icon text-white" title="Pending" onclick="Status1(<?php echo $values->id;?>,'kyc_status','account_kyc')">Pending</button>
												  <?php } elseif($values->kyc_status=='Accepted'){ ?>
												  <button  class="btn btn-success btn-icon text-white" title="Accepted"onclick="Status1(<?php echo $values->id;?>,'kyc_status','account_kyc')">Accepted</button>
												  
												  <?php } elseif($values->kyc_status=='Rejected'){ ?>
												  <button class="btn btn-danger btn-icon text-white" title="Rejected"onclick="Status1(<?php echo $values->id;?>,'kyc_status','account_kyc')">Rejected</button>
												  <?php } ?>
											</td>
											<td>
											
												<button class="btn btn-outline-danger " title="Delete" onclick="Status(<?php echo $values->id?>,'delete_status','true','account_kyc','Delete')"><i class="fa fa-trash "></i></button>
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
			<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered " role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title" id="exampleModalLabel"></h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  <div class="modal-body">
		 
		</div>
	  </div>
	</div>	
</div>	
				
<!-- End Modal -->	
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
	 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   <script>
	
		function quick_view(id)
          {
            // alert(id);
            $("#exampleModal").modal("show");
            $("#exampleModal .modal-body").html("<center><i class='fa fa-4x fa-spin fa-spinner'></i></center>");
            $("#exampleModal .modal-body").load("passbook.php?id="+id);

          }
		  function quick_view1(id)
          {
            // alert(id);
            $("#exampleModal").modal("show");
            $("#exampleModal .modal-body").html("<center><i class='fa fa-4x fa-spin fa-spinner'></i></center>");
            $("#exampleModal .modal-body").load("pan.php?id="+id);

          }
		</script>
	  <script>
         function Status1(id,column,table){
			 Swal.fire({
				 
  title: 'Are you sure?',
  text: "You want to take action on this request.",
  icon: 'warning',
  showDenyButton: true,
  confirmButtonText: `Accepted`,
  confirmButtonColor: "green",
  denyButtonText: `Rejected`,
  denyButtonColor: "#e10000",
}).then((result) => {
  /* Read more about isConfirmed, isDenied below */
  if (result.isConfirmed) {
    //next error
					Swal.fire({
						title: 'Are you sure?',
						text: "You want to Accepted this request.",
				  icon: 'warning',
						  showDenyButton: true,
						 // showCancelButton: true,
						  confirmButtonText: `Yes`,
						  //denyButtonText: `Don't save`,
						}).then((result) => {
						  /* Read more about isConfirmed, isDenied below */
						  if (result.isConfirmed) {
							
							//ajex
							 $.ajax({
								   url: "../code/ManageStatus.php?flag=Delete",
								   type: "post",
								   data: {"id": id,"column":column,"value":'Accepted',"table":table,"status":'Accepted' },
								   success: function(r) {
									   if(r=='Success'){
										   swal.fire(""+'Accepted'+"", "Request data has been "+'Accepted'+".", "success");
										   window.setTimeout(function() {
										 window.location.reload();
									 }, 800);
									   }
									   else{
											swal.fire("Failed"," Try  ! Again", "error");
									   }
								   } 
							   })
                           
							//end
							
						  } else if (result.isDenied) {
							Swal.fire('Your request is not processed')
						  }
						})
  } else if (result.isDenied) {
    	//reject
					
					Swal.fire({
						title: 'Are you sure?',
						text: "You want to Rejected this request.",
				  icon: 'warning',
						  showDenyButton: true,
						 // showCancelButton: true,
						  confirmButtonText: `Yes`,
						  //denyButtonText: `Don't save`,
						}).then((result) => {
						  /* Read more about isConfirmed, isDenied below */
						  if (result.isConfirmed) {
							  
							//ajax
								$.ajax({
								   url: "../code/ManageStatus.php?flag=Delete",
								   type: "post",
								   data: {"id": id,"column":column,"value":'Rejected',"table":table,"status":'Rejected' },
								   success: function(r) {
									   if(r=='Success'){
										   swal.fire(""+'Rejected'+"", "Request data has been "+'Rejected'+".", "success");
										   window.setTimeout(function() {
										 window.location.reload();
									 }, 800);
									   }
									   else{
											swal.fire("Failed"," Try  ! Again", "error");
									   }
								   } 
							   })
							//end
							 
						  } else if (result.isDenied) {
							Swal.fire('Your request is not processed')
						  }
						})
						
					//end
  }
})
		 }
     
      </script>
	  
	  
	  
	   <script>

	   
	   
         function Status(id,column,value,table,status){
                       Swal.fire({
    title: "Are you sure?",
	text: "You want to "+status+" this section.",
	icon: "warning",
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((willDelete) => {
         		if (willDelete) {
         		 $.ajax({
                           url: "../code/ManageStatus.php?flag=Delete",
                           type: "post",
                           data: {"id": id,"column":column,"value":value,"table":table,"status":status },
                           success: function(r) {
                               if(r=='Success'){
                                   Swal.fire(""+status+"", "Selected data has been "+status+".", "success");
                                   window.setTimeout(function() {
                                 window.location.reload();
                             }, 800);
                               }
                               else{
                                    swal("Failed"," Try  ! Again", "error");
                               }
                           }
                       })
         		}
         		});
                  }
				  
				 
      </script>
</body>

</html>