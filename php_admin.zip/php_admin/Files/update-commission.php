<?php
	
	require '../init.php';
	
	$id=$_REQUEST['id'];
	
	$source->Query("SELECT * FROM `level_commission` WHERE id='$id'");
	$single=$source->Single();
	
	if($single){
		?>
		<input type="hidden" value="<?php echo $id; ?>" name="id">
		 <div class="form-group">
			<label for="">Commission (%)</label>
			<input type="number" class="form-control" id="" name="commission" value="<?php echo $single->commission; ?>" placeholder="Enter Commission">
		  </div>
		<?php
	}else{
		echo 'Data not found';
	}

?>