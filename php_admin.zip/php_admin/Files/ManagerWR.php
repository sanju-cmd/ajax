<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
					 
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Manage Managers Withdrawal Request</h4>
							</div>
							<hr>
							<div class="row mt-2">
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="all"/>
					 <button class="btn btn-info">All</button>
					 </form></div>
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="accepted"/>
					 <button class="btn btn-success">Accepted</button>
					 </form></div>
					 
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="pending"/>
					 <button class="btn btn-warning">Pending</button> 
					 </form></div>
					 
					 <div class="col-sm-2 m-3 text-center">
					 <form method="post">
					 <input type="hidden" name="rejected"/>
					 <button class="btn btn-danger">Rejected</button>
					 </form></div>
					 </div> 
					 <hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Vendor ID</th>
											<th>Name</th>
											<th>Amount</th>
											<th>Wallet Balance</th>
											<th>Date/Time</th>
											<th>Status</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										if(isset($_POST['accepted'])){
										$source->Query("SELECT * FROM `withdrawal_request` WHERE `user_type`='Manager' and `status`='Accepted' ORDER BY `id` DESC");}
										elseif(isset($_POST['rejected'])){
										$source->Query("SELECT * FROM `withdrawal_request` WHERE `user_type`='Manager' and `status`='Rejected' ORDER BY `id` DESC");}
										elseif(isset($_POST['pending'])){
										$source->Query("SELECT * FROM `withdrawal_request` WHERE `user_type`='Manager' and `status`='Pending' ORDER BY `id` DESC");}
										else{
										$source->Query("SELECT * FROM `withdrawal_request` where `user_type`='Manager' ORDER BY `id` DESC");}
										while ($values=$source->Single()){
											$source->Query1("SELECT * FROM `tbl_manager` WHERE `id`='$values->user_id'");
											$values1=$source->SingleData();
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											<td><?php echo $values1->sponsorID;?></td>
											<td><?php echo $values1->name;?></td>
											<td>&#8377;<?php echo $values->amount;?></td>
											<td>&#8377;<?php echo $values1->wallet;?></td>
											<td><?php echo $values->date;?><br><?php echo $values->time;?></td>
											<td><?php if($values->status=='Pending'){ ?>
												  <button class="btn btn-warning btn-icon text-white" title="Pending" onclick="Status(<?php echo $values->id;?>,<?php echo $values1->id;?>,<?php echo $values->amount;?>,'status','withdrawal_request')">Pending</button>
												  <?php } elseif($values->status=='Accepted'){ ?>
												  <button  class="btn btn-success btn-icon text-white" disabled title="Accepted"onclick="Status(<?php echo $values->id;?>,<?php echo $values1->id;?>,<?php echo $values->amount;?>,'status','withdrawal_request')">Accepted</button>
												  
												  <?php } elseif($values->status=='Rejected'){ ?>
												  <button class="btn btn-danger btn-icon text-white" title="Rejected"onclick="Status(<?php echo $values->id;?>,<?php echo $values1->id;?>,<?php echo $values->amount;?>,'status','withdrawal_request')">Rejected</button>
												  <?php } ?>
											</td>
										
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->

				
<!-- End Modal -->	
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
	 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   
	  <script>
         function Status(id,user_id,amount,column,table){
			 Swal.fire({
				 
  title: 'Are you sure?',
  text: "You want to take action on this request.",
  icon: 'warning',
  showDenyButton: true,
  confirmButtonText: `Accepted`,
  confirmButtonColor: "green",
  denyButtonText: `Rejected`,
  denyButtonColor: "#e10000",
}).then((result) => {
  /* Read more about isConfirmed, isDenied below */
  if (result.isConfirmed) {
    //next error
					Swal.fire({
						title: 'Are you sure?',
						text: "You want to Accepted this request.",
				  icon: 'warning',
						  showDenyButton: true,
						 // showCancelButton: true,
						  confirmButtonText: `Yes`,
						  //denyButtonText: `Don't save`,
						}).then((result) => {
						  /* Read more about isConfirmed, isDenied below */
						  if (result.isConfirmed) {
							
							//ajex
							 $.ajax({
								   url: "../code/ManageStatus.php?flag=ManagerWithdrawal",
								   type: "post",
								    data: {"id": id,"user_id": user_id,"amount":amount,"column":column,"value":'Accepted',"table":table,"status":'Accepted' },
								   success: function(r) {
									   if(r=='Success'){
										   swal.fire(""+'Accepted'+"", "Request data has been "+'Accepted'+".", "success");
										   window.setTimeout(function() {
										 window.location.reload();
									 }, 800);
									   }
									   else{
											swal.fire("Failed"," Try  ! Again", "error");
									   }
								   } 
							   })
                           
							//end
							
						  } else if (result.isDenied) {
							Swal.fire('Your request is not processed')
						  }
						})
  } else if (result.isDenied) {
    	//reject
					
					Swal.fire({
						title: 'Are you sure?',
						text: "You want to Rejected this request.",
				  icon: 'warning',
						  showDenyButton: true,
						 // showCancelButton: true,
						  confirmButtonText: `Yes`,
						  //denyButtonText: `Don't save`,
						}).then((result) => {
						  /* Read more about isConfirmed, isDenied below */
						  if (result.isConfirmed) {
							  
							//ajax
								$.ajax({
								   url: "../code/ManageStatus?flag=Delete",
								   type: "post",
								   data: {"id": id,"column":column,"value":'Rejected',"table":table,"status":'Rejected' },
								   success: function(r) {
									   if(r=='Success'){
										   swal.fire(""+'Rejected'+"", "Request data has been "+'Rejected'+".", "success");
										   window.setTimeout(function() {
										 window.location.reload();
									 }, 800);
									   }
									   else{
											swal.fire("Failed"," Try  ! Again", "error");
									   }
								   } 
							   })
							//end
							 
						  } else if (result.isDenied) {
							Swal.fire('Your request is not processed')
						  }
						})
						
					//end
  }
})
		 }
     
      </script>
	  
	  

</body>

</html>