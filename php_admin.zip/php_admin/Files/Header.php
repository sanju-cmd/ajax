

<!--header-->
		<header class="top-header">
			<nav class="navbar navbar-expand">
				<div class="left-topbar d-flex align-items-center">
					<a href="javascript:;" class="toggle-btn">	<i class="bx bx-menu"></i>
					</a>
				</div>
				
				<div class="right-topbar ml-auto">
					<ul class="navbar-nav">
						
						
						
						<li class="nav-item dropdown dropdown-user-profile">
							<a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="javascript:;" data-toggle="dropdown">
								<div class="media user-box align-items-center">
									<div class="media-body user-info">
										<p class="user-name mb-0"><?php echo $admin->name?></p>
										<p class="designattion mb-0">Available</p>
									</div>
									<img src="../upload/admin/<?php echo $admin->image?>" class="user-img" alt="user avatar">
								</div>
							</a>
							<div class="dropdown-menu dropdown-menu-right">	<a class="dropdown-item" href="ManageProfile"><i class="bx bx-user"></i><span>Profile</span></a>
								<a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal"><i class="bx bx-power-off"></i><span>Logout</span></a>
							</div>
						</li>
						
					</ul>
				</div>
			</nav>
		</header>
		<!--end header-->


	
<!-- Logout Modal -->
<div class="modal" id="logoutModal" tabindex="-1" role="dialog" aria-hidden="true">
   <div class="modal-dialog modal-sm">
      <div class="modal-content">
         <div class="modal-header">
            <h4><i class="bx bx-log-out"></i> Logout </h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
         </div>
         <div class="modal-body">
            <p><i class="fa fa-question-circle"></i> Are you sure you want to Logout? <br /></p>
            <div class="actionsBtns">
               <a  class="btn  btn-primary"  href="../code/ManageAccount?flag=Logout" >Logout</a>
               <button class="btn btn-default" data-dismiss="modal">Cancel</button>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>