<?php
require '../init.php';
 $dataId=$_REQUEST['id'];
$source->Query("SELECT *,(SELECT  name FROM tbl_brands BR WHERE BR.id=P.brand)as brandname,(SELECT  name FROM tbl_subcategory TS WHERE TS.id=P.sub_category)as sub_category,(SELECT image FROM product_images PI WHERE PI.product_id=P.id limit 1) as product_image,(SELECT name FROM tbl_category C WHERE C.id=P.category) as category_name FROM product P WHERE del_status='false' and id='$dataId'"); 
$product=$source->Single();

// var_dump($product);
?>

<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col" colspan="3"class="text-success font-weight-bod">Product Details</th>
    </tr>
  </thead>
  <tbody>
  
    <tr>
      <th>Name</th>
      <td colspan="2"><?= base64_decode($product->name);?></td>
    </tr>
  
	 <tr>
      <th>Category</th>
     
	  <th>Sub Category</th>
     
	  <th>Brand</th>
    
    </tr>
	<tr>
		<td colspan=""><?= base64_decode($product->category_name);?></td> 
		<td colspan=""><?= base64_decode($product->sub_category);?></td>
		<td colspan=""><?= ($product->brandname);?></td>
	</tr>
	
    
  </tbody>
</table>
<table class="table table-bordered">
  <thead>
   <tr>
      <th scope="col" colspan="7" class="text-success font-weight-bod">Product Variant</th>
    </tr>
  </thead>
  <tbody>
  
    <tr>
      <th>Model</th>
      <th>Qty</th>
      <th>Unit</th>
      <th>Stock</th>
      <th>Sale</th>
      <th>MRP</th>
      <th>Price</th>
    </tr>
	<?php
		
		$source->Query("SELECT *,(SELECT percentage FROM tbl_tax TB WHERE TB.id=TPD.tax) as tax_ FROM `tbl_product_details` TPD WHERE product_id='".$dataId."' and delete_status='false'");
		while ($values=$source->Single()){
		$source->Query1("select * from tbl_unit where id='".$values->unit."'");
		$unt=$source->SingleData();
	?>
		<tr>
			<td><?php echo $values->model;?></td>
			<td><?php echo $values->quantity;?></td>
			<td><?php echo $unt->name;?></td>
			<td><?php echo $values->stock;?></td>
			<td><?php echo $values->mrp;?></td>
			<td><?php echo $values->price;?></td>
			<td><?php echo $values->discount;?></td>
		</tr>
	<?php $i++; }?>
	
    
  </tbody>
</table>



<table class="table table-bordered">
  <thead>
   <tr>
      <th scope="col" colspan="2" class="text-success font-weight-bod" >Product Attribute</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Name</th>
      <th>Text</th>
    </tr>
	<?php
		$i=1;
		$_SESSION['update_varient']=$_REQUEST['id'];
		$source->Query("SELECT * FROM `tbl_attribute` WHERE product_id='".$dataId."' and delete_status='false'");
		while ($values=$source->Single()){
	?>
		<tr>
			<td><?php echo $values->name;?></td>
			<td><?php echo $values->text;?></td>
		</tr>
	<?php $i++; } ?>
  </tbody>
</table>


<table class="table table-bordered">
  <thead>
   <tr>
      <th scope="col" colspan="2"class="text-success font-weight-bod" >Other Details</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Meta Tag Title</th>
  
    </tr>
	<tr>
      <td><?= $product->meta_tag_title;?></td>
  
    </tr>
	
	<tr>
      <th>Description</th>
  
    </tr>
	<tr>
      <td><?= base64_decode($product->meta_tag_description);?></td>
  
    </tr>
  </tbody>
</table>



<table class="table table-bordered">
  <thead>
   <tr>
      <th scope="col" colspan="2" class="text-success font-weight-bod" >Product Image</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>#</th>
      <th>IMG</th>
    </tr>
	<?php
		$i=1;
		$source->Query("SELECT * FROM `product_images` WHERE product_id='".$dataId."' and delete_status='false'");
		while ($values=$source->Single()){
	?>
		<tr>
			<td><?= $i++; ?></td>
			<td><a href="../../API/v1/uploads/products/<?php echo $values->image;?>" target="_blank"><img src="../../API/v1/uploads/products/<?php echo $values->image;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
		</tr>
	<?php $i++; } ?>
  </tbody>
</table>