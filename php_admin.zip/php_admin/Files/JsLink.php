<script src="../assets/js/jquery-3.5.1.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/notify/bootstrap-notify.min.js"></script>
<!--<script src="../assets/js/notify/index.js"></script>-->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha256-KsRuvuRtUVvobe66OFtOQfjP8WA2SzYsmm4VPfMnxms=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script>
   function Status(id,column,value,table,status){
                swal({
   		title: "Are you sure?",
   		text: "You want to "+status+" this section.",
   		icon: "warning",
   		buttons: true,
   		dangerMode: true,
   		})
   		.then((willDelete) => {
   		if (willDelete) {
   		 $.ajax({
                     url: "../code/ManageStatus.php?flag=Delete",
                     type: "post",
                     data: {"id": id,"column":column,"value":value,"table":table,"status":status },
                     success: function(r) {
                         if(r=='Success'){
                             swal(""+status+"", "Selected data has been "+status+".", "success");
                             window.setTimeout(function() {
                           window.location.reload();
                       }, 800);
                         }
                         else{
                              swal("Failed"," Try  ! Again", "error");
                         }
                     }
                 })
   		}
   		});
            }
   
   
</script>



<script>
   function AllDel(id,column,value,table,status){
	   //alert(id);
                swal({
   		title: "Are you sure?",
   		text: "You want to "+status+" this section.",
   		icon: "warning",
   		buttons: true,
   		dangerMode: true,
   		})
   		.then((willDelete) => {
   		if (willDelete) {
   		 $.ajax({
                     url: "../code/ManageStatus.php?flag=DeleteAllData",
                     type: "post",
                     data: {"id": id,"column":column,"value":value,"table":table,"status":status },
                     success: function(r) {
                         if(r=='Success'){
                             swal(""+status+"", "Selected data has been "+status+".", "success");
                             window.setTimeout(function() {
                           window.location.reload();
                       }, 800);
                         }
                         else{
                              swal("Failed"," Try  ! Again", "error");
                         }
                     }
                 })
   		}
   		});
            }
   
   
</script>








<!-- Summernote -->
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script>
   $('.summernote').summernote({
     placeholder: 'Write here....',
     tabsize: 2,
     height: 100
   });
</script>
<!-- Project JS Start -->
<script src="../assets/js/popper.min.js"></script>
<!--plugins-->
<script src="../assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="../assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="../assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<!-- Vector map JavaScript -->
<script src="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="../assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="../assets/plugins/vectormap/jquery-jvectormap-in-mill.js"></script>
<script src="../assets/plugins/vectormap/jquery-jvectormap-us-aea-en.js"></script>
<script src="../assets/plugins/vectormap/jquery-jvectormap-uk-mill-en.js"></script>
<script src="../assets/plugins/vectormap/jquery-jvectormap-au-mill.js"></script>
<script src="../assets/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
<script src="../assets/js/index2.js"></script>
<!-- App JS -->
<script src="../assets/js/app.js"></script>
<!--Data Tables js-->
<script src="../assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script>
   $(document).ready(function () {
   	//Default data table
   	$('#example').DataTable();
   	var table = $('#example2').DataTable({
   		lengthChange: false,
   		buttons: ['copy', 'excel', 'pdf', 'print', 'colvis']
   	});
   	table.buttons().container().appendTo('#example2_wrapper .col-md-6:eq(0)');
   });
</script>
<!------------Active /Deactive button------------>
<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>