<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					<div class="row">
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body p-5">
									<div class="card-title d-flex align-items-center">
										
										<h4 class="mb-0 text-primary">Add Pincode</h4>
									</div>
									<hr>
									<form  id="FormSubmit" novalidate="">
                     
										<input type="hidden" name="location" id="location" value="../code/managepin?flag=Add">
									
									<div class="form-body">
									
										<div class="form-row">
										
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Pincode<sup class="text-danger">*</sup></label>
                                                <input type="number" class="form-control" name="percentage" placeholder="Pincode" required />
                                            </div>
										</div>
											
										</div>
										
                                        
										<button type="submit" class="btn btn-primary px-5 radius-30" id="uploadBtn">Submit <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>
									</div>
									</form>
								</div>
							</div>
						</div>
						
						
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body p-5">
									<div class="card-title d-flex align-items-center">
										
										<h4 class="mb-0 text-primary">Manage Pincode</h4>
									</div>
									<hr>
									<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Pincode</th>
											
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$source->Query("SELECT * FROM `pincode` where del_status='false' ORDER BY `id` DESC");
										while ($values=$source->Single()){
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											<td><?php echo $values->pincode;;?></td>
											
											<td>
												<a class="btn btn-outline-warning btn-circle" href="updatepin?id=<?php echo base64_encode($values->id);?>"><i class="fa fa-pencil"></i></a>
									
												<button class="btn btn-outline-danger " title="Delete" onclick="Status(<?php echo $values->id?>,'del_status','true','pincode','Delete')"><i class="fa fa-trash "></i></button>
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
									</div>
								</div>
							</div>
						</div>
						
						
						
					</div>
					<!--end row-->
					
					
				
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--End Back To Top Button-->
		<?php require'Footer.php';?>
	</div>
	
	<?php require'JsLink.php';?>
	 <script type="text/javascript" src="../ajax/SignUp.js"></script>
</body>

</html>