<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Manage Delivery Charge</h4>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											
											<th>Amount</th>
											<th>Limits</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$source->Query("SELECT * FROM delivery_charge where delete_status='false'");
										while ($values=$source->Single()){
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											<td><?php echo "&#8377; ".$values->amount;?></td>

											<td><?php echo "&#8377; ".$values->limits;?></td>
											<td>
												<!--a class="btn btn-outline-warning btn-circle" href="UpdateBlog?id=<?php #echo base64_encode($values->id);?>"><i class="fa fa-pencil"></i></a-->
									
												<button class="btn btn-outline-danger " title="Delete" onclick="Status(<?php echo $values->id?>,'delete_status','true','delivery_charge','Delete')"><i class="fa fa-trash "></i></button>
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
</body>

</html>