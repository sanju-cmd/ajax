<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					<div class="row">
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body p-5">
									<div class="card-title d-flex align-items-center">
										
										<h4 class="mb-0 text-primary">Add About</h4>
									</div>
									<hr>
									<form  id="FormSubmit" novalidate="">
                     
										<input type="hidden" name="location" id="location" value="../code/ManageAboutUs?flag=Add">
									
									<div class="form-body"> 
									
										<div class="form-row">
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Title<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="name" placeholder="Title " required />
                                            </div>
                                    </div>
											<!---<div class="form-group col-md-6">
											<label >Image<sup class="text-danger">*</sup></label>
												<div class="custom-file">
												
													<input type="file" class="custom-file-input" name="image" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
													<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
											    </div>
											</div>-------->
											<div class="col-sm-12 ">
												
												<label >Description<sup class="text-danger">*</sup></label>
                                                <textarea type="text" class="form-control summernote" name="description" placeholder="Brand Name " required ></textarea>
											
											</div>
										</div><br>
										<!--Include the JS & CSS-->



                                   
										<button type="submit" class="btn btn-primary px-5 radius-30" id="uploadBtn">Submit <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>
									</div>
									</form>
								</div>
							</div>
						</div>
						
					</div>
					<!--end row-->
					
					
				
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--End Back To Top Button-->
		<?php require'Footer.php';?>
	</div>
	
	<?php require'JsLink.php';?>
	 <script type="text/javascript" src="../ajax/SignUp.js"></script>
<link rel="stylesheet" href="/richtexteditor/rte_theme_default.css" />
<script type="text/javascript" src="/richtexteditor/rte.js"></script>
<script type="text/javascript" src='/richtexteditor/plugins/all_plugins.js'></script>
<script>
	var editor1 = new RichTextEditor("#div_editor1");
	//editor1.setHTMLCode("Use inline HTML or setHTMLCode to init the default content.");
</script>	
</body>

</html>