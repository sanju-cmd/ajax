<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		
		<?php require'Header.php';
					$source->Query("SELECT * FROM `side_banner` WHERE `id`=1");
					$data=$source->Single();
	 ?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					<div class="row">
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body p-5">
									<div class="card-title d-flex align-items-center">
										
										<h4 class="mb-0 text-primary">Update Banner</h4>
									</div>
									<hr>
									<form  id="FormSubmit" novalidate="">
                     
										 <input type="hidden" name="location" id="location" value="../code/ManageSideBanner?flag=Update">
					  <input type="hidden" value="1" name="id">
									<div class="form-body">
									
										<div class="form-row">
										
						 <div class="col-md-4 mb-4">
                          <label class="form-label" >Link<sup class="text-danger">*</sup></label>
                          
						  
                          <input class="form-control" value="<?php echo $data->link;?>"  type="text" placeholder="Enter Link" name="link" required> 
						  
                        </div>
										
											<div class="form-group col-sm-4">
											<label >Image1<sup class="text-danger">*</sup></label>
												<div class="custom-file">
													<input type="file" class="custom-file-input" name="image1" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
													<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
											    </div>
											</div>
											
											<div class="col-sm-3 mb-3">
                                            <div class="form-group">
											<p></p><br>
                                                <a href="../upload/sidebanner/<?php echo $data->image1;?>" target="_blank"><img src="../upload/sidebanner/<?php echo $data->image1;?>" style="width:100%; height:100px;"></a>
                                            </div>
                                        </div>
										
						 <div class="col-md-4 mb-4">
                          <label class="form-label" >Link2<sup class="text-danger">*</sup></label>
                          <input class="form-control" value="<?php echo $data->link2;?>"  type="text" placeholder="Enter Link" name="link2" required>
                        </div>
										
											<div class="form-group col-sm-4">
											<label >Image2<sup class="text-danger">*</sup></label>
												<div class="custom-file">
													<input type="file" class="custom-file-input" name="image2" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
													<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
											    </div>
											</div>
                                      <div class="col-sm-3 mb-3">
                                            <div class="form-group">
											<p></p><br>
                                                <a href="../upload/sidebanner/<?php echo $data->image2;?>" target="_blank"><img src="../upload/sidebanner/<?php echo $data->image2;?>" style="width:100%; height:100px;"></a>
                                            </div>
                                        </div>
                          <div class="col-md-4 mb-4">
                          <label class="form-label" >Link3<sup class="text-danger">*</sup></label>
                          <input class="form-control" value="<?php echo $data->link3;?>"  type="text" placeholder="Enter Link" name="link3" required>
                        </div>
                                										
										
											<div class="form-group col-sm-4">
											<label >Image3<sup class="text-danger">*</sup></label>
												<div class="custom-file">
													<input type="file" class="custom-file-input" name="image3" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
													<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
											    </div>
											</div>
                                             <div class="col-sm-3 mb-3">
                                            <div class="form-group">
											<p></p><br>
                                                <a href="../upload/sidebanner/<?php echo $data->image3;?>" target="_blank"><img src="../upload/sidebanner/<?php echo $data->image3;?>" style="width:100%; height:100px;"></a>
                                            </div>
                                        </div>											
						 <div class="col-md-4 mb-4">
                          <label class="form-label" >Link4<sup class="text-danger">*</sup></label>
                          <input class="form-control" value="<?php echo $data->link4;?>"  type="text" placeholder="Enter Link" name="link4" required>
                        </div>
                                
											<div class="form-group col-sm-4">
											<label >Imag4<sup class="text-danger">*</sup></label>
												<div class="custom-file">
													<input type="file" class="custom-file-input" name="image4" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
													<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
											    </div>
											</div>
											
											<div class="col-sm-3 mb-3">
                                            <div class="form-group">
											<p></p><br>
                                                <a href="../upload/sidebanner/<?php echo $data->image4;?>" target="_blank"><img src="../upload/sidebanner/<?php echo $data->image4;?>" style="width:100%; height:100px;"></a>
                                            </div>
                                        </div>
						 <div class="col-md-4 mb-4">
                          <label class="form-label" >Link5<sup class="text-danger">*</sup></label>
                          <input class="form-control" value="<?php echo $data->link5;?>"  type="text" placeholder="Enter Link" name="link5" required>
                        </div>
                                
											<div class="form-group col-sm-4">
											<label >Image5<sup class="text-danger">*</sup></label>
												<div class="custom-file">
													<input type="file" class="custom-file-input" name="image5" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
													<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
											    </div>
											</div>
												<div class="col-sm-3 mb-3">
                                            <div class="form-group">
											<p></p><br>
                                                <a href="../upload/sidebanner/<?php echo $data->image5;?>" target="_blank"><img src="../upload/sidebanner/<?php echo $data->image5;?>" style="width:100%; height:100px;"></a>
                                            </div>
                                        </div>
											
										</div>
										
                                        
										<button type="submit" class="btn btn-primary px-5 radius-30" id="uploadBtn">Update <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>
									</div>
									</form>
								</div>
							</div>
						</div>
						
					</div>
					<!--end row-->
					
					
				
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--End Back To Top Button-->
		<?php require'Footer.php';?>
	</div>
	
	<?php require'JsLink.php';?>
	 <script type="text/javascript" src="../ajax/SignUp.js"></script>
</body>

</html>