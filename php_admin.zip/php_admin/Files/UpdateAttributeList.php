<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">All Attribute</h4>
								<a href="AddAttribute?id=<?php echo $_REQUEST['id'];?>">
								
								<button class="btn btn-primary" style="float:right;margin-top:-25px;"  onclick="">Add Attribute</button>
								
								</a>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Name</th>
											<th>Test</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$_SESSION['update_varient']=$_REQUEST['id'];
										$source->Query("SELECT * FROM `tbl_attribute` WHERE product_id='".base64_decode($_REQUEST['id'])."' and delete_status='false'");
										while ($values=$source->Single()){
											
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											
											
											<td><?php echo $values->name;?></td>
											<td><?php echo $values->text;?></td>
											<td>
												
												<a class="btn btn-outline-warning btn-circle" href="UpdateAttribute?id=<?php echo base64_encode($values->id);?>"><i class="fa fa-pencil"></i></a>
										
												<button class="btn btn-outline-danger " title="Delete" onclick="Status5(<?php echo $values->id?>,'delete_status','true','tbl_attribute','Delete')"><i class="fa fa-trash "></i></button>
												
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
	
	<script>
         function Status5(id,column,value,table,status){
			 alert(id);
                      swal({
         		title: "Are you sure?",
         		text: "You want to "+status+" this section.",
         		icon: "warning",
         		buttons: true,
         		dangerMode: true,
         		})
         		.then((willDelete) => {
         		if (willDelete) {
         		 $.ajax({
                           url: "../code/ManageStatus.php?flag=Delete1",
                           type: "post",
                           data: {"id": id,"column":column,"value":value,"table":table,"status":status },
                           success: function(r) {
							   alert(r);
                               if(r=='Success'){
                                   swal(""+status+"", "Selected data has been "+status+".", "success");
                                   window.setTimeout(function() {
                                 window.location.reload();
                             }, 800);
                               }
                               else{
                                    swal("Failed"," Try  ! Again", "error");
                               }
                           }
                       })
         		}
         		});
                  }
				  
				 
      </script>
</body>

</html>