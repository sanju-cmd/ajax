<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
	<style>
	#img-preview {
	  display: none; 
	  width: 155px;   
	  border: 2px dashed #333;  
	  margin-bottom: 20px;
	}
	#img-preview img {  
	  width: 100%;
	  height: auto; 
	  display: block;   
	}
	
	[type="file"] {
	  height: 0;  
	  width: 0;
	  overflow: hidden;
	}
	[type="file"] + label {
	  font-family: sans-serif;
	  background: #f44336;
	  padding: 10px 30px;
	  border: 2px solid #f44336;
	  border-radius: 3px;
	  color: #fff;
	  cursor: pointer;
	  transition: all 0.2s;
	}
	[type="file"] + label:hover {
	  background-color: #fff;
	  color: #f44336;
	}
	
	</style>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					<div class="row">
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body">
									<div class="card-title d-flex align-items-center">
										
										<h5 class="mb-0 text-primary">Update Logo</h5>
									</div>
									<hr>
									<form  id="FormSubmit" novalidate="">
                     
										<input type="hidden" name="location" id="location" value="../code/ManageSetting?flag=logo_update">
									
										<div class="form-body">
										
											<div class="form-row">
												<div class="form-group col-md-4">
													<label >Logo<sup class="text-danger">*</sup></label>
													<!--<div class="custom-file">
														<input type="file" class="custom-file-input" name="image" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
														<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
													</div>-->
													<div>
													
													<input type="file" accept="image/*"  id="choose-file" name="image" />
													<label for="choose-file">Choose File</label>
													<div id="img-preview"></div>
												</div>
												</div>
												<div class="form-group col-md-1"></div>
												<div class="form-group col-md-3">
													<label >Logo View </label>
													<div class="custom-file"><?php $source->Query("SELECT * FROM `settings` where name='logo'"); $logo=$source->Single(); ?>
														<a href="../upload/banner/<?php echo $logo->value;?>" target="_blank"><img src="../upload/banner/<?php echo $logo->value;?>" style="width:70px; height:70px;border-radius:50%;border:2px solid #000"></a>
													</div>
												</div>
												<div class="form-group col-md-4  mt-2 pt-3">
												<button type="submit" class="btn btn-primary px-5 radius-30" id="uploadBtn">Update <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>
												</div>
											</div>
											
										</div>
									</form>
								</div>
							</div>
						</div>
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body">
									<div class="card-title d-flex align-items-center">
										
										<h5 class="mb-0 text-primary">Social media links</h5>
									</div>
									<hr>
									<form  id="FormSubmit1" novalidate="">
                     
									<input type="hidden" name="location" id="location" value="../code/ManageSetting?flag=link_update">
									
										<div class="form-body">
										
											<div class="form-row">
											
											<?php $source->Query("SELECT * FROM `settings` where name='links'"); $logo=$source->Single(); $links=explode("ZPS",$logo->value); ?>
											
												<div class="form-group col-md-4">
													<label >Facebook<sup class="text-danger">*</sup></label>
													<div class="custom-file">
														<input type="text" class="form-control" name="facebook" value="<?php  echo $links[0]; ?>">
													</div>
												</div>
												
												<div class="form-group col-md-4">
													<label >Twitter<sup class="text-danger">*</sup></label>
													<div class="custom-file">
														<input type="text" class="form-control" name="twitter" value="<?php  echo $links[1]; ?>">
													</div>
												</div>
												<div class="form-group col-md-4">
													<label >Instagram<sup class="text-danger">*</sup></label>
													<div class="custom-file">
														<input type="text" class="form-control" name="instagram" value="<?php  echo $links[2]; ?>" >
													</div>
												</div>
												<div class="form-group col-md-4">
													<label >Youtube<sup class="text-danger">*</sup></label>
													<div class="custom-file">
														<input type="text" class="form-control" name="youtube" value="<?php  echo $links[3]; ?>" >
													</div>
												</div>
													<div class="form-group col-md-4">
													<label >Download App Link<sup class="text-danger">*</sup></label>
													<div class="custom-file">
														<input type="text" class="form-control" name="app" value="<?php  echo $links[4]; ?>" >
													</div>
												</div>
												<div class="form-group col-md-4">
													<label >Text Marquee<sup class="text-danger">*</sup></label>
													<div class="custom-file">
													<?php $source->Query("SELECT * FROM `settings` where name='heading'"); 
													$heading=$source->Single();
														  ?>
														<input type="text" class="form-control" name="marquee" value="<?php echo $heading->value; ?>" />
													</div>
												</div>
												
												<div class="form-group col-md-4  mt-2 pt-3">
												<button type="submit" class="btn btn-primary px-5 radius-30" id="UpdateBtn">Update <i class="fa fa-spinner fa-spin" id="UpdateSpin" style="display:none;"></i></button>
												</div>
											</div>
											
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					<!--end row-->
					
					
				
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--End Back To Top Button-->
		<?php require'Footer.php';?>
	</div>
	
	<?php require'JsLink.php';?>
	 <script type="text/javascript" src="../ajax/SignUp.js"></script>
	 
	 <script>
				
		$("#FormSubmit1").on('submit', function(e) {
			 // $("#pageloader").fadeIn();
			e.preventDefault();
			var data = new FormData(this);
			// alert(data);
			$.ajax({
				type: 'POST',
				url: data.get('location'),
				data: data,
				cache: false,
				contentType: false,
				processData: false,
				 beforeSend: function() {
					$("#UpdateBtn").attr("disabled", true);
					$('#UpdateSpin').show();
				},
				success: function(response) {
					// alert(response);
					 $("#pageloader").fadeOut();
					var  response= JSON.parse(response);
					$("#UpdateBtn").removeAttr("disabled");
					$('#UpdateSpin').hide();
					if(response.res == 'success'){
						$.notify(response.msg,'success');
						 setInterval(function () {
							   location.href=response.url;
						   },3000)
					}
					else if(response.res == 'otp'){
						// alert("ok");
						$("#otp").show();
						$("#SelectLogin").val(response.otp);
						$("#EmailPwd").prop('readonly', true);
						$.notify(response.msg,'success');
					}else if(response.res=='newPwd'){
						$.notify(response.msg,'success');
						setInterval(function () {
						   location.href=response.url;
					   },3000)
					}else{
						$.notify(response.msg,'error');
					}
				},
				error: function() {
					 $("#uploadBtn").removeAttr("disabled");
					 $('#uploadSpin').hide();
					$.notify('Something went wrong','success');
				}
			});
		})


// keyup
	 </script>
</body>

<script>
	
	const chooseFile = document.getElementById("choose-file");
	const imgPreview = document.getElementById("img-preview");
	
	chooseFile.addEventListener("change", function () {
	  getImgData();
	  
	});
	
	function getImgData() {
	  const files = chooseFile.files[0];
	  if (files) {
		const fileReader = new FileReader();
		fileReader.readAsDataURL(files);
		fileReader.addEventListener("load", function () {
		  imgPreview.style.display = "block";
		  imgPreview.innerHTML = '<img src="' + this.result + '" />';
		});    
	  }
	}
	
	
	
</script>

</html>