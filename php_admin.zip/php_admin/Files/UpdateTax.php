<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php 
		require'Header.php';
		if(empty($_REQUEST['id'])){
		header("location:ManageTax");
		}
		else{
			$id=base64_decode($_REQUEST['id']);
			$source->Query("SELECT * FROM `tbl_tax` WHERE `id`=?",[$id]);
			$data=$source->Single();
			
		}
		?>
		
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					<div class="row">
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body p-5">
									<div class="card-title d-flex align-items-center">
										
										<h4 class="mb-0 text-primary">Update Tax</h4>
									</div>
									<hr>
									<form  id="FormSubmit" novalidate="">
                     
										<input type="hidden" name="location" id="location" value="../code/ManageTax?flag=Update">
										<input type="hidden" name="id"  value="<?php echo $id;?>">
									<div class="form-body">
									
										<div class="form-row">
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Title<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" value="<?php echo $data->title?>" name="title" placeholder="Title of Tax " required />
                                            </div>
										</div>
										<div class="col-sm-6 ">
                                            <div class="form-group">
                                                <label >Percentage<sup class="text-danger">*</sup></label>
                                                <input type="number" value="<?php echo $data->percentage?>" class="form-control" name="percentage" placeholder="10.00" required />
                                            </div>
										</div>
											
										</div>
										
                                        
										<button type="submit" class="btn btn-primary px-5 radius-30" id="uploadBtn">Update <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>
									</div>
									</form>
								</div>
							</div>
						</div>
						
					</div>
					<!--end row-->
					
					
				
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--End Back To Top Button-->
		<?php require'Footer.php';?>
	</div>
	
	<?php require'JsLink.php';?>
	 <script type="text/javascript" src="../ajax/SignUp.js"></script>
</body>

</html>