<?php
// require "../init.php";
// $category = $_POST["category"];
// $cat = $_POST["cat"];
// $source->Query("SELECT * from tbl_subcategory where delete_status='false' and category_id='$category'");
                            
?>
<!---<option disabled selected>--Select Sub Category--</option>
<?php
//while($data1=$source->Single()) {
?>
<option value='<?php //echo $data1->id;?>' <?php //if($data1->id==$cat){ echo "selected";}?>><?php //echo $data1->name;?></option>------->
<?php
//}
?>

<?php 
require "../init.php";

	error_reporting(0);
	$flag=$_REQUEST['flag'];

	switch ($flag) 
	{
		
		case 'SubCategory':
			$category = $_POST["category"];
			$cat = $_POST["cat"];
			$source->Query("SELECT * from tbl_service_subcategory where delete_status='false' and category_id='$category'");
										
			?>
			<option disabled selected>Select Sub-Category</option>
			<?php
			while($data1=$source->Single()) {
			?>
			<option value='<?php echo $data1->id;?>' <?php if($data1->id==$cat){ echo "selected";}?>><?php echo $data1->name;?></option>
			<?php }
		break;	
			
		
			?>









<?php
	}
?>