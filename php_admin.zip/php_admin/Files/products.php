<?php
  require '../../Admin/init.php';
  $id=$_POST['id'];
  $source->Query("select * from tbl_subcategory where delete_status='false' and category_id='$id'"); 
  while($data=$source->Single())
  {
	echo '<option value="'.$data->id.'">'.base64_decode($data->name).'</option>';	
  }

	
?>