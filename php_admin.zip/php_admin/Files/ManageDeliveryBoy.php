<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Manage Delivery Boy</h4>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>AD ID</th>
											<th>Name</th>
											<th>Email</th>
											<th>Mobile</th>
											<th>Document No.</th>
											<th>Wallet Amount</th>
											<th>Commission</th>
											<th>Total Referrals</th>
											<th>Document</th>
											<th>Profile</th>
											<th>Date/Time</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$source->Query("SELECT * FROM `tbl_deliveryboy` where delete_status='false' ORDER BY `id` DESC");
										while ($values=$source->Single()){
											
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											<td><a href="DeliveryBoyDashboard?id=<?php echo base64_encode($values->id);?>"><?php echo $values->sponsorID;?></td>
											<td><?php echo $values->name;?></td>
											<td><?php echo $values->email;?></td>
											<td><?php echo $values->mobile;?></td>
											<td><?php echo $values->document_no;?></td>
											<td><?php echo $values->commission;?></td>
											<td>&#x20B9;<?php echo $values->wallet;?></td>
											<td><?php $source->Query1("SELECT * FROM `tbl_deliveryboy` where delete_status='false' and referral_id='$values->sponsorID'"); echo $count=$source->NumRows();?></td>
											<td><a href="../../API/v1/uploads/Driver/<?php echo $values->document_image;?>" target="_blank"><img src="../../API/v1/uploads/Driver/<?php echo $values->document_image;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
											<td><a href="../../API/v1/uploads/Driver/<?php echo $values->image;?>" target="_blank"><img src="../../API/v1/uploads/Driver/<?php echo $values->image;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
											
											<td><?php echo $values->date;?><br><?php echo $values->time;?></td>
											<td>
												<a class="btn btn-outline-warning btn-circle" title="Edit" href="UpdateDeliveryBoy?id=<?php echo base64_encode($values->id);?>"><i class="fa fa-pencil"></i></a>
												<?php if($values->status=='true'){
												?><input type="checkbox" checked onchange="Status(<?php echo $values->id?>,'status','false','tbl_deliveryboy','Deactive')" name="checkbox"  data-toggle="toggle" ><?php
											}else{
												?><input type="checkbox" onchange="Status(<?php echo $values->id?>,'status','true','tbl_deliveryboy','Active')" name="checkbox"  data-toggle="toggle" ><?php
											} ?>
									
												<button class="btn btn-outline-danger " title="Delete" onclick="Status(<?php echo $values->id?>,'delete_status','true','tbl_deliveryboy','Delete')"><i class="fa fa-trash "></i></button>
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
</body>

</html>