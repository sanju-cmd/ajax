<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					<div class="row">
						<div class="col-12 col-lg-12">
							<div class="card radius-15 border-lg-top-primary">
								<div class="card-body p-5">
									<div class="card-title d-flex align-items-center">
										
										<h4 class="mb-0 text-primary">Update Attributes  </h4>
										
										<?php $source->Query("SELECT * FROM `tbl_attribute` WHERE id='".base64_decode($_REQUEST['id'])."'"); $data=$source->Single();  ?>
										
									</div>
									<hr>
									<form  id="FormSubmit" class="FormSubmit" novalidate="">
                     
										<input type="hidden" name="location" id="location" value="../code/ManageProduct?flag=UpdateAttribute">
										
										<input type="hidden" name="id"  value="<?= base64_decode($_REQUEST['id']) ?>">
									
									<div class="form-body">
									
										<div class="form-row">
										<div class="col-sm-4 ">
                                            <div class="form-group">
                                                <label >Name<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="name" value="<?= $data->name; ?>" placeholder="Name " required />
                                            </div>
										</div>
										
										<div class="col-sm-4 ">
                                            <div class="form-group">
                                                <label >Text<sup class="text-danger">*</sup></label>
                                                <input type="text" class="form-control" name="text" placeholder="Text "   value="<?= $data->text; ?>"  required />
                                            </div>
										</div>
										
																				</div>
										
                                        
										<button type="submit" class="btn btn-primary px-5 radius-30" id="uploadBtn" >Update <i class="fa fa-spinner fa-spin" id="uploadSpin" style="display:none;"></i></button>
										
									</div>
									</form>
								</div>
							</div>
						</div>
						
					</div> 
					<!--end row-->
					
					
				
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--End Back To Top Button-->
		<?php require'Footer.php';?>
	</div>
	
	<?php require'JsLink.php';?>
	 <script type="text/javascript">
		
		
		$("#FormSubmit").on('submit', function(e) {
	 // $("#pageloader").fadeIn();
	e.preventDefault();
	var data = new FormData(this);
	// alert(data);
	$.ajax({
		type: 'POST',
		url: data.get('location'),
		data: data,
		cache: false,
		contentType: false,
		processData: false,
		 beforeSend: function() {
			$("#uploadBtn").attr("disabled", true);
			$('#uploadSpin').show();
		},
		success: function(response) {
			// alert(response);
			 $("#pageloader").fadeOut();
			var  response= JSON.parse(response);
			$("#uploadBtn").removeAttr("disabled");
			$('#uploadSpin').hide();
			if(response.res == 'success'){
				$.notify(response.msg,'success');
				 window.location.href=response.url;
			}
			else if(response.res == 'otp'){
				// alert("ok");
				$("#otp").show();
				$("#SelectLogin").val(response.otp);
				$("#EmailPwd").prop('readonly', true);
				$.notify(response.msg,'success');
			}else if(response.res=='newPwd'){
				$.notify(response.msg,'success');
				setInterval(function () {
				   location.href=response.url;
			   },3000)
			}else{
				$.notify(response.msg,'error');
			}
		},
		error: function() {
			 $("#uploadBtn").removeAttr("disabled");
			 $('#uploadSpin').hide();
			$.notify('Something went wrong','success');
		}
	});
})

	
    </script>
	 	
</body>

</html>