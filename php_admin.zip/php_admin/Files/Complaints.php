<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';?>
		
		<?php
			
			if(isset($_POST['update_reply']))
			{
				$id=$_POST['id'];
				$message=$_POST['message'];
				
				if(!empty($message)){
					
					$sql=$source->Query("UPDATE complaints SET reply='$message' ,reply_status='true',reply_date='$date' WHERE id='$id'");
					if($sql){
						echo "<script>
						const Toast = Swal.mixin({
						  toast: true,
						  position: 'top-end',
						  showConfirmButton: false,
						  timer: 3000,
						  timerProgressBar: true,
						  didOpen: (toast) => {
							toast.addEventListener('mouseenter', Swal.stopTimer)
							toast.addEventListener('mouseleave', Swal.resumeTimer)
						  }
						})

						Toast.fire({
						  icon: 'success',
						  title: 'Send Reply successfully'
						})
						</script>";
					}else{
						echo "<script>
						const Toast = Swal.mixin({
						  toast: true,
						  position: 'top-end',
						  showConfirmButton: false,
						  timer: 3000,
						  timerProgressBar: true,
						  didOpen: (toast) => {
							toast.addEventListener('mouseenter', Swal.stopTimer)
							toast.addEventListener('mouseleave', Swal.resumeTimer)
						  }
						})

						Toast.fire({
						  icon: 'error',
						  title: 'Network Problem'
						})
						</script>";
					}
					
				}else{
					echo "<script>
					const Toast = Swal.mixin({
					  toast: true,
					  position: 'top-end',
					  showConfirmButton: false,
					  timer: 3000,
					  timerProgressBar: true,
					  didOpen: (toast) => {
						toast.addEventListener('mouseenter', Swal.stopTimer)
						toast.addEventListener('mouseleave', Swal.resumeTimer)
					  }
					})

					Toast.fire({
					  icon: 'error',
					  title: 'Enter Reply'
					})
					</script>";
				}
				
			}
			
		?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Manage Complaints</h4>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Type</th>
											<th>UserId</th>
											<th>UserName</th>
											<th>Mobile</th>
											<th>Title</th>
											<th>Complaint</th>
											<th>Reply</th>
											<th>Reply Status</th>
											<th>Reply Date</th>
											<th>Date/Time</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$source->Query("SELECT * FROM `complaints` ORDER BY `id` DESC");
										while ($values=$source->Single()){
											
											if($values->type=='User'){
												$source->Query1("SELECT * FROM `tbl_user` where id=?",[$values->user_id]);
												$data=$source->SingleData();
											}
											
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											<td><?php echo $values->type;?></td>
											<td><?php echo $data->id;?></td>
											<td><?php echo $data->name;?></td>
											<td><?php echo $data->mobile;?></td>
											<td><?php echo $values->title;?></td>
											<td><?php echo $values->complaint;?></td>
											<td><?php echo $values->reply;?></td>
											<td><?php echo $values->reply_status;?></td>
											<td><?php echo $values->reply_date;?></td>
											<td><?php echo $values->date;?> <?php echo $values->time;?></td>
											<td> <?php if($values->reply_status=='false'){ ?><a onclick="Reply(<?php echo $values->id; ?>)" ><label class='btn btn-success btn-sm' style='cursor:pointer '>Reply</label></a><?php } ?></td>
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<div class="modal fade" id="sendReply" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Send Reply</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
	  <form method="post">
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="update_reply" class="btn btn-primary">Send</button>
      </div>
	  </form>
    </div>
  </div>
</div>
		<!--start overlay-->
		
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
	<script>
		function Reply(id){
		$("#sendReply").modal("show");
		$("#sendReply .modal-body").html("<center><i class='fa fa-4x fa-spin fa-spinner'></i></center>");
		$("#sendReply .modal-body").load("../code/Complaints.php?flag=2&id="+id);
	}
	</script>
</body>

</html>