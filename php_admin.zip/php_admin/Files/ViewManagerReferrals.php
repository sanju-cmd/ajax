<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<?php require'LeftMenu.php';?>
		<?php require'Header.php';
		if(empty($_REQUEST['id'])){
		header("location:ManageManager");
		}
		else{
			$id=base64_decode($_REQUEST['id']);
			$source->Query("SELECT * FROM `tbl_manager` WHERE `sponsorID`=?",[$id]);
			$data=$source->Single();
			
		}
		?>
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					
					<!--end breadcrumb-->
					
					<div class="card">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0"> All Manager Referrals</h4>
							</div>
							<hr>
							<div class="table-responsive">
								<table id="example2" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sr. No.</th>
											<th>Sponsor ID</th>
											<th>Name</th>
											<th>Email</th>
											<th>Mobile</th>
											<th>Wallet Amount</th>
											<th>Total Referrals</th>
											<th>Profile</th>
											<th>Date/Time</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i=1;
										$source->Query("SELECT * FROM `tbl_manager` where delete_status='false' and referral_id='$data->sponsorID' ORDER BY `id` DESC");
										while ($values=$source->Single()){
											
                                    ?>
										<tr>
											<td><?php echo $i;?></td>
											<td><a href="ManagerDashboard?id=<?php echo base64_encode($values->id);?>"><?php echo $values->sponsorID;?></td>
											<td><?php echo $values->name;?></td>
											<td><?php echo $values->email;?></td>
											<td><?php echo $values->mobile;?></td>
											<td>&#x20B9;<?php echo $values->wallet;?></td>
											<td><?php $source->Query1("SELECT * FROM `tbl_manager` where delete_status='false' and referral_id='$values->sponsorID'"); echo $count=$source->NumRows();?></td>
											<td><a href="../../API/v1/uploads/manager/<?php echo $values->image;?>" target="_blank"><img src="../../API/v1/uploads/manager/<?php echo $values->image;?>" style="width:50px; height:50px;border-radius:50%;"></a></td>
											<td><?php echo $values->date;?><br><?php echo $values->time;?></td>
											<td>
												<a class="btn btn-outline-warning btn-circle" title="Edit" href="UpdateManager?id=<?php echo base64_encode($values->id);?>"><i class="fa fa-pencil"></i></a>
												
												<button class="btn btn-outline-danger " title="Delete" onclick="Status(<?php echo $values->id?>,'delete_status','true','tbl_manager','Delete')"><i class="fa fa-trash "></i></button>
											</td>
										</tr>
									<?php $i++; }?>
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<?php require'Footer.php';?>
	</div>
	<!-- end wrapper -->
	
	<?php require'JsLink.php';?>
</body>

</html>