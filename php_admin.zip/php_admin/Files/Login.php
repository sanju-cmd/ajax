<!DOCTYPE html>
<html lang="en">

<head>
	<?php require'CssLink.php';?>
</head>

<body class="bg-login">
	<!-- wrapper -->
	<div class="wrapper">
		<div class="section-authentication-login d-flex align-items-center justify-content-center">
			<div class="row">
				<div class="col-12 col-lg-10 mx-auto mt-5">
					<div class="card radius-15">
						<div class="row no-gutters">
							<div class="col-lg-6">
							 <form class="" id="FormSubmit" method="post">
			  
							 <input type="hidden" name="location" id="location" value="../code/ManageAccount.php?flag=Login">
			  
								<div class="card-body p-md-5">
									<div class="text-center">
										<img src="../assets/images/20211110213917.png" width="250" height="80" alt="">
										<h3 class="mt-4 font-weight-bold">Welcome Back</h3>
									</div>
									
									<div class="login-separater text-center"> <span>LOGIN WITH EMAIL</span>
										<hr>
									</div>
									<div class="form-group mt-4">
										<label>Email Address</label>
										<input type="text" class="form-control" name="email" placeholder="Enter your email address">
									</div>
									<div class="form-group">
										<label>Password</label>
										<input type="password" class="form-control" name="password" placeholder="Enter your password">
									</div>
									<!--<div class="form-row">
										<div class="form-group col">
											<div class="custom-control custom-switch">
												<input type="checkbox" class="custom-control-input" id="customSwitch1" checked="">
												<label class="custom-control-label" for="customSwitch1">Remember Me</label>
											</div>
										</div>
										<!--div class="form-group col text-right"> <a href="#"><i class='bx bxs-key mr-2'></i>Forget Password?</a>
										</div
									</div>-->
									<div class="btn-group mt-3 w-100">
										<button type="submit" class="btn btn-primary btn-block">Log In </button>
										
									</div>
									
								</div>
								</form>
							</div>
							<div class="col-lg-6">
								<img src="../assets/images/login-images/Adminlogin.png" class="card-img login-img h-100" alt="...">
							</div>
						</div>
						<!--end row-->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end wrapper -->
	<?php require 'JsLink.php';?>
	<script type="text/javascript" src="../ajax/SignUp.js"></script>
</body>

</html>